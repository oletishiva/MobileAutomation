package grocery.core;

import grocery.utils.Flows;
import grocery.utils.InputParserUtil;

/** @author Roma Jacob Remedy Dec12RJR*/

/** AbstractTestCase is the parent of all TestCases Dec12RJR */
public abstract class AbstractTestCase {

	/** flows {@link Flows} contains all the common user flows Apr11RJR */
	Flows flows = Flows.getFlowsInstance();
	
	/** declaring the objects name Dec15RJR */
	protected transient String name;


	
	/** Common Variables Section are used within the Test Cases Apr19RJR */
	
	/** actualResult stores the actualResult value for assertion Dec15RJR */
	protected transient Object actualResult;
	/** actualResult stores the expectedResult value for assertion Dec15RJR */
	protected transient Object expectedResult;
	
	/** someVariable is a generic string helper variable Mar19RJR */
	protected transient String someVariable;
	
	/** orderNumber stores the orderNumber when order is captured Mar19RJR */
	protected transient String orderNumber;
	
	/** cartTotalPrice stores the parsed price of the cart May14RJR */
	protected transient double cartTotalPrice;
	
	/** firstItemPrice stores the parsed price of an item May14RJR */
	protected transient double firstItemPrice;
	/** secondItemPrice stores the parsed price of an item May14RJR */
	protected transient double secondItemPrice;
	
	
	
	/** EBT Item Apr19RJR */
	protected transient String itemBeef = "Great Value Beef Broth";
	/** EBT Item Apr19RJR */
	protected transient String itemWater = "Great Value Purified Water";
	/** EBT Item Apr19RJR */
	protected transient String itemVaccum = "Bissell Powerforce vacuum";
	/** EBT Item Apr19RJR */
	protected transient String itemRedWine = "Apothic Crush Red Wine";
	/** EBT Item Apr19RJR */
	protected transient String itemChicken = "Oscar Mayer Oven Roasted Chicken";
	/** EBT Item Apr19RJR */
	protected transient String itemSalame = "Gallo Peppered Salame";
	/** EBT Item Apr19RJR */
	protected transient String itemJalapeno = "Jalapeno Peppers approximately 3-5 peppers per 0.25 lb";
	/** EBT Item Apr19RJR */
	protected transient String itemCrackers = "Cheez-it White Cheddar Baked Snack Crackers";
	/** EBT Item Apr19RJR */
	protected transient String itemPolish = "Krakus Sliced Polish Ham";

	
	
	
	
	
	
	/** {@link UtilityContainer} */
	protected transient UtilityContainer utility;

	/** initialQuantity stores an Integer value of items Feb26RJR */
	protected transient Integer initialQuantity; 
	
	/** signInState represents the user state Jan01RJR */
	protected final transient Object signInState;
	/** getSignInState returns the state of sign in 
	 * @return {@link signInState} Jan01RJR */
	protected Object getSignInState() {
		return signInState;
	}//getSignInState
	
	/**
	 * constructs AbstractTestCase setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public AbstractTestCase(final UtilityContainer utility) {
		setUtility(utility);
		signInState = utility.getSignInState();
		name = this.getClass().getSimpleName();
	}//constructor
	
	//should i return object this? Apr18RJR
	protected void tapElementAbstractClass(final String elementLocator) {
	        utility.seleniumAction("tapElement", elementLocator);
		
	}//
	
	/**
	 * sets local reference of {@link UtilityContainer} @param utility Dec12RJR
	 */
	private void setUtility(final UtilityContainer utility) {
		this.utility = utility;
	}//initTestCase
	
	
	/** flow_SignIn first orchestrates the SignIn Sequence 
	 * than asserts that User Is On Home Screen  Jan13RJR */
	protected void flowSignIn() {
		if ( !utility.mappedCLA.get( InputParserUtil.InputCLA.resetappiumdevice)
				.equals("noReset")
				&& getSignInState().equals(false)) {
			utility.getSignIn(utility);
		}//if statement
		
		utility.assertUserIsOnHomeScreen();
	}//flow_SignIn
	
	
	public Object flowCleanCart() {
		flows.flowCleanCart( utility );
		return this;
	}
	
	public Object flowAddItemViaFavoritesSearch( final String itemName) {
		flows.flowAddToCartFavoriteItem( utility , itemName );
		return this;
	}
	
	
	
	public Object flowAddItemViaSearch2( final String itemName) {
		flows.addToCartSearchedItem( utility , itemName );
		return this;
	}
	
	
	
	public Object flowEbtCheckoutPlaceorder( final String cvv ) {
		flows.flowEbtCheckoutPlaceorder( cvv );
		
		
		return this;
	}//flowEbtCheckoutPlaceorder
	
	/** perform will contain the test body in child class 
	 * @throws Exception */
	public abstract void perform() throws Throwable ;
	
}//AbstractTestCase