package grocery.core;
/** @author R.Jacob Remedy May11RJR */

import static java.util.concurrent.TimeUnit.SECONDS;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import com.google.common.base.Function;

import edu.emory.mathcs.backport.java.util.concurrent.TimeoutException;
import grocery.utils.Flow_SignIn;
import grocery.utils.InputParserUtil;
import grocery.utils.OgStateUtil;
import grocery.utils.PageObjPatUtil;
import grocery.utils.Reporter;
import grocery.utils.InputParserUtilInterface.InputCLA;
import grocery.utils.driverfactory.DriverFactory;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import ru.yandex.qatools.allure.annotations.Step;

interface UtilityContainerInterface {
	
	/** initializing sequence for utilityContainer Dec11RJR */
	void initUtilityContainer();
	
	/** Instantiates the driver from the DriverFactory Dec06RJR */
	void instantiateWebDriver();
	
	/**
	 * getLocator will retrieve the element xPath from the mappedElements excel
	 * document
	 * 
	 * @param locatorReference
	 *            String is the locator name of the element in the mappedElements
	 *            excel document Dec19RJR
	 */
	String getLocator( final String locatorReference );
	
	
	/**
	 * clickElement will click the specific UI element.
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen. Dec19RJR
	 */
	void clickElement( final String elementLocator );
	
	/** clickElement will click the specific UI element.
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param text String
	 *            is the text to sendKeys to the element. Dec19RJR
	 */
	void sendKeysElement( final String elementLocator , final String text );
	
	/** getTextElement will parse text from the specific UI element.
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @return text String
	 *            the text that was parsed from the UI element Dec19RJR
	 */
	String getTextElement( final String elementLocator );
	

	/**
	 * getPriceElement receives an elementLocator String,
	 * finds the relevant element, parsing and extracting the price,
	 * returning the price as a bigDecimal.
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @return priceAsBigDecimal <BigDecimal> Jan31RJR
	 */
	BigDecimal getPriceElement ( final String elementLocator );
	
	
	/**
	 * scrollToElement will scroll the element into view based on the String text
	 * the element has Feb02RJR
	 * 
	 * @param anchoringText
	 *            <String> is the text to scroll to
	 */
	void scrollToElement(final String anchoringText);


	/** hardAssert will conduct assertion between actualResult vs expectedResult
	 * it will log the result and capture a screenshot upon failure
	 * @param actualResult <T>
	 * @param expectedResult <T>
	 * @param name the message to be included in assertion for logging (TestCase name)
	 * @return this <T> the hardAssertion returns its state Jan03RJR */
	<T> void hardAssert( final T actualResult, final T expectedResult, final String name );
	

	/** fastSwipe will make the fast swipe from the element in the direction
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param swipeDirection String
	 *            is the direction of swipe
	 */
	void fastSwipe( final String elementLocator, final String swipeDirection );
	
	/** slowSwipe will make the slow swipe from the element in the direction
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param swipeDirection String
	 *            is the direction of swipe
	 */
	void slowSwipe( final String elementLocator, final String swipeDirection );
	
	/** fastScrollHorizontal will make the
	 * fast horizontal scrolling from/or the element in the direction
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 */
	void fastScrollHorizontal( final String elementLocator);
	
	/** fastScrollVertical will make
	 * the fast vertical scrolling from/or the element in the direction
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 */
	void fastScrollVertical( final String elementLocator);
	
	/** tapVariableElement will tap the specific
	 * UI element that contains a preassigned text
	 * @param elementLocator String the locator of an element on screen.
	 * @param text String the text contained in the element
	 * @return true if tap was success
	 * @return false if tap was failure       */  
	boolean tapVarElement( final String elementLocator, final String text );
	
	
	
	
}// UtilityContainerInterface

/**
 * UtilityContainer contains all the methods evoked during automation
 * and encapsulates all interactions with the driver Dec12RJR
 */
public final class UtilityContainer implements UtilityContainerInterface {

    /**
     * {@link InputParserUtil}
     */
    private transient InputParserUtil inputParserUtil;

    /**
     * driver {@link WebDriver} is the object instance of WebDriver
     * Dec06RJR
     */
    private transient WebDriver driver;

    /**
     * element {@link WebElement} is a particular element Dec19RJR
     */
    private transient WebElement element;
    /**
     * elementxPath {@link WebElement} is the DOM path to the element Dec19RJR
     */
    private transient String elementxPath;

    /**
     * ** reporter used for logging of messages and screenshots
     */
    public transient Reporter reporter = Reporter.getreporterInstance();

    
    /**
     * mappedCLA is a {@link HashMap} that stores all the Frameworks arguments
     * Dec24RJR
     */
    protected transient Map<InputCLA, String> mappedCLA;
    /**
     * mappedElementsMap member contains the Key Value Element Name and xPath
     * pairs used within the project Dec17RJR
     */
    private transient Map<String, String> mappedElementsMap;
    /**
     * {@link PageObjPatUtil} PageObjPatUtil reads the
     * mappedElements.xlsx document, parsing the element names and locators an
     * creating a mappedElementMap object where locator xPaths can be returned
     * when calling the element Name as key this is an Excel alternative to
     * PageFactory Dec17RJR
     */
    private transient PageObjPatUtil pageObjPatUtil;

    /**
     * the testDataPropFile stores all the testData for the Oga TestCases Feb22RJR
     */
    private transient Properties testDataPropFile;


    /**
     * signInFlag represents being signed in as a user Jan02RJR
     */
    private transient Object signInFlag = Flow_SignIn.getSignInState();


    /**
     * {@link OgStateUtil} Feb21RJR
     */
    public transient OgStateUtil ogaStateUtil;

    /**
     * testDataMap stores all the Oga test data as key value pairs from the
     * OgaTestData Properties file Feb22RJR
     */
    private transient Map<String, String> testDataMap;


    /**
     * creates an instance of {@link UtilityContainer} Dec11RJR
     */
    public UtilityContainer() {
        initUtilityContainer();
    }//constructor


    @Override
    /** {@link initUtilityContainer} Dec11RJR */
    public void initUtilityContainer() {
        try {

            inputParserUtil = new InputParserUtil();
            initMappedCLA();
            initTestDataMap(mappedCLA.get(InputCLA.nameOfTestData));

            instantiateOgStateUtil();
            instantiateWebDriver();
            initPageObjPatUtil();


        } catch (Exception e) {
            reporter.logToAllure(String.format("%n Exception happened in %s \n The Exception was: %s \n",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e));
            e.printStackTrace();
        } // try-catch
    }// initUtilityContainer


    
    /**
     * initMappedCLA initializes, loads and prints, all the Command Line Arguments
     * into the mappedCLA collection Feb23RJR
     */
    public void initMappedCLA() {
        mappedCLA = inputParserUtil.getMappedCLA();
        reporter.logToAllure(String.format("%n Printing grocery.properties"));
        for (final Entry<InputCLA, String> someEntry : mappedCLA.entrySet()) {
            reporter.logToAllure(String.format(" key  : " + someEntry.getKey()));
            reporter.logToAllure(String.format(" value: " + someEntry.getValue()));
        }//for loop
    }//initMappedCLA

    /**
     * loadOgaTestDataPropFile loads the groceryTestData.properties file Apr15RJR
     *
     * @param nameOfTestData String name of the testDataFile to load
     * @throws IOException
     * @throws FileNotFoundException
     */
    public void initTestDataMap(final String nameOfTestData) throws FileNotFoundException, IOException {

        reporter.logToAllure("iniTestDataMap loading the"
                + "testDataPropFile in UtilityContainer");

        testDataMap = new HashMap<String, String>();
        testDataPropFile = new Properties();

        /** stream loads the property file by searching for it in the project Apr15RJR */
		final InputStream stream = ClassLoader.getSystemResourceAsStream( nameOfTestData );
        
        try {
            testDataPropFile.load(stream);
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException("property file '" + nameOfTestData + "' not found in the classpath" + e);
        }



        for (final String key : testDataPropFile.stringPropertyNames()) {
            final String value = testDataPropFile.getProperty(key);

            reporter.loggerNoAllureDebug(String.format(
                    "\n testDataMap put \n Key: %s\n Value: %s", key, value));
            testDataMap.put(key, value);

        }//for each loops
    } //loadOgaTestDataPropFile

    /**
     * instantiateOgStateUtil instantiates the {@link OgaStatUtil} object Feb21RJR
     */
    public void instantiateOgStateUtil() {
        ogaStateUtil = new OgStateUtil();
    }//instantiateOgStateUtil

    @Override
    /** {@link instantiateWebDriver} Dec11RJR */
    public void instantiateWebDriver() {
        try {

            final DriverFactory driverFactory = new DriverFactory(inputParserUtil);
            driverFactory.buildDriver();
            driver = driverFactory.getDriver();
            setDriver(driver);

        } catch (Exception e) {
            final String exception = String.format("%n Exception happened in %s \n The Exception was: %s",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
            reporter.logToAllure(exception);
        } // try-catch
    } // instantiateWebDriver


    /**
     * initPageObjPatUtil instantiates and loads all the relevant
     * sequence components for the mappedElementsMap to be parsed Dec17RJR
     */
    public void initPageObjPatUtil() {

        try {


            pageObjPatUtil = new PageObjPatUtil();

            pageObjPatUtil.createMappedElementsMAP(mappedCLA.get(InputCLA.locMappedElements));

            mappedElementsMap = new HashMap<String, String>();

            mappedElementsMap = pageObjPatUtil.getMappedElementsMap();


        } catch (Exception e) {
            reporter.logToAllure(String.format("%n Exception happened in %s \n The Exception was: %s",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e));
        } // try-catch
    }//initPageObjPatUtil

    @Override
    /**
     * getLocator will retrieve the element xPath from the mappedElements excel
     * document
     *
     * @param locatorReference
     *            String is the locator name of the element in the mappedElements
     *            excel document Dec19RJR
     */
    public String getLocator(final String elementLocator) {
        String elemLocatorPath;
        elemLocatorPath = mappedElementsMap.get(elementLocator);
        return elemLocatorPath;
    }// getLocator


    /**
     * driver getter @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }//getDriver

    /**
     * driver setter Dec11RJR
     */
    public void setDriver(final WebDriver driver) {
        this.driver = driver;
    }//setDriver

    /**
     * inputParserUtil setter Dec11RJR
     */
    public void setInputParserUtil(final InputParserUtil inputParserUtil) {
        this.inputParserUtil = inputParserUtil;
    }//inputParserUtil


    /** clickNativeAndroidBackButton clicks the Android native back button Apr24RJR */
	public void clickNativeAndroidBackButton() {
		reporter.logToAllure(" tap the device back button to navigate back");
		//tap back button  //only for automation
		getDriver().navigate().back();
	}//clickNativeAndroidBackButton
    
    @Override
    /**
     * clickElement will click the specific UI element.
     *
     * @param elementLocator
     *            is the locator of an element on the page or screen. Feb22RJR
     */
    public void clickElement(final String elementLocator) {
        seleniumAction("clickElement", elementLocator);
    } // clickElement


    @Override
    /** clickElement will click the specific UI element.
     *
     * @param elementLocator String
     *            is the locator of an element on the page or screen.
     * @param text String
     *            is the text to sendKeys to the element. Feb22RJR
     */
    public void sendKeysElement(final String elementLocator, final String text) {
        seleniumAction("sendKeysElement", elementLocator, text);
    } // sendKeysElement

    @Override
    /** getTextElement will parse text from the specific UI element.
     *
     * @param elementLocator String
     *            is the locator of an element on the page or screen.
     * @return text String
     *            the text that was parsed from the UI element Feb22RJR
     */
    public String getTextElement(final String elementLocator) {
        return (String) seleniumAction("getTextElement", elementLocator);
    } // getTextElement


//	@Override

    /**
     * {@link tapElement }
     */
    public void tapElement(final String elementLocator) {
        seleniumAction("tapElement", elementLocator);
    }//tapElement


    @Override
    /** {@link @getPriceElement } */
    public BigDecimal getPriceElement(final String elementLocator) {
        return (BigDecimal) seleniumAction("getPriceElement", elementLocator);
    }//getPriceElement

    /**
     * {@link scrollToElement }
     */
    public void scrollToElement(final String anchoringText) {
        reporter.measureMethodDuration();

        reporter.logToAllure(String.format("%n scrollToElement: %s %n anchoringText: %n",
                anchoringText));

        element = (AndroidElement) driver.findElement(MobileBy.AndroidUIAutomator(
                "new UiScrollable(new UiSelector().className(\"android.widget.LinearLayout\")).getChildByText("
                        + "new UiSelector().className(\"android.widget.FrameLayout\"), \"" + anchoringText + "\")"));

        reporter.logMethodDuration();
    }//scrollToElement

    @Override
    /** fastScrollHorizontal will make the fast horizontal scrolling of element
     *
     * @param elementLocator String
     *            is the locator of an element on the page or screen.
     */
    public void fastScrollHorizontal(final String elementLocator) {
        fastScroll(elementLocator, "horizontal");
    }
    

    @Override
    /** fastScrollVertical will make the fast vertical scrolling of element
     *
     * @param elementLocator String
     *            is the locator of an element on the page or screen.
     */
    public void fastScrollVertical(final String elementLocator) {
        fastScroll(elementLocator, "vertical");
    }
    
    
    
    /** isEnabledElement will check if an element is present and enabled
    *
    * @param elementLocator String
    *            is the locator of an element on the page or screen.
    * @return true/false boolean
    *            the result whether an element was present or not Apr28RJR
    */
   public boolean isEnabledElement(final String elementLocator) {
       return (boolean) seleniumAction( "isEnabledElement" , elementLocator);
   } // isEnabledElement
    

   /** parsePriceElement will parse the price from an element
   * returning the read price as a double value
   *
   * @param elementLocator String
   *            is the locator of an element on the page or screen.
   * @return price double
   *            the parsed price read from the element May14RJR
   */
   public double parsePriceElement( final String elementLocator) {
	   return (double) seleniumAction( "parsePriceElement" , elementLocator);
   }//parsePriceElement
   
   
    /**
     * seleniumAction helps with all the element Interactions
     *
     * @Param callerMethodName String name of method that calls the seleniumAction
     * @Param callerMethodVars String[]
     * All other variables passed from the caller method
     * @Return returnedValue Object
     * the returned value from this method can be any object Feb21RJR
     */
    public Object seleniumAction(final String callerMethodName, final String... callerMethodVars) {
        final String elementLocator = callerMethodVars[0];
        String text;
        Object returnedValue = null;
        reporter.measureMethodDuration();


        /** flagsMap contains all the state flags and error handling elements
         * Key = elementLocator , Value = Boolean Mar08RJR */
        Map<String, Boolean> flagsMap = new HashMap<String, Boolean>();
        flagsMap.put("splashScreen_CloseButton", false);
        flagsMap.put("reserveATime_AlertOkButton", false);
        flagsMap.put("homeTab_ReserveButton", false);
        flagsMap.put("pickupTab_ChangeButton", false);
        flagsMap.put("reserveATime_NoAvailabilityTodayText", false);



        if (isElementFluentlyPresent(elementLocator)) {
            //if its true continue
        } else {
        	
        	reporter.logToAllure(  "isElementFluentlyPresent error handling started:");
        	
        	reporter.logToAllure("\n an error occurred and error handler activated"
        			+ "- setting error handler eanabled flag to true" );
        	ogaStateUtil.setOgFlag( "flag_ErrorHandlingActivated", true);
        	
        	reporter.logToAllure( "Capturing image during error handling with makeScreenShotAndAttachToAllure");
        	reporter.makeScreenShotAndAttachToAllure(driver, "someScreenshot_");
        	
        	if ( ! isUserOnHomeScreen() ) {
        		reporter.logToAllure( " Navigating back to home screen from flowCleanCart");
        		clickNativeAndroidBackButton();
        	} //if statement 
        	
        	
        }//if else statement

        elementxPath = this.getLocator(elementLocator);

        reporter.logToAllure(String.format("\n %s: %s \n xPath: %s",
                callerMethodName, elementLocator, elementxPath));
        element = driver.findElement(By.xpath(elementxPath));


        switch (callerMethodName) {
            case "clickElement":
                element.click();
                break;

            case "sendKeysElement":
                text = callerMethodVars[1];
                reporter.logToAllure(String.format(
                        "\n text to send is: %s", text));
                element.sendKeys(text);
                break;

            case "tapElement":
                new TouchAction((MobileDriver<?>) driver).tap(element).perform();
                break;


            case "getTextElement":
                returnedValue = element.getText();
                reporter.logToAllure(String.format("%n %s: read text is: %s",
                        callerMethodName, returnedValue));
                break;

            case "getPriceElement":
                text = element.getText();
                returnedValue = new BigDecimal(text.replace("$", ""));
                reporter.logToAllure(String.format("%n getPriceElement: parsed Element"
                        + "price is: %d", returnedValue));
                break;
                
            case "isEnabledElement":
            	returnedValue = element.isEnabled();
            	reporter.logToAllure("did we crash because of log below? (in seleniumAction");
                reporter.logToAllure(String.format("%n isEnabledElement: %s", returnedValue));
                break;
                
            case "parsePriceElement":
        		final String regexPricePattern = "^"
   					 + "(?:\\$)?"
   					 + "(?:\\s*)?"
   					 + "((?:\\d{1,3})(?:\\,)?(?:\\d{3})?(?:\\.)?(\\d{0,2})?)"
   					 + "$";	
            	
            	returnedValue = element.getText();

        		final Pattern pattern = Pattern.compile(regexPricePattern);
        		Matcher matcher = pattern.matcher((CharSequence) returnedValue);
        		matcher.find();
        		
        		returnedValue = Double.valueOf( matcher.group(1) );
        		
                reporter.logToAllure(String.format("%n %s: the parsed price is: %s",
                        callerMethodName, returnedValue));
                break;
                

            default:
                reporter.logToAllure("We somehow reached defaut in the switch case");
                break;
        } // switch case


        reporter.logMethodDuration();
        return returnedValue;
    }//seleniumAction


    /**
     * isElementFluentlyPresent verifies presence of element with the help of
     * {@link fluentWait}, ignoring NoSuchElementException
     *
     * @param byxPathElement is the elements xPath
     *                       {@link By}
     * @return result boolean Mar07RJR
     */
    public Boolean isElementFluentlyPresent(final String elementLocator) {
    	
        /**
         * TimeoutException ignored so no exception is thrown at `withTimeout` Mar15RJR */
		 FluentWait<WebDriver> fluentWait = new FluentWait<>( driver )
                .withMessage("\n fluentWait exception: Couldnt find element \n")
                .withTimeout(12, SECONDS)
                .pollingEvery(100, TimeUnit.MILLISECONDS)
                .ignoring(NoSuchElementException.class)
                .ignoring(TimeoutException.class);

         
         Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {

            @Override
            /** implements the apply interface Mar07RJR */
            public Boolean apply( WebDriver someDriver) {
            	
                String elementxPath = getLocator(elementLocator);
                
                boolean isElementPresent = false;
                
				if ( ! someDriver.findElements(By.xpath(elementxPath)).isEmpty() ) { //works May11RJR
					isElementPresent = true;
				return isElementPresent;
				} //if statement
				
				if ( someDriver.findElements(By.xpath(elementxPath)).size() != 1 ) {
					isElementPresent = false;
				return isElementPresent;
				} //if statement
                
                
                return isElementPresent;
                
                

            }//apply
        };//function


        boolean fluentWaitTryCatch = true;
        try {
        	fluentWait.until(function);
        } catch (org.openqa.selenium.TimeoutException e) {
        	
        	reporter.logToAllure("fluentWait: a TimeoutException Thrown\n" + e);
        	fluentWaitTryCatch = false;
        } //try catch of 
        
        return fluentWaitTryCatch;
        
        
    }//isElementFluentlyPresent



@Override
	/** {@link hardAssert} Dec11RJR */
	@Step("{2}")
	public <T> void hardAssert( final T actualResult, final T expectedResult, final String name) {
		final boolean resultFlag = actualResult.equals(expectedResult);
		
		reporter.logToAllure( String.format(
				"%n %n Is Test Case Successful?: %s %n Title: %s %n actualResult: %s %n expectedResult: %s %n %n",
				resultFlag, name, actualResult.toString(), expectedResult.toString() ));
		
		Assert.assertEquals(actualResult, expectedResult, "\n " + name + "\n");
	}//hardAssert
	
	

	/** sets the variable for signInFlag Jan02RJR */
	public void setSignInFlag() {
		signInFlag = true;
	}//setSignInFlag
	
	/** gets the Flow_signIn sequence state Jan01RJR */
	public Object getSignIn( final UtilityContainer utility ) {
		new Flow_SignIn(utility).signIn();
		setSignInFlag();
		return this;
	}//getSignIn
	
	
	/** gets the signInState and handles null situations Jan01RJR */
	public Object getSignInState() {
		if (signInFlag == null) {
			signInFlag = false;
		}//if-statement
		return signInFlag;
	}//getSignInState
	
	
	
	/**
	 * isElementPresent checks presence of element on the screen Feb22RJR
	 * 
	 * @param elementLocator
	 *            is the locator of the target element. Feb22RJR
	 * @return {boolean}
	 */
	public boolean isElementPresent( final String elementLocator ) {
		elementxPath = this.getLocator( elementLocator );

		reporter.logToAllure(String.format("%n isElementPresent: %s %n xPath: %s %n", elementLocator, elementxPath));
		return driver.findElements(By.xpath(elementxPath)).size() == 1;
	}// isElementPresent

	
	//state
	/**
	 * isUserOnHomeScreen answers if user is located on homescreen or not by checking
	 * if the element <homeTab_HelloText> is present
	 * 
	 * @return bool {@link boolean}
	 */
	public boolean isUserOnHomeScreen() {
		return isElementPresent( "homeTab_HelloText" );
	}//isUserOnHomeScreen
	
	
	//control
	/** assertUserIsOnHomeScreen asserts whether a user is on homeScreen
	 * if not than exceptionHandling happens Feb22RJR */
	public void assertUserIsOnHomeScreen() {
		
		if ( !isUserOnHomeScreen() ) {
			reporter.logToAllure(
				"\n assertUserIsOnHomeScreen: If you are reading this message that means"
						+ "\n were not in the HomeScreen, either the"
						+ "\n signIn_flow failed sequence faild or "
						+ "\n a previous test failed assertUserIsOnHomeScreen "
						+ "\n returned 'false' exceptionHandling starts now A1");
			
			reporter.logToAllure("assertUserIsOnHomeScreen: Starting Error handling"
					+ "\n - clicking the native back button one time Apr08RJR A2 ");
					getDriver().navigate().back();
					
					
					reporter.logToAllure(" assertUserIsOnHomeScreen: "
							+ "\n will call assertUserIsOnHomeScreen again"
							+ "after hitting the native navigate back button"
							+ "- and check again if we are home?? A3");
						
			
			} else {
		reporter.loggerNoAllureDebug(String.format(
				"\n `assertUserIsOnHomeScreen` "
				+ "- user is located on home screen. =) \n" ));
			} //if else statement that was originally assert true Mar16RJR
	}//verifyUserOnHomeScreen
	
	
	//state
	/** the getTestDataItem returns the value of the TestData Key called by user 
	 * @param itemName String
	 * 			the name of the item were calling
	 * @return itemValue String
	 * 			the value of the item were calling Feb22RJR*/
	public String getTestDataItem( final String itemName ) {
		final String itemValue = testDataMap.get( itemName );
		return itemValue;
	}//getTestDataItem
	
	
	
	@Override
	/** fastSwipe will make the fast swipe from the element in the direction
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param direction String
	 *            is the direction of swipe
	 */
	public void fastSwipe( final String elementLocator, final String swipeDirection) {
		
		swipe(elementLocator, 0, swipeDirection);
		
	}
	
	@Override
	/** slowSwipe will make the slow swipe from the element in the direction
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param direction String
	 *            is the direction of swipe
	 */
	public void slowSwipe( final String elementLocator, final String swipeDirection) {
		
		swipe(elementLocator, 500, swipeDirection);
		
	}
	
	 /** swipe will make the swipe from the element in the direction
	 *            with wait moveWait
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param direction String
	 *            is the direction of swipe
	 * @param moveWait is time of swipe in milliseconds                    
	 */
	public void swipe ( final String elementLocator, int moveWait, final String direction ) {
		TouchAction action = new TouchAction((PerformsTouchActions) driver);
		elementxPath = this.getLocator( elementLocator );
		element = driver.findElement(By.xpath( elementxPath ));
		
		// center of element
		Point elementCenter = ((AndroidElement) element).getCenter();
		int elementCenterX = elementCenter.getX();
		int elementCenterY = elementCenter.getY();
		
		// view size
		Dimension dimensions = driver.manage().window().getSize();
		int viewWidth = dimensions.getWidth();
		int viewHeight = dimensions.getHeight();
		
		//X-axis offset
		int moveX = 0;
		
		//Y-axis offset
		int moveY = 0;
		
		// length of swipe
		int lengthSwipe = 70;
		
		switch (direction) {
		case "left":			
			if (elementCenterX < lengthSwipe + 10)
				moveX = 10 - elementCenterX;
			else			
				moveX = -lengthSwipe;
	
			break;
			 
		case "right":			
			
			if (viewWidth - elementCenterX < lengthSwipe + 10)
				moveX = viewHeight - elementCenterX - 10;
			else			
				moveX = lengthSwipe;			
			
			break;
		
		case "up":
			
			if (elementCenterY < lengthSwipe + 10)
				moveY = 10 - elementCenterY;
			else			
				moveY = -lengthSwipe;
	
			break;
		
		case "down":
			
			if (viewHeight - elementCenterY < lengthSwipe + 10)
				moveY = viewHeight - elementCenterY - 10;
			else			
				moveY = lengthSwipe;			
			
			break;
			
		default:
			
			reporter.logToAllure("We somehow reached defaut in the switch case");
			
			break;
			
		} // switch case
		
		reporter.logToAllure(String.format( "%n swipe %s %n from the element %s %n during %s msec", direction, elementxPath, moveWait));
		
		if (moveWait == 0)
			
			//fast swipe
			action.press(element).moveTo(moveX, moveY).release().perform();
		
		else		
		
			//slow swipe
			action.press(element).waitAction(Duration.ofMillis(moveWait)).moveTo(moveX, moveY).release().perform();
		
	}
	
	
	 /** fastScroll will make the scroll the element which has class
	 * android.widget.FrameLayout, android.support.v4.widget.DrawerLayout or android.widget.LinearLayout 
	 * in the direction 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen.
	 * @param direction String
	 *            is the direction of scroll (horizontal or vertical)                 
	 */
	public void fastScroll ( final String elementLocator, final String direction ) {
		
		TouchAction action = new TouchAction((PerformsTouchActions) driver);
		elementxPath = this.getLocator( elementLocator );
		element = driver.findElement(By.xpath( elementxPath ));
		
		// center of scrolling element
		Point elementCenter = ((AndroidElement) element).getCenter();
		int elementCenterX = elementCenter.getX();
		int elementCenterY = elementCenter.getY();
		
		// size of scrolling element
		Dimension dimensions = element.getSize();
		int viewWidth = dimensions.getWidth();
		int viewHeight = dimensions.getHeight();
		
		switch (direction) {
		case "vertical":
			
			reporter.logToAllure(String.format( "%n vertical scroll of element %s", elementxPath));

			action.press(elementCenterX, (int) (viewHeight * 0.8)).moveTo(0, (int) (viewHeight * -0.6)).release().perform();
			
			break;
		case "horizontal":
			
			reporter.logToAllure(String.format( "%n horizontal scroll of element %s", elementxPath));
	
			action.press((int) (viewWidth * 0.8), elementCenterY).moveTo((int) (viewWidth * -0.6), 0).release().perform();
			
			break;
			
        default:
			
			reporter.logToAllure("We somehow reached defaut in the switch case");
			
			break;
			
		}
		
	}
	
	
	/**
	 * tapVariableElement will tap the specific UI element that contains a preassigned text
	 * 
	 * @param elementLocator String
	 *            is the locator of an element on the page or screen. Dec19RJR
	 * @param text String
	 *        the text contained in the element
	 *        
	 * @return true if tap was success
	 * @return false if tap was failure      
	 *        
	 */
	public boolean tapVarElement( final String  elementLocator, final String text ) {
		
		elementxPath = this.getLocator( elementLocator );
		elementxPath = elementxPath.replace("]", "and contains(@text,'" + text + "')]");
		
		FluentWait<WebDriver> fluentWait = new FluentWait<>( driver )
				.withMessage(" We couldnt find the element with fluentWait and now there is an exception ")
				.withTimeout(12, SECONDS)
		        .pollingEvery(100, TimeUnit.MILLISECONDS)
		        .ignoring(NoSuchElementException.class)
		        .ignoring(TimeoutException.class);
		
        try {
	    	fluentWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(elementxPath)));  
	    }  
	    
        catch (Exception e) {  
	    	reporter.logToAllure(String.format("%n We couldnt find the element: %s %n contained text: %s", elementLocator, text));
	    	return false;  
	    }   
        
        if (driver.findElements(By.xpath(elementxPath)).size() == 1) {
            
        	reporter.logToAllure(String.format( "%n tapElement: %s %n xPath: %s", elementLocator, elementxPath)); 
        	
        	element = driver.findElement(By.xpath( elementxPath ));        
        	new TouchAction((MobileDriver<?>) driver).tap(element).perform();    	
        
        	return true;
        }
        
        else {
			reporter.logToAllure(String.format(
					"%n We couldnt tap the element: %s %n contained text: %s %n because element isn't unique!!!",
					elementLocator, text));
			return false;
		}
	
	}
	

} //UtilityContainer
