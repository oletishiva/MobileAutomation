package grocery.core;
/** @author Roma Jacob Remedy Dec02RJR */
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import grocery.utils.Reporter;

/**
 * TestListener implements {@link ITestListener} capturing and responding to
 * Test Results Dec12RJR
 */
public class TestListener implements ITestListener {
	
    /**
     * ** reporter used for logging of messages and screenshots
     */
    public transient Reporter reporter = Reporter.getreporterInstance();

	@Override
    public void onTestStart(final ITestResult result) {
        reporter.logToAllure( "on test method " +  getTestMethodName(result) + " starts");
    }
    @Override
    public void onTestSuccess(final ITestResult result) {
        reporter.logToAllure( "on test method " + getTestMethodName(result) + " success");
    }
    @Override
    public void onTestFailure(final ITestResult result) {
        reporter.logToAllure( "on test method " + getTestMethodName(result) + " failure");
    }
    @Override
    public void onTestSkipped(final ITestResult result) {
        reporter.logToAllure( "test method " + getTestMethodName(result) + " skipped");
    }
    @Override
    public void onTestFailedButWithinSuccessPercentage(final ITestResult result) {
        reporter.logToAllure( "test failed but within success % " + getTestMethodName(result));
    }
    @Override
    public void onStart(final ITestContext context) {
        reporter.logToAllure( "on start of test " + context.getName());
    }
    @Override
    public void onFinish(final ITestContext context) {
        reporter.logToAllure( "on finish of test " + context.getName());
    }
    private static String getTestMethodName(final ITestResult result) {
        return result.getMethod().getConstructorOrMethod().getName();
    }
}
