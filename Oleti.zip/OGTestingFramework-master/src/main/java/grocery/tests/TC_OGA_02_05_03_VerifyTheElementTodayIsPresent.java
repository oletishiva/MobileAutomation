package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

//doesn't work

public class TC_OGA_02_05_03_VerifyTheElementTodayIsPresent extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_05_03_VerifyTheElementTodayIsPresent(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}
	

	@Override
	/** {@link performTest} */
	public void perform() {
		

		flowSignIn();
						
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
			
		
		
		//getText Today
		
		//utility.getDriver().findElements(By.xpath(utility.getLocator("reserveATime_WeekDayNameText")));
		
		actualResult = utility.getTextElement("reserveATime_TodayText");
		
		expectedResult = "Today";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
	
		
	}// performTest



} // class

