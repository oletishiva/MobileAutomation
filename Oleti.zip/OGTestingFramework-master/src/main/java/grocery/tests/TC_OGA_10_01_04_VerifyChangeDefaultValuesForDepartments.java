package grocery.tests;

import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_10_01_04_VerifyChangeDefaultValuesForDepartments extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_10_01_04_VerifyChangeDefaultValuesForDepartments(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}


	public void cleanFavoritesList() {
		//clear Favorites List (for next test cases)
		utility.tapElement("homeTab_ItemFavoriteToggle");
	}

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
	
		flowSignIn();
						
				
		//click <actionBar_SearchButton>
		utility.tapElement("actionBar_SearchButton");
				
		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		//click <Text>
		utility.tapElement( "search_Text" );

		//click on <homeTab_ItemFavoriteToggle> on left item
		utility.tapElement("homeTab_ItemFavoriteToggle");

		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		//click Favorites Tab
		utility.tapElement("actionBar_FavoritesTab");

		//click Sort & Filter
		utility.tapElement("favoritesTab_SortAndFilterButton");
		
		//click <sortFilterMenu_DepartmentsDropDown>
		utility.tapElement("sortFilterMenu_DepartmentsDropDown");
				
	
		//getText count_Items_FilterDepartments 
		actualResult = utility.getTextElement("sortFilterMenu_DepartmentsQuantityOfItemsInDepartmentText");
		expectedResult = "1";
		Assert.assertEquals(actualResult, expectedResult);
		
		//click <sortFilterMenu_DepartmentsRadioButton>
		utility.tapElement("sortFilterMenu_DepartmentsRadioButton");

		
		//click <sortFilterMenu_DropDownOptionText>
		//utility.tapElement("sortFilterMenu_DepartmentsDropDownOptionText");
		
		//getText count_Items_Favorites_List from <favoritesTab_ItemCountText>
		actualResult = utility.getTextElement("favoritesTab_ItemCountText");
		expectedResult = "1 Item";
		Assert.assertEquals(actualResult, expectedResult);
		
		//click Sort & Filter
		utility.tapElement("favoritesTab_SortAndFilterButton");
		
		//getText new_FilterDepartments from <sortFilterMenu_DropDownOptionText>
		actualResult = utility.getTextElement("sortFilterMenu_DepartmentsCurrentlySelectedText");
		expectedResult = "Beverages";
		Assert.assertEquals(actualResult, expectedResult);
		
		//click Clear
		utility.tapElement("sortFilterMenu_ClearButton");
		
		utility.clickNativeAndroidBackButton();
 
		cleanFavoritesList();
		
		clickHomeTab();

		
	}// performTest

} // class
