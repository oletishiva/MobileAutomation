package grocery.tests;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_08_01_13_VerifyPricesOnItemsDetailsScreenThroughFavoritesList extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_08_01_13_VerifyPricesOnItemsDetailsScreenThroughFavoritesList(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}

	public void cleanFavoritesList() {
		//clean Favorites list
		utility.tapElement( "homeTab_ItemFavoriteToggle" );
	}

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
										
		
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );

		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemBeef" ) );

		//click <Text>
		utility.tapElement( "search_Text" );

		//click on <homeTab_ItemFavoriteToggle>
		utility.tapElement( "homeTab_ItemFavoriteToggle" );

		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );

		//click Favorites Tab
		utility.tapElement( "actionBar_FavoritesTab" );
			
		//getPriceTotalHomeScreen
		final String itemPriceTotal = utility.getTextElement( "homeTab_ItemPriceText" );
		final String regex = "^"
				 + "(?:\\$)?"
				 + "(?:\\s*)?"
				 + "((?:\\d{1,3})(?:\\,)?(?:\\d{3})?(?:\\.)?(\\d{0,2})?)"
				 + "$";
		final Pattern patt = Pattern.compile(regex);
		Matcher matcher = patt.matcher(itemPriceTotal);
		matcher.find();
		
		final double itemPriceTotalDouble = Double.parseDouble(matcher.group(1).replaceAll("[$.]", ""));
		final double itemPriceTotalSelected = new BigDecimal((100.0 * itemPriceTotalDouble) / 100).setScale(2,RoundingMode.HALF_UP).doubleValue();
				
		utility.reporter.logToAllure( "Total price is " + itemPriceTotalSelected); 
				

		//click on top left item's image
		utility.tapElement( "homeTab_ImageView" );

		//getText priceTotalImageScreen
		final String priceTotalImageScreen =  utility.getTextElement( "itemDetails_PriceTotal" );
		
		matcher = patt.matcher(priceTotalImageScreen);
		matcher.find();
		
		final double priceTotalImageScreenDouble = Double.parseDouble(matcher.group(1).replaceAll("[$.]", ""));
		final double priceTotalImageScreenSelected = new BigDecimal((100.0 * priceTotalImageScreenDouble) / 100).setScale(2,RoundingMode.HALF_UP).doubleValue();
		
		utility.reporter.logToAllure( "Total price on the Image Screen is " + priceTotalImageScreenSelected); 
		
		Assert.assertEquals(itemPriceTotalSelected, priceTotalImageScreenSelected);
		
				
		utility.tapElement( "global_ToolbarNavigateToPreviousScreenArrow " );
		
		cleanFavoritesList();
		
		clickHomeTab();

		
		
	}// performTest

} // class
