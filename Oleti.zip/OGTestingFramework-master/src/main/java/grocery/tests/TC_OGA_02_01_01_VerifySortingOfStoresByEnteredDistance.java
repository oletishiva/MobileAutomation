package grocery.tests;


import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

// Verify Stores Displayed Per Radius


public class TC_OGA_02_01_01_VerifySortingOfStoresByEnteredDistance extends AbstractTestCase {


	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */


	public TC_OGA_02_01_01_VerifySortingOfStoresByEnteredDistance(final UtilityContainer utility) {
		super(utility);
	}//constructor



	@Override
	public void perform() throws Exception {

		flowSignIn();


		utility.tapElement("homeTab_StorePicker");
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
		

		//Feb02RJR


        //click <reserveATime_PickUpLocationPicker>
		utility.tapElement( "reserveATime_PickUpLocationPicker" );
		

		
		//send keys <pickupTab_SearchField>  
		//utility.sendKeysElement( "pickupTab_SearchField" , "80211" );
		
		//tap <pickupTab_SearchField>  
		//doesn't work, because we can't use Android native keyboard
		//utility.tapElement( "pickupTab_SearchField" );
		
	
		//getText
		actualResult = utility.getTextElement("pickupTab_SortedByDistanceText").replaceAll("\\d{5}", "");
			
		expectedResult = utility.getTextElement("pickupTab_SortedByDistanceText").replaceAll("\\d{5}", "");
		
	
		utility.hardAssert(actualResult, expectedResult, name);

		
		
		utility.clickNativeAndroidBackButton();
		
		utility.clickNativeAndroidBackButton();


		
	} // performTest
} // class

