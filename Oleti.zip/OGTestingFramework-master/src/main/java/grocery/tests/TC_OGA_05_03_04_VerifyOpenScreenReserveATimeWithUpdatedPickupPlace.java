package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_05_03_04_VerifyOpenScreenReserveATimeWithUpdatedPickupPlace extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_05_03_04_VerifyOpenScreenReserveATimeWithUpdatedPickupPlace(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	@Override
	/** {@link performTest} */
	public void perform() {
		
		//flowSignIn sequence
		flowSignIn();		
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);

		//tap search button
		utility.tapElement( "actionBar_SearchButton");
				
		//sendKeys <water> to <search field>
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemVaccum" ) );
				
		//tap search 
		utility.tapElement( "search_Text" );
				
		//tap <ADD> button
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton"); 
		
		//tap quantity button to open drop down menu
		utility.tapElement( "global_AmountQuantityOfItemButton"); 

		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
		
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
				
		//tap <max amount>
		utility.tapElement( "global_AmountDropDownMenuLastElement");
				
		//tap <ComeBack>
		utility.tapElement( "global_ToolBarArrowBackButton");
				
		//tap <Cart>
		utility.tapElement( "actionBar_CartButton");
				
		//tap <Checkout>
		utility.tapElement( "cart_CheckoutButton");
		
		//Check PaymentMethodView
		if (!utility.getDriver().findElements(By.xpath("//*[contains(@text,'Payment Method')]")).isEmpty()) {
			
			//tap <payment_FirstPaymentMethod>
			utility.tapElement( "payment_FirstPaymentMethod");
			
			//tap <Continue>
			utility.tapElement( "cart_CheckoutButton");

		}
		
		else
			
			//tap <Continue>
		    utility.tapElement( "cart_ContinueButton");
		
		//Check PaymentMethodView
		if (!utility.getDriver().findElements(By.xpath("//*[contains(@text,'Payment Method')]")).isEmpty()) {
			
			//tap <payment_FirstPaymentMethod>
			utility.tapElement( "payment_FirstPaymentMethod");
			
			//tap <Continue>
			utility.tapElement( "cart_CheckoutButton");

		}
				
		//Check snackbar
		if (!utility.getDriver().findElements(By.xpath("//*[starts-with(@text,'What if an item isn')]")).isEmpty()) {
					
			//close snackbar
			utility.tapElement( "reviewOrder_AllowSubstitutesCheckBox");
				    
			//tap <PickupPicker>
			utility.tapElement( "reviewOrder_PickupPicker");

		}
				
		//tap <DayAfterTomorrow>
		utility.tapElement( "reserveATime_PickupDay");
				
	    utility.fastSwipe( "reserveATime_TodayText", "up");
	    
        //tap <3PM-4PM> 
        utility.tapElement( "reserveATime_LastSlotTime");
				
		//tap <Continue>
		utility.tapElement( "cart_ContinueButton");
		
		//Check PaymentMethodView
		if (!utility.getDriver().findElements(By.xpath("//*[contains(@text,'Payment Method')]")).isEmpty()) {
			
			//tap <payment_FirstPaymentMethod>
			utility.tapElement( "payment_FirstPaymentMethod");
			
			//tap <Continue>
			utility.tapElement( "cart_CheckoutButton");

		}
				
		//Check snackbar
		if (!utility.getDriver().findElements(By.xpath("//*[starts-with(@text,'What if an item isn')]")).isEmpty())
					
			//close snackbar
			utility.tapElement( "reviewOrder_AllowSubstitutesCheckBox");
				    
		//tap <PickupPicker>
		utility.tapElement( "reviewOrder_PickupPicker");
		
		//getText <reserveATime_ReserveStoreAddressText>
		 final String oldPickupAddress = utility.getTextElement("reserveATime_ReserveStoreAddressText");
		
		//tap <PickUpLocationPicker>
		utility.tapElement( "reserveATime_PickUpLocationPicker");
		
		//tap <pickupTab_FrameLayout1>
		utility.tapElement("pickupTab_SecondAddress");
		
		//tap <pickupTab_ChangeButton>
		utility.tapElement("pickupTab_ChangeButton");
		
		//getText <reserveATime_ReserveStoreAddressText>
		 final String newPickupAddress = utility.getTextElement("reserveATime_ReserveStoreAddressText");
		
		 expectedResult = "Pickup Address was changed";
		
		//compare old and new pickup addresses
		if (oldPickupAddress == newPickupAddress)
			actualResult = "Pickup Address wasn't changed";
		else
			actualResult = "Pickup Address was changed";
		
		//compare expected and actual results
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();

		
	}// performTest


	
}// class

