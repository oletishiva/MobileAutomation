package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_05_01_02_VerifyOpenScreenReviewOrder extends AbstractTestCase {

	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_05_01_02_VerifyOpenScreenReviewOrder(final UtilityContainer utility) {
		super(utility);
	}//constructor
	


	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		
		flowSignIn();
		
																									
		
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );

		//sendKeys "Bissell powerforce" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemVaccum" ) );
		
		//click <Text>
		utility.tapElement( "search_Text" );
			
		//click <global_AddVeryFirstItemOnTopLeftButton> of top right item
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );

		//click <global_IncreaseByOneItemButton> 
		utility.tapElement( "global_IncreaseByOneItemButton" );
		
		//tap <global_ToolBarArrowBackButton>		
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		//click <cart_ActionCartView>
		utility.tapElement( "actionBar_CartButton" );
		
		//click <cart_CheckoutButton>
		utility.tapElement( "cart_CheckoutButton" );
		
		
		
		//click <cart_ContinueButton>
		utility.tapElement( "cart_ContinueButton" );
		
		//sometimes appeared
		//click OK to close snackbar message	
		//utility.tapElement("reserveATime_AlertOkButton");
		
		//sometimes appeared
		//click <reserveATime_SlotTimeText>
		//utility.tapElement("reserveATime_SlotTimeText");
		
		utility.tapElement("payment_TitleText");
		
		utility.tapElement("payment_FirstPaymentMethod");
		
	
		
		//sometimes appeared
		//click <payment_ContinueButton>
		utility.tapElement( "payment_ContinueButton" );
		
		//getText <reviewOrder_TitleText>
		actualResult = utility.getTextElement("reviewOrder_TitleText");
		expectedResult = "Review Order";
		utility.hardAssert(actualResult, expectedResult, name);
		
		
		utility.clickNativeAndroidBackButton();
		
		//click OK to close snackbar message	
		utility.tapElement("reserveATime_AlertOkButton");
				
		
		
		utility.clickNativeAndroidBackButton();

		
	}// performTest


} // class
