package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_01_07_01_05_ErrorMessagesDuringCreateAccount extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_01_07_01_05_ErrorMessagesDuringCreateAccount(final UtilityContainer utility) {
		super(utility);
	}//constructor

	@Override
	/** {@link performTest} */
	public void perform() {
        
		//tap <SkipButon>
		utility.tapElement( "skipScreen_SkipButton");
		
		//sendKeys <80211> to <zipCode_EnterZipCodeField>
		utility.sendKeysElement("zipCode_EnterZipCodeField", "80211");
		
		//tap <zipCode_GoButton>
		utility.tapElement( "zipCode_GoButton"); 
		
		//tap <signIn_CreateAccountButton>
		utility.tapElement( "signIn_CreateAccountButton");
		
		//sendKeys <FIRSTNAME> to <createAccount_FirstNameField>
		utility.sendKeysElement("createAccount_FirstNameField", "FIRSTNAME");
		
		//sendKeys <LASTNAME> to <createAccount_LastNameField>
		utility.sendKeysElement("createAccount_LastNameField", "LASTNAME");
		
		//sendKeys <previously registered EMAIL> to <createAccount_EmailField>
		utility.sendKeysElement("createAccount_EmailField", "walmartsunnyvale2@gmail.com");
		
		//sendKeys <1234567> to <createAccount_PasswordField>
		utility.sendKeysElement("createAccount_PasswordField", "1234567");
		
		//tap <createAcccount_CreateAccountButton>
		utility.tapElement( "createAcccount_CreateAccountButton");
		
		//getText <createAccount_ErrorMessageText>
		actualResult = utility.getTextElement("createAccount_ErrorMessageText");
		
		expectedResult = "The email address you entered is associated with a Walmart.com account. Please sign in or use another email address.";
		//"Walmart account already exists"
		
		//compare expected and actual results
		utility.hardAssert(actualResult, expectedResult, name);
		
		
	}// performTest
}// class

