package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_06_04_VerifyCopyrights extends AbstractTestCase {
	

	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_07_06_04_VerifyCopyrights(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //only for automation
		utility.tapElement( "actionBar_HomeTab" );
	}

	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_AboutWalmartGroceryButton>
			
		
		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down"); 
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
		
		
        utility.tapElement("navigationDrawer_AboutWalmartGroceryButton");
        
        
      
		//getText <navigationDrawer_AboutCopyrightsText>
		actualResult = utility.getTextElement("navigationDrawer_AboutCopyrightsText");
		expectedResult = "Walmart Stores, Inc All Rights Reserved";
		utility.hardAssert(actualResult, expectedResult, name);

		
		utility.clickNativeAndroidBackButton();
       	
		clickHomeTab();

	}// performTest
} // class

