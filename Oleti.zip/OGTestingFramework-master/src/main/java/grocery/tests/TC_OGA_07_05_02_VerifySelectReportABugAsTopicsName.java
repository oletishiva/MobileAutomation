package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_05_02_VerifySelectReportABugAsTopicsName extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_05_02_VerifySelectReportABugAsTopicsName(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_SendAppFeedbackButton>
		

		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down");
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
		
		utility.tapElement("navigationDrawer_SendAppFeedbackButton");
		
		//click <submitFeedback_TopicSubtitleText>
		utility.tapElement("submitFeedback_TopicSubtitleText");
		
		//select <submitFeedback_TopicDropDownOptions1>
		utility.tapElement("submitFeedback_TopicDropDownOptions1");
		
		
		
		//getText "Report a bug" as Topic's name
 		actualResult = utility.getTextElement("submitFeedback_TopicSubtitleText");
		expectedResult = "Report a bug";
		utility.hardAssert(actualResult, expectedResult, name);
		
		
		
		utility.clickNativeAndroidBackButton();
				
		
	}// performTest
} // class
