package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_02_02_VerifyReturnToNavigationDrawerFromHome extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_02_02_VerifyReturnToNavigationDrawerFromHome(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		

		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Home
		utility.tapElement("navigationDrawer_HomeButton");
		
		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		
		//getText <navigationDrawer_HomeButton>
		actualResult = utility.getTextElement("navigationDrawer_HomeButton");
		expectedResult = "Home";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
		
		clickHomeTab();

		
	}// performTest

} // class
