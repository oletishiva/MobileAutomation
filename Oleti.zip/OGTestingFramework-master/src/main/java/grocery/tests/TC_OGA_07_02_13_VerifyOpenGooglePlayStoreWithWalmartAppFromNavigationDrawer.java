package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_02_13_VerifyOpenGooglePlayStoreWithWalmartAppFromNavigationDrawer extends AbstractTestCase {
	

	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_02_13_VerifyOpenGooglePlayStoreWithWalmartAppFromNavigationDrawer(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		

		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Walmart App
		       

		
		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down");
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
        
        utility.tapElement("navigationDrawer_WalmartAppButton");
		
		
		//getText <navigationDrawer_WalmartAppTitleText>
		actualResult = utility.getTextElement("navigationDrawer_WalmartAppTitleText");
		expectedResult = "Walmart";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
 
		
	}// performTest
} // class
