package grocery.tests;

import java.util.concurrent.TimeUnit;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_04_02_07_VerifyErrorMessageForIncorrectInformationInTheSearch extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_04_02_07_VerifyErrorMessageForIncorrectInformationInTheSearch(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		//flowSignIn sequence
		flowSignIn();
		
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);

		//tap search button
		utility.tapElement( "actionBar_SearchButton");
				
		//sendKeys <qwertyui> to <search field>
		utility.sendKeysElement("search_SearchSrcField", "qwertyui\n");
				
		//tap search field <qwertyui>
		//utility.tapElement( "search_Text" );
		
		//get text from message
		actualResult = utility.getTextElement("seach_NoResultsText");
		
		expectedResult = "We found no results for qwertyui";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);
		
		//click back button  //only for automation
				utility.getDriver().navigate().back();
		
	}// performTest
}// class
