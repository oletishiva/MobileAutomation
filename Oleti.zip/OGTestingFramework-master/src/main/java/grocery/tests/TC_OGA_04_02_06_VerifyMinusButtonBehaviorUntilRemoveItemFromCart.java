package grocery.tests;

import org.openqa.selenium.By;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_04_02_06_VerifyMinusButtonBehaviorUntilRemoveItemFromCart extends AbstractTestCase {
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	public TC_OGA_04_02_06_VerifyMinusButtonBehaviorUntilRemoveItemFromCart(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
			
		//getText old_cart_count
		initialQuantity = Integer.valueOf( utility.getTextElement( "actionBar_CartItemCountButton" ) );
		
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );
		
		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		//click <Text>
		utility.tapElement( "search_Text" );
		
		

		//tap <global_AddVeryFirstItemOnTopLeftButton> 		
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
		
		
		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );

		//getText new_cart_count
		actualResult = Integer.valueOf( 
		utility.getTextElement( "actionBar_CartItemCountButton" ) );

		expectedResult = initialQuantity + 1;
		utility.hardAssert(actualResult, expectedResult, name);

		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );
		
		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		
		//click <Text>
		utility.tapElement( "search_Text" );

		
		//tap <global_SubstractByOneItemButton> 
		utility.tapElement( "global_SubstractByOneItemButton" );
		
				
		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );

		
		//getText new_cart_count_after_click_minus
		actualResult = Integer.valueOf( 
		utility.getTextElement( "actionBar_CartItemCountButton" ) );

		expectedResult = initialQuantity;
		utility.hardAssert(actualResult, expectedResult, name);
		
				
		
	}// performTest

} // class
