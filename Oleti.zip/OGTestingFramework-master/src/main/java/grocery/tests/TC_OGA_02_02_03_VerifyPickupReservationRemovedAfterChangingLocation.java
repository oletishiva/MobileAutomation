package grocery.tests;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;

public class TC_OGA_02_02_03_VerifyPickupReservationRemovedAfterChangingLocation extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	public MobileElement element;
	
	public TC_OGA_02_02_03_VerifyPickupReservationRemovedAfterChangingLocation(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}


	
	@Override
	/** {@link performTest} */
	public void perform() throws ParseException {
		
		//flowSignIn sequence
		flowSignIn();
        
		// // comment one this test case will fail some of the time because you
		// cannot guarantee the existance of reserveButton Feb05RJR
		//tap <homeTab_ReserveButton>
		
		//decrease implicitly wait
 
		
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
		
		
		//tap <reserveATime_PickUpLocationPicker>
		utility.tapElement("reserveATime_PickUpLocationPicker"); 
		
		//tap <pickupTab_AnotherStoreAddress>
		utility.tapElement("pickupTab_AnotherStoreAddress");



		//getText Tomorrow day	
		final Calendar calendar = Calendar.getInstance(); 
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		final Date tomorrow = calendar.getTime();

		final SimpleDateFormat formatter = new SimpleDateFormat("EEE, MMM dd");
		final String tomorrowDate = formatter.format(tomorrow);
		
		
		if (!utility.getDriver().findElements(By.xpath(utility.getLocator("reserveATime_NoAvailabilityTodayText"))).isEmpty()) {
			
			//getText <reserveATime_NoAvailabilityTodayText>
			actualResult = utility.getTextElement("reserveATime_NoAvailabilityTodayText");
			
			expectedResult = "There is no Pickup availability today. The next opening is on " + tomorrowDate;
			utility.hardAssert(actualResult, expectedResult, name);
			

		}
		

		else {		
			//tap <DayAfterTomorrow>
			utility.tapElement( "reserveATime_PickupDay");
			
			utility.fastSwipe( "reserveATime_TodayText", "up");
		
					
			//tap <3PM-4PM> 
			utility.tapElement( "reserveATime_LastSlotTime");
					

		
		} 
		
		utility.clickNativeAndroidBackButton();
		
	}// performTest


}// class

