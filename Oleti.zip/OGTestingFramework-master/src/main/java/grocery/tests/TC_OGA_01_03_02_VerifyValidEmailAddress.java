package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_01_03_02_VerifyValidEmailAddress extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	
	public FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!")
			.withTimeout(3, TimeUnit.SECONDS)
	        .pollingEvery(10, TimeUnit.MILLISECONDS)
	        .ignoring(NoSuchElementException.class);
	
	public TC_OGA_01_03_02_VerifyValidEmailAddress(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	public boolean isElementPresent(final By locator) {
	    try {
	    	
	    	fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	    	
	        return true;  
	    
	    }  
	    
	    catch(Exception e) { 
	       
	    	return false;
	    	
	    }
	 
	 }
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		
		utility.tapElement( "skipScreen_SkipButton" );

		utility.sendKeysElement( "zipCode_EnterZipCodeField" , "80211" );
		utility.tapElement( "zipCode_GoButton" );
		utility.tapElement( "signIn_SignInButton" ); 

		//sendKeys <TESTUSER> to <signIn_EmailField>
		utility.sendKeysElement( "signIn_EmailField" , "walmartsunnyvale@gmail.com" );

		utility.tapElement( "signIn_EmailField" );




		//sendKeys <hhhhhhh> to <signIn_PasswordField>
		utility.sendKeysElement( "signIn_PasswordField" , "hhhhhhh" );



		utility.tapElement( "signIn_PasswordField" );

		utility.reporter.logToAllure( "Please manually click Sign In button !!");
		utility.reporter.logToAllure( "Please manually click Sign In button !!");
		utility.reporter.logToAllure( "Please manually click Sign In button !!");
		utility.reporter.logToAllure( "Please manually click Sign In button !!");


		try {
		Thread.sleep(5000);
		} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
		//get text from message
		actualResult = utility.getTextElement("signIn_ErrorMessageText");
		
		expectedResult = "Your email address and password do not match.";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);	
		
		//tap <signIn_ForgotPasswordButton>
		utility.tapElement( "signIn_ForgotPasswordButton");
		
		//sendKeys <walmartsunnyvale@gmail.com> to <signIn_VerificationEmailAddressField>
		utility.sendKeysElement( "signIn_VerificationEmailAddressField" , "walmartsunnyvale@gmail.com\n" );
		
		if (isElementPresent(By.xpath("//*[contains(@text,'We sent a verification code to:')]")))
		
			actualResult = "We sent a verification code to:";
		
		else
			
			actualResult = "";			
		
		expectedResult = "We sent a verification code to:";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);	
		
		utility.clickNativeAndroidBackButton();

		
	}// performTest

}// class


