package grocery.tests;

import org.openqa.selenium.By;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_04_02_05_VerifyPlusButtonBehaviorUntilMaxAmount  extends AbstractTestCase {
	
		
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_04_02_05_VerifyPlusButtonBehaviorUntilMaxAmount(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
								
		
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );
		
		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		//click <Text>
		utility.tapElement( "search_Text" );

		//tap <global_AddVeryFirstItemOnTopLeftButton> 		
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
		
		//tap quantity button to open drop down menu
		utility.tapElement( "global_AmountQuantityOfItemButton"); 

				
		//scroll down to <max amount>		
		
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
		
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
				
		//get <max amount>
		 //int max = utility.getTextElement( "global_AmountDropDownMenuLastElement");

		 initialQuantity = Integer.valueOf( utility.getTextElement( "global_AmountDropDownMenuLastElement" ) );
		 System.out.println( initialQuantity);
		 		 
		 utility.fastSwipe( "global_AmountDropDownMenuFirstElement", "down");
		 
		 //close drop down menu
		 utility.tapElement( "global_AmountDropDownMenuFirstElement" );
		
		for (int i = 0; i <= initialQuantity; i++) {
				
		//tap <global_IncreaseByOneItemButton> 
		utility.tapElement( "global_IncreaseByOneItemButton" );
				
		}
		
				
		//added assert that button plus not enabled
		//getAttribute("enabled")
		final String buttonPlus = utility.getDriver().findElement(By.xpath(utility.getLocator("global_IncreaseByOneItemButton"))).getAttribute("enabled");
		utility.reporter.logToAllure( buttonPlus);
		Assert.assertEquals("false", buttonPlus);
		
		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );

	
		
		
		
		
		utility.clickNativeAndroidBackButton();	
		
	}// performTest

} // class

