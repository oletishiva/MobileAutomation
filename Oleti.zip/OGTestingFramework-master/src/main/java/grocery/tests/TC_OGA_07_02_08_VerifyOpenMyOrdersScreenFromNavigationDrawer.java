package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_02_08_VerifyOpenMyOrdersScreenFromNavigationDrawer extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_02_08_VerifyOpenMyOrdersScreenFromNavigationDrawer(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
		
		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_YourOrdersButton>
		utility.tapElement("navigationDrawer_YourOrdersButton");
		
		
		//getText <navigationDrawer_YourOrdersTitleText>
		actualResult = utility.getTextElement("navigationDrawer_YourOrdersTitleText");
		expectedResult = "Your Orders";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();

		
	}// performTest

} // class
