package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_05_10_04_VerifyUserCanSeeYourOrdersHistory extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!")
			.withTimeout(3, TimeUnit.SECONDS)
	        .pollingEvery(10, TimeUnit.MILLISECONDS)
	        .ignoring(NoSuchElementException.class);
	
	public TC_OGA_05_10_04_VerifyUserCanSeeYourOrdersHistory(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public boolean isElementPresent(final By locator) {
	    
		try {
	    	
	    	fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	    	
	        return true;  
	    
	    }  
	    
	    catch(Exception e) { 
	       
	    	return false;
	    	
	    }
	 
	 }
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		//flowSignIn sequence
		flowSignIn();
		
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);

		//tap <actionBar_NavigationDrawerButton>
		utility.tapElement( "actionBar_NavigationDrawerButton");
		
		//tap <navigationDrawer_YourOrdersButton>
		utility.tapElement( "navigationDrawer_YourOrdersButton" );

		if (isElementPresent(By.xpath("//*[contains(@resource-id,'com.walmart.grocery:id/title')]")))

			//get text from message
			actualResult = "Your orders list is present.";
		
		else
			
			actualResult = "Your orders list isn't present.";
			
		expectedResult = "Your orders list is present.";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);
		
		//click back button  //only for automation
				utility.getDriver().navigate().back();
		
	}// performTest
	
}// class