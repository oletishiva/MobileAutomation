package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_11_02_01_VerifyRemoveItemsFromFavoritesWhichAddedFromHomePage extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_11_02_01_VerifyRemoveItemsFromFavoritesWhichAddedFromHomePage(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
							
		//click Favorites Tab
		utility.tapElement("actionBar_FavoritesTab");

		
		clickHomeTab();
		
		
		//click on <homeTab_ItemFavoriteToggle> on left item
		utility.tapElement("homeTab_ItemFavoriteToggle");
		
		//click Favorites Tab
		utility.tapElement("actionBar_FavoritesTab");
		
		
		//click on <homeTab_ItemFavoriteToggle> on left item
		utility.tapElement("homeTab_ItemFavoriteToggle");
		//Thread.sleep(5000);
		
		
		//getText <favoritesTab_GetStartedText>
		actualResult = utility.getTextElement("favoritesTab_GetStartedText");
		expectedResult = "Save some faves";
		utility.hardAssert(actualResult, expectedResult, name);

		
		clickHomeTab();

		
		
	}// performTest

} // class
