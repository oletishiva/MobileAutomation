package grocery.tests;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_05_07_VerifyAttachScreenshotToSubmitFeedback extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_05_07_VerifyAttachScreenshotToSubmitFeedback(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		

		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_SendAppFeedbackButton>
		
		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down");
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
		
		utility.tapElement("navigationDrawer_SendAppFeedbackButton");
		
		
		//click <submitFeedback_ScreenshotsAddButton>
		utility.tapElement("submitFeedback_ScreenshotsAddButton");
		
						
		//click <submitFeedback_ImageView>
 		utility.tapElement("submitFeedback_ImageView");
	
		
		//getAttribute("enabled")
 		actualResult = utility.getDriver().findElement(By.xpath(utility.getLocator("submitFeedback_RemoveScreenshotButton"))).getAttribute("enabled");
 		expectedResult = "true";
		utility.hardAssert(actualResult, expectedResult, name);
			
		utility.clickNativeAndroidBackButton();
		
		//click Discard Button
		utility.tapElement("submitFeedback_DiscardButton");
		
		
	}// performTest

} // class
