package grocery.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import org.openqa.selenium.By;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;
import io.appium.java_client.MobileElement;


public class TC_OGA_02_01_02_VerifyAscendingOrder extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_01_02_VerifyAscendingOrder(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}

	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
	
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
	
		

		//click <reserveATime_PickUpLocationPicker>
		utility.tapElement( "reserveATime_PickUpLocationPicker" );
		
		//send keys <pickupTab_SearchField>  
		//utility.sendKeysElement( "pickupTab_SearchField" , "80211" );
		
		//tap <pickupTab_SearchField>  
		//doesn't work, because we can't use Android native keyboard
		//utility.tapElement( "pickupTab_SearchField" );


		//check Sort
		final List elements = utility.getDriver().findElements(By.xpath("//android.widget.TextView[2]"));
	
		
		 
				 
		for (int i = 0; i < elements.size(); i++) {
			   
		final MobileElement defaultDistance = (MobileElement) elements.get(i);  
		final List<String> defDist = new ArrayList<>();
		defDist.add(defaultDistance.getText()); 
		System.out.println( defDist);
				
		
		final MobileElement sortedDistance = (MobileElement) elements.get(i);	  
		final List<String> sortedDist = new ArrayList<>();
		sortedDist.add(sortedDistance.getText());
		Collections.sort(sortedDist, String.CASE_INSENSITIVE_ORDER);
		System.out.println( sortedDist);
				  
		Assert.assertEquals(defDist, sortedDist); 
		
		} // for loop
		

		utility.clickNativeAndroidBackButton();
		
	
		utility.clickNativeAndroidBackButton();

		

	}// performTest


} // class

