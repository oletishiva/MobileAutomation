package grocery.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;
import io.appium.java_client.MobileElement;



public class TC_OGA_02_08_01_VerifyAllTimesForPickupAreDisplayed extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_02_08_01_VerifyAllTimesForPickupAreDisplayed(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}
	
	

	@Override
	/** {@link performTest} */
	public void perform() {
		

		flowSignIn();
							
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
	
	
		//click <reserveATime_NoAvailabilityTodayText>
		
		
		//getText Available Pickup time
		utility.tapElement( "reserveATime_AvailablePickupSlotsText" );
		
		//getText "reserveATime_SlotTimeText"	
		
		final List<WebElement> elements = utility.getDriver().findElements(By.xpath(utility.getLocator("reserveATime_SlotTimeText")));	
	    		
		final List<String> pickupTimeToday = new ArrayList<>();
		final List<String> sortedPickupTimeToday = new ArrayList<>();
				 
		for (int i = 0; i < elements.size(); i++) {
			   
		final MobileElement pickupTimeTodaySTR = (MobileElement) elements.get(i);  
		pickupTimeToday.add(pickupTimeTodaySTR.getText()); 
		System.out.println( pickupTimeToday);
		
		final MobileElement sortedpickupTimeTodaySTR = (MobileElement) elements.get(i);	  
		sortedPickupTimeToday.add(sortedpickupTimeTodaySTR.getText());
		Collections.sort(sortedPickupTimeToday, String.CASE_INSENSITIVE_ORDER);
		System.out.println( sortedPickupTimeToday);
				  
		Assert.assertEquals(pickupTimeToday, sortedPickupTimeToday); 
	
	    
	}
		
		//we need to scroll to element and take list of these values, not only to scroll. 
		
		
		utility.fastSwipe( "reserveATime_AvailablePickupSlotsText", "up");
		
		final List<WebElement> elements2 = utility.getDriver().findElements(By.xpath(utility.getLocator("reserveATime_SlotTimeText")));	
		final List<String> pickupTimeToday2 = new ArrayList<>();
		final List<String> sortedPickupTimeToday2 = new ArrayList<>();
				 
		for (int i = 0; i < elements2.size(); i++) {
			   
		final MobileElement pickupTimeTodaySTR = (MobileElement) elements2.get(i);  
		
		pickupTimeToday2.add(pickupTimeTodaySTR.getText()); 
		System.out.println( pickupTimeToday2);
		
		final MobileElement sortedpickupTimeTodaySTR = (MobileElement) elements2.get(i);	  
		
			sortedPickupTimeToday2.add(sortedpickupTimeTodaySTR.getText());
		Collections.sort(sortedPickupTimeToday, String.CASE_INSENSITIVE_ORDER);
		System.out.println( sortedPickupTimeToday2);
				  
		Assert.assertEquals(pickupTimeToday2, sortedPickupTimeToday2); 
	
	    
	}
	
		
		utility.clickNativeAndroidBackButton();
		
	}// performTest


} // class
