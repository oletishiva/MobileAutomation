package grocery.tests;
import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_08_01_02_VerifyDetailsOnItemDetailsScreenUsingSearch extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_08_01_02_VerifyDetailsOnItemDetailsScreenUsingSearch(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();

		utility.tapElement( "actionBar_SearchButton");
		
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemBeef" ) );

		
		utility.tapElement( "search_Text"); //why am i doing this? Jan03RJR
		
		//click on top left item's image
		utility.tapElement( "homeTab_ImageView");
		
		//getText details
			
		utility.tapElement( "itemDetails_PriceTotal");
		utility.fastSwipe( "itemDetails_PriceTotal", "up");
		
		actualResult = utility.getTextElement("itemDetails_DetailsTitle");
		expectedResult = "Details";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
 
		utility.clickNativeAndroidBackButton();
 
		
	}// performTest

}// class

