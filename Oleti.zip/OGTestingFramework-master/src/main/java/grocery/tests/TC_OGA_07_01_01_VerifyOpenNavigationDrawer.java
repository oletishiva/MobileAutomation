package grocery.tests;

import java.util.concurrent.TimeUnit;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_01_01_VerifyOpenNavigationDrawer extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_01_01_VerifyOpenNavigationDrawer(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
		utility.getDriver().manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
		

		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//getText <navigationDrawer_HomeButton>
		actualResult = utility.getTextElement("navigationDrawer_HomeButton");
		expectedResult = "Home";
		//utility.hardAssert(actualResult, expectedResult, name);
		
		//click Home
		utility.tapElement("navigationDrawer_HomeButton");
		
		//clickHomeTab();
	
 
		
	}// performTest

} // class
