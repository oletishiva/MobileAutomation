package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_08_01_19_VerifyShowMoreButtonBehavior extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_08_01_19_VerifyShowMoreButtonBehavior(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();

		utility.tapElement( "actionBar_SearchButton");
		
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		utility.tapElement( "search_Text"); 
		
		//click on top left item's image
		utility.tapElement( "homeTab_ImageView");
		
		
		//fastSwipe <itemDetails_DetailsTitle>
				
		utility.tapElement( "itemDetails_PriceTotal");
		utility.fastSwipe( "itemDetails_PriceTotal", "up");
		
		
		//tap <itemDetails_ShowMoreLessButton>
		utility.tapElement( "itemDetails_ShowMoreLessButton" );
		
		//getText <itemDetails_ShowMoreLessButton>
		
		
		actualResult = utility.getTextElement("itemDetails_ShowMoreLessButton");
		expectedResult = "Show less";
		utility.hardAssert(actualResult, expectedResult, name);

		
		utility.clickNativeAndroidBackButton();
       	
		utility.clickNativeAndroidBackButton();
 

		
	}// performTest
} // class
