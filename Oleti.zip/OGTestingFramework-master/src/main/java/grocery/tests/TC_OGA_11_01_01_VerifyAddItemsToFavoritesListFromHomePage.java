package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_11_01_01_VerifyAddItemsToFavoritesListFromHomePage extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_11_01_01_VerifyAddItemsToFavoritesListFromHomePage(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}

	public void cleanFavoritesList() {
		//clear Favorites List (for next test cases)
		utility.tapElement("homeTab_ItemFavoriteToggle");
	}

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
	
		flowSignIn();
						
						
		//click Favorites Tab
		utility.tapElement("actionBar_FavoritesTab");
		
		//getText <favoritesTab_GetStartedText>
		actualResult = utility.getTextElement("favoritesTab_GetStartedText");
		expectedResult = "Save some faves";
		utility.hardAssert(actualResult, expectedResult, name);
		
		clickHomeTab();
		
		//click on <homeTab_ItemFavoriteToggle> on left item
		utility.tapElement("homeTab_ItemFavoriteToggle");
		
		//click Favorites Tab
		utility.tapElement("actionBar_FavoritesTab");
		//Thread.sleep(5000);
		
		//getText new_favoritesList_count from <favoritesTab_ItemCountText>
		actualResult = utility.getTextElement("favoritesTab_ItemCountText");
		expectedResult = utility.getTextElement("favoritesTab_ItemCountText");
		utility.hardAssert(actualResult, expectedResult, name);

		cleanFavoritesList();

		clickHomeTab();

		
		
	}// performTest

} // class
