package grocery.tests;
import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

/** @author Roma Jacob Remedy May14RJR */
public class TC_OGA_04_01_04_VerifyRemoveItemsFromCartUsingRemove extends AbstractTestCase {
	
		
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_04_01_04_VerifyRemoveItemsFromCartUsingRemove(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
				
	
		initialQuantity = Integer.valueOf( utility.getTextElement( "actionBar_CartItemCountButton" ) );
						
		utility.tapElement( "actionBar_SearchButton" );
		
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemBeef" ) );
		
		utility.tapElement( "search_Text" );
				
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
			
		utility.tapElement( "global_AmountQuantityOfItemButton" );
		
		utility.tapElement( "global_AmountDropDownMenuLastElement" );
		
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		actualResult = Integer.valueOf( 
				utility.getTextElement( "actionBar_CartItemCountButton" ) );

		expectedResult = initialQuantity +3;
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.tapElement( "actionBar_CartButton" );
		
		utility.tapElement( "cart_QuantityView" );

		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
		
		utility.tapElement( "homeTab_RemoveDropDownMenu" );
		Thread.sleep(5000);
		
		actualResult = Integer.valueOf( 
				utility.getTextElement( "cart_ActionBarCartCountText" ) );

		expectedResult = initialQuantity;
		utility.hardAssert(actualResult, expectedResult, name);

		utility.clickNativeAndroidBackButton();

	}// performTest

} // class

