package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_08_01_03_VerifyNutritionFactsUsingSearch extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_08_01_03_VerifyNutritionFactsUsingSearch(final UtilityContainer utility) {
		super(utility);
	}//constructor

	
	@Override
	/** {@link performTest} */
	public void perform() throws InterruptedException {
		
		flowSignIn();
												
		
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );
				
		//sendKeys "bread" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemBread" ) );

		//click <Text>
		utility.tapElement( "search_Text" );

		//click on top left item's image
		utility.tapElement( "homeTab_ImageView" );

		//getText Nutrition facts 
		utility.tapElement( "itemDetails_PriceTotal");
		utility.fastSwipe( "itemDetails_PriceTotal", "up");
       
		utility.tapElement( "itemDetails_NutritionTab" );
		//Thread.sleep(5000);
       
	
		actualResult = utility.getTextElement("itemDetails_NutritionFacts");
		expectedResult = "Nutrition Facts";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
 
		utility.clickNativeAndroidBackButton();
 

		
	}// performTest

}// class

