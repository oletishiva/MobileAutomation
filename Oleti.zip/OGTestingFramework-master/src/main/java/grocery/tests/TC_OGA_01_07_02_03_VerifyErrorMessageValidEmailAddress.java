package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_01_07_02_03_VerifyErrorMessageValidEmailAddress extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_01_07_02_03_VerifyErrorMessageValidEmailAddress(final UtilityContainer utility) {
		super(utility);
	}//constructor

	@Override
	/** {@link performTest} */
	public void perform() {
        
		//tap <SkipButon>
		utility.tapElement( "skipScreen_SkipButton" );
		
		//sendKeys <ZIP80211> to <zipCode_EnterZipCodeField>
		utility.sendKeysElement( "zipCode_EnterZipCodeField" , "80211" );//comment li8ne
		
		//tap <zipCode_GoButton>
		utility.tapElement( "zipCode_GoButton" );//comment li8ne
		
		//tap <signIn_SignInButton>
		utility.tapElement( "signIn_SignInButton" ); //remove line old build Dec24RJR
		
		//sendKeys <hhhh> to <signIn_EmailField>	
		utility.sendKeysElement( "signIn_EmailField" , "hhhh" );
	
		//tap <signIn_SignInButton>
		utility.tapElement( "signIn_EmailField" );
	
		//sendKeys <walmart> to <signIn_PasswordField>
		utility.sendKeysElement( "signIn_PasswordField" , "walmart" );
		
		//tap <signIn_PasswordField>
		utility.tapElement( "signIn_PasswordField" );
		
		//getText <createAccount_ErrorMessageText>
		actualResult = utility.getTextElement("signIn_ErrorMessageText");
		
		expectedResult = "Please enter a valid email address";
		
		//compare expected and actual results
		utility.hardAssert(actualResult, expectedResult, name);
		
		
	}// performTest
}// class

