package grocery.tests;
import java.io.IOException;
import java.text.ParseException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import grocery.core.UtilityContainer;
import grocery.tests.snap.TC_SNAP_04_01_VerifyAddEBTfood_itemsToCartUsingSearch;
import grocery.tests.snap.TC_SNAP_04_02_VerifyAddEBTcash_itemsToCartUsingSearch;
import grocery.tests.snap.TC_SNAP_04_03_VerifyAddAlcohol_itemsToCartUsingSearch;
import grocery.tests.snap.TC_SNAP_05_01_VerifyCheckOutActive;
import grocery.tests.snap.TC_SNAP_05_02_VerifyCheckOutNonactive;
import grocery.tests.snap.TC_SNAP_06_01_VerifyIntermittentPageInReviewOrderMethodsBeforeUserIsRedirectedToPINadToShowEBTFoodAuthAmount;
import grocery.tests.snap.TC_SNAP_06_02_VerifyIntermittentPageInReviewOrderBeforeUserIsRedirectedToPINadToShowEBTCashAuthAmount;
import grocery.tests.snap.TC_SNAP_06_03_IntermittentPageInPaymentMethodsBeforeUserIsRedirectedToPINadWithoutAmountForBalanceCheckonFoodAndCash;
import grocery.tests.snap.TC_SNAP_07_01_DisplayOrderTotalAmountInPaymentMethodAsPerUXForEBTeligibleStoreLongVersion;
import grocery.tests.snap.TC_SNAP_07_02_DisplayOrderTotalAmountInPaymentMethodAsPerUXForEBTeligibleStoreShortVersion;
import grocery.tests.snap.TC_SNAP_08_01_UserCannotPayUsingEBTNo_CC;
import grocery.tests.snap.TC_SNAP_08_02_CartHasEBTEligibleItems;
import grocery.tests.snap.TC_SNAP_08_03_CartHasEBTRestrictedItems;
import grocery.tests.snap.TC_SNAP_08_04_UserIsOnNonEBTStoreRequiringCCToPayForTheOrder;
import grocery.tests.snap.TC_SNAP_08_05_UserHasNoEBTandNoCCOnFile;
import grocery.tests.snap.TC_SNAP_08_06_EBTIsON_NoCCToPayButHasAmountRemaining;
import grocery.tests.snap.TC_SNAP_08_07_EBTIsON_NoCCToPayButTheAmountChangeInAmountRemaining;
import grocery.tests.snap.TC_SNAP_08_08_EBTIsONOrderIsNotFoodEligibleWeDontKnowIfUserHasEBTCashBenefit;
import grocery.tests.snap.TC_SNAP_08_09_InputErrorsCashMaxError;
import grocery.tests.snap.TC_SNAP_08_10_InputErrorsFoodMaxError;
import grocery.tests.snap.TC_SNAP_09_01_DisplayAlertMessageEBTRestrictedItemsWithEBTEligibleItemsNoCC;
import grocery.tests.snap.TC_SNAP_09_02_DisplayAlertMessageBelowCCSectionEBTRestrictedItemsWithEBTEligibleItemsNoCC;
import grocery.tests.snap.TC_SNAP_10_01_UserShownAcceptsEBTLogoOnPickupStoreListOnLocationSlider;
import grocery.tests.snap.TC_SNAP_10_02_UserShownAcceptsEBTLogoOnPickupStoreList;
import grocery.tests.snap.TC_SNAP_10_03_UserShownAcceptsEBTCopyOnPickupStoreList;
import grocery.tests.snap.TC_SNAP_10_04_UserNotShownLogoOrCopyIfDoesNotAcceptEBT;
import grocery.tests.snap.TC_SNAP_11_01_UserIsAbleToSeeEBTCardEndingInPaymentMethodsSection;
import grocery.tests.snap.TC_SNAP_11_02_UserIsAbleToSeeMutliplePaymentMethodsInPaymentMethodsSectionCCPlusEBT;
import grocery.tests.snap.TC_SNAP_11_03_EBTPaymentsAppliedToOrderToShowUpBelowOrderTotal;
import grocery.tests.snap.TC_SNAP_12_01_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalGreater;
import grocery.tests.snap.TC_SNAP_12_02_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalEqualsZero;
import grocery.tests.snap.TC_SNAP_13_01_VerifyMessageWhenOrderTotalAmountHigherThanPreviousOrderTotal;
import grocery.tests.snap.TC_SNAP_14_01_VerifyRemovePromoFromPaymentsMethodsScreen;
import grocery.tests.snap.TC_SNAP_14_02_01_ApplyingPromo;
import grocery.tests.snap.TC_SNAP_14_02_OrderWithPromotions;
import grocery.tests.snap.TC_SNAP_14_03_01_PromoAddedOnPaymentDetailsInPaymentMethods;
import grocery.tests.snap.TC_SNAP_14_03_EBTPaymentPromoAdjustments;
import grocery.tests.snap.TC_SNAP_14_04_01_PromoAddedOnPaymentDetailsInReviewOrder;
import grocery.tests.snap.TC_SNAP_14_04_EBTPaymentAdjustmentsCCPromo;
import grocery.utils.Flows;
import io.appium.java_client.AppiumDriver;
@Listeners(grocery.core.TestListener.class)

/** @author Roma Jacob Remedy May14RJR */
/** _ProjectNameTestSuite lists each IndividualTestCases in RemedyFramework */
public class _ProjNameTestSuite {
	
	/** {@link UtilityContainer} Dec12RJR */
	private transient UtilityContainer utility;
	
	/** flows {@link Flows} contains all the common user flows Apr11RJR */
	Flows flows = Flows.getFlowsInstance();
	
	/**
	 * getUtility returns the reference of utility Dec06RJR
	 * @return an instance of {@link UtilityContainer}
	 */
	public UtilityContainer getUtility() {
		return utility;
	}//getUtility
	
	
	/**
	 * BeforeSuite loads critical components necessary for IndividualTestCases
	 * execution Dec06RJR
	 */
	@BeforeSuite (alwaysRun = true)
	public void setUp() {
		
		
		try {
		utility = new UtilityContainer();
		} catch (Exception e) {
			utility.reporter.logToAllure(
					String.format("%n Exception happened in %s \n The Exception was: %s \n",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e));
		}//try-catch
		
		/**
		 * initializing the flag of previous test ending to true this is as part of the
		 * error handling sequence May10RJR
		 */
		utility.ogaStateUtil.setOgFlag( "flag_DidTestCaseFinish", true);
	}//setUp method
	
	

	/**
	 * {@link BeforeMethod} performs relevant operations/settings at the beginning
	 * of each Test Case May14RJR
	 */
	@BeforeMethod (alwaysRun = true)
	public void beforeMethod() {
		flows.flowCleanCart( utility );
		
		if ( ! utility.ogaStateUtil.getOgFlagState("flag_DidTestCaseFinish") ) {
			
			System.err.println(
					"the previous test case did not finish correctly and we need to do some error handling here!! ");
			
		}//if statement
		
		
		//setting the flag_DidTestCaseFinish to false
		utility.ogaStateUtil.setOgFlag( "flag_DidTestCaseFinish", false);
		//setting the flag_ErrorHandlingActivated to false
		utility.ogaStateUtil.setOgFlag( "flag_ErrorHandlingActivated", false);
	} //beforeTest
	
	

	/**
	 * {@link AfterMethod} performs relevant operations at the end of each TestCase
	 * Method May14RJR
	 */
	@AfterMethod(alwaysRun = true)
	public void afterMethod() {

		utility.reporter.logToAllure( "In AfterTest ");
		// if error Handler did not work set to true
		utility.ogaStateUtil.setOgFlag("flag_DidTestCaseFinish", true);

		utility.reporter.logToAllure( "checking if flagerrorhandling"
				+ "is false to check flow clean cart ");
		if ( ! utility.ogaStateUtil.getOgFlagState("flag_ErrorHandlingActivated")) {
			flows.flowCleanCart(utility);
		} // if statement

	}// afterTest

	
	/** cleanUp method closes the driver at the end of the test suite 
	 * @throws IOException */
	@AfterClass(alwaysRun = true)
	public void cleanUp() throws IOException {

		if(utility.getDriver() !=null) {
			
			utility.reporter.logToAllure(
					String.format("%n AfterClass tearDown %n%n"));
			
			utility.reporter.logToAllure(
					String.format("%n getting logcat from device.."));
			utility.reporter.captureLog( ( ( AppiumDriver<?> ) utility.getDriver() ) );
			
//			close(utility.getDriver() );
			
		}//if statement

	}// cleanUp method
	
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential1111" , "Prod"} , priority=101, enabled = false)
	/**some comment*/
	public void tC_OGA_01_06_CreateAccount() {
		new TC_OGA_01_06_CreateAccount(utility).perform();
	}//tc_ProjName_01_06_CreateAccountTest
	
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_01_FlowSignInFunctionalityTesting", "Prod"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_01_SignInAsAnExistingUser() {
		new TC_OGA_01_01_SignInAsAnExistingUser(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest
	
	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential" , "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_01_01_VerifySortingOfStoresByEnteredDistance() throws Exception {
		new TC_OGA_02_01_01_VerifySortingOfStoresByEnteredDistance(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_01_02_VerifyAscendingOrder() {
		new TC_OGA_02_01_02_VerifyAscendingOrder(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_02_02_VerifyThatUserIsAbleToChangeStore() throws Exception {
		new TC_OGA_02_02_02_VerifyThatUserIsAbleToChangeStore(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_02_03_VerifyPickupReservationRemovedAfterChangingLocation() throws ParseException {
		new TC_OGA_02_02_03_VerifyPickupReservationRemovedAfterChangingLocation(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_03_VerifyInfoAboutPickupService() {
		new TC_OGA_02_03_VerifyInfoAboutPickupService(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialDoesntworkyet"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_04_VerifyInfoAboutDeliveryService() {
		new TC_OGA_02_04_VerifyInfoAboutDeliveryService(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_05_01_VerifyCorrectDaysAreDisplayedInReserveView() throws Exception {
		new TC_OGA_02_05_01_VerifyCorrectDaysAreDisplayedInReserveView(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_05_02_VerifyCorrectDatesDisplayedInReserveView() throws Exception {
		new TC_OGA_02_05_02_VerifyCorrectDatesDisplayedInReserveView(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_05_03_VerifyTheElementTodayIsPresent() throws Exception {
		new TC_OGA_02_05_03_VerifyTheElementTodayIsPresent(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = { "SequentialNo", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_05_04_VerifyMessageNoPickupAvailabilityTodayIsPresent() throws Exception {
		new TC_OGA_02_05_04_VerifyMessageNoPickupAvailabilityTodayIsPresent(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = { "Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_05_05_VerifyErrorMessageYourOrderIsBelowTheMinimum() throws Exception {
		new TC_OGA_02_05_05_VerifyErrorMessageYourOrderIsBelowTheMinimum(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_06_01_VerifyTodaysDate() throws Exception {
		new TC_OGA_02_06_01_VerifyTodaysDate(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_06_02_VerifyTodaysDatePlusOne() throws Exception {
		new TC_OGA_02_06_02_VerifyTodaysDatePlusOne(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_02_ReserveATimeScreenFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_02_08_01_VerifyAllTimesForPickupAreDisplayed() {
		new TC_OGA_02_08_01_VerifyAllTimesForPickupAreDisplayed(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here"), 
	@Test(groups = {"Sequential", "Suite_OGA_03_AdditionalPickupFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_03_01_01_VerifyAllAvailableTimeForPickupDisplayed() {
		new TC_OGA_03_01_01_VerifyAllAvailableTimeForPickupDisplayed(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_03_AdditionalPickupFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_03_01_02_VerifyAscendingOrderFromTopToBottomOfDisplayedPickupTimes() {
		new TC_OGA_03_01_02_VerifyAscendingOrderFromTopToBottomOfDisplayedPickupTimes(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_03_AdditionalPickupFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_03_01_03_VerifyInformationAboutFREEPickup() {
		new TC_OGA_03_01_03_VerifyInformationAboutFREEPickup(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"
			, "tC_OGA_04_01_01_VerifyAddItemsInTheCart"} , priority=411, enabled = true)
	/**some comment*/
	public void tC_OGA_04_01_01_VerifyAddItemsInTheCart() throws Exception {
		new TC_OGA_04_01_01_VerifySignedInUserIsAbleToAddItemsToCartThroughSearch(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"
			, "tC_OGA_04_01_02_VerifyThatTotalPriceIncreasedForPriceOfAddedItem"} , priority=412, enabled = true)
	/**some comment*/
	public void tC_OGA_04_01_02_VerifyThatTotalPriceIncreasedForPriceOfAddedItem() throws Exception {
		new TC_OGA_04_01_02_VerifyThatTotalPriceIncreasedForPriceOfAddedItem(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"
			,"tC_OGA_04_01_04_VerifyRemoveItemsFromCartUsingRemove"} , priority=414, enabled = true)
	/**some comment*/
	public void tC_OGA_04_01_04_VerifyRemoveItemsFromCartUsingRemove() throws Exception {
		new TC_OGA_04_01_04_VerifyRemoveItemsFromCartUsingRemove(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialDoesntworkyet", "Prod"} , priority=313, enabled = true)
		/**some comment*/
	public void tC_OGA_04_02_01_VerifyAddItemsToTheCartUsingSearch() throws Exception {
		new TC_OGA_04_02_01_VerifyAddItemsToTheCartUsingSearch(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_02_02_VerifyAddItemsToTheCartViaDepartments() throws Exception {
		new TC_OGA_04_02_02_VerifyAddItemsToTheCartViaDepartments(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_02_04_VerifyAddItemsToTheCartViaFavoritesList() throws Exception {
		new TC_OGA_04_02_04_VerifyAddItemsToTheCartViaFavoritesList(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_02_05_VerifyPlusButtonBehaviorUntilMaxAmount() throws Exception {
		new TC_OGA_04_02_05_VerifyPlusButtonBehaviorUntilMaxAmount(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_02_06_VerifyMinusButtonBehaviorUntilRemoveItemFromCart() throws Exception {
		new TC_OGA_04_02_06_VerifyMinusButtonBehaviorUntilRemoveItemFromCart(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_02_07_VerifyErrorMessageForIncorrectInformationInTheSearch() throws Exception {
		new TC_OGA_04_02_07_VerifyErrorMessageForIncorrectInformationInTheSearch(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_03_01_VerifyIncreaseDecreaseItemsInTheCart() throws Exception {
		new TC_OGA_04_03_01_VerifyIncreaseDecreaseItemsInTheCart(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	//**some comment*/
	public void tC_OGA_04_03_02_VerifyCheckoutButtonIsNotEnabled() throws Exception {
		new TC_OGA_04_03_02_VerifyCheckoutButtonIsNotEnabled(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_04_CoreFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	//**some comment*/
	public void tC_OGA_04_03_03_VerifyCheckoutButtonIsEnabled() throws Exception {
		new TC_OGA_04_03_03_VerifyCheckoutButtonIsEnabled(utility).perform();
	}//IndividualTestCase2
	
	
	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo","Suite_OGA_05_PreCheckOutFunctionalityTestingNo", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_05_01_02_VerifyOpenScreenReviewOrder() throws Exception {
		new TC_OGA_05_01_02_VerifyOpenScreenReviewOrder(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo","Suite_OGA_05_PreCheckOutFunctionalityTestingNo", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_05_03_03_VerifyMessageChangingStoreAfterTapChange() throws Exception {
		new TC_OGA_05_03_03_VerifyMessageChangingStoreAfterTapChange(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_05_PreCheckOutFunctionalityTestingNo", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_05_03_04_VerifyOpenScreenReserveATimeWithUpdatedPickupPlace() throws Exception {
		new TC_OGA_05_03_04_VerifyOpenScreenReserveATimeWithUpdatedPickupPlace(utility).perform();
	}//IndividualTestCase2
	
	
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential",  "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_01_01_VerifyOpenNavigationDrawer() throws Exception {
		new TC_OGA_07_01_01_VerifyOpenNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential",   "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_01_VerifyOpenHomeScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_01_VerifyOpenHomeScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod" } , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_02_VerifyReturnToNavigationDrawerFromHome() throws Exception {
		new TC_OGA_07_02_02_VerifyReturnToNavigationDrawerFromHome(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_03_VerifyOpenFavoritesScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_03_VerifyOpenFavoritesScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_04_VerifyReturnToNavigationDrawerFromFavorites() throws Exception {
		new TC_OGA_07_02_04_VerifyReturnToNavigationDrawerFromFavorites(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_05_VerifyOpenDepartmentsScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_05_VerifyOpenDepartmentsScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_06_VerifyReturnToNavigationDrawerFromDepartments() throws Exception {
		new TC_OGA_07_02_06_VerifyReturnToNavigationDrawerFromDepartments(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_07_VerifyOpenReserveATimeScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_07_VerifyOpenReserveATimeScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_08_VerifyOpenMyOrdersScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_08_VerifyOpenMyOrdersScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_09_VerifyOpenContactUsScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_09_VerifyOpenContactUsScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_10_VerifyOpenInviteFriendsScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_10_VerifyOpenInviteFriendsScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_11_VerifyOpenSubmitFeedbackScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_11_VerifyOpenSubmitFeedbackScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_12_VerifyOpenAboutScreenFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_12_VerifyOpenAboutScreenFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_02_13_VerifyOpenGooglePlayStoreWithWalmartAppFromNavigationDrawer() throws Exception {
		new TC_OGA_07_02_13_VerifyOpenGooglePlayStoreWithWalmartAppFromNavigationDrawer(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_03_01_VerifyCallToWalmart() throws Exception {
		new TC_OGA_07_03_01_VerifyCallToWalmart(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_03_02_VerifySendEmailToWalmart() throws Exception {
		new TC_OGA_07_03_02_VerifySendEmailToWalmart(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_04_01_VerifyShareToFacebook() throws Exception {
		new TC_OGA_07_04_01_VerifyShareToFacebook(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_04_02_VerifyShareToWhatsApp() throws Exception {
		new TC_OGA_07_04_02_VerifyShareToWhatsApp(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_04_03_VerifyOpenTermsAndConditions() throws Exception {
		new TC_OGA_07_04_03_VerifyOpenTermsAndConditions(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_04_04_VerifyCloseTermsAndConditions() throws Exception {
		new TC_OGA_07_04_04_VerifyCloseTermsAndConditions(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_01_VerifyOpenOptionsForTopic() throws Exception {
		new TC_OGA_07_05_01_VerifyOpenOptionsForTopic(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_02_VerifySelectReportABugAsTopicsName() throws Exception {
		new TC_OGA_07_05_02_VerifySelectReportABugAsTopicsName(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_03_VerifySelectSuggestAFeatureAsTopicsName() throws Exception {
		new TC_OGA_07_05_03_VerifySelectSuggestAFeatureAsTopicsName(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_04_VerifyWriteMessage() throws Exception {
		new TC_OGA_07_05_04_VerifyWriteMessage(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_05_VerifySendMessage() throws Exception {
		new TC_OGA_07_05_05_VerifySendMessage(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_06_VerifyOpenCameraScreenForAddScreenshot() throws Exception {
		new TC_OGA_07_05_06_VerifyOpenCameraScreenForAddScreenshot(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_07_VerifyAttachScreenshotToSubmitFeedback() throws Exception {
		new TC_OGA_07_05_07_VerifyAttachScreenshotToSubmitFeedback(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_08_VerifyRemoveScreenshotFromSubmitFeedback() throws Exception {
		new TC_OGA_07_05_08_VerifyRemoveScreenshotFromSubmitFeedback(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting" , "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_09_VerifyTechnicalDetailsAboutDeviceForSubmitFeedback() throws Exception {
		new TC_OGA_07_05_09_VerifyTechnicalDetailsAboutDeviceForSubmitFeedback(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_10_VerifyTechnicalDetailsAboutAppForSubmitFeedback() throws Exception {
		new TC_OGA_07_05_10_VerifyTechnicalDetailsAboutAppForSubmitFeedback(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_05_11_VerifyUseContactUsFromSubmitFeedbackScreen() throws Exception {
		new TC_OGA_07_05_11_VerifyUseContactUsFromSubmitFeedbackScreen(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_06_01_VerifyTermsOfUse() throws Exception {
		new TC_OGA_07_06_01_VerifyTermsOfUse(utility).perform();
	}//IndividualTestCase2
	

	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_07_NavigationFunctionalityTestingNo", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_06_02_VerifyPrivacyPolicy() throws Exception {
		new TC_OGA_07_06_02_VerifyPrivacyPolicy(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting" ,"Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_06_03_VerifyVersion() throws Exception {
		new TC_OGA_07_06_03_VerifyVersion(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_07_NavigationFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_07_06_04_VerifyCopyrights() throws Exception {
		new TC_OGA_07_06_04_VerifyCopyrights(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Demo", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_01_VerifyPricesOnItemDetailsScreenUsingSearch() throws Exception {
		new TC_OGA_08_01_01_VerifyPricesOnItemDetailsScreenUsingSearch(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Demo", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_02_VerifyDetailsOnItemDetailsScreenUsingSearch() throws Exception {
		new TC_OGA_08_01_02_VerifyDetailsOnItemDetailsScreenUsingSearch(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Demo", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_03_VerifyNutritionFactsUsingSearch() throws InterruptedException {
		new TC_OGA_08_01_03_VerifyNutritionFactsUsingSearch(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_04_VerifyIngredientsUsingSearch() throws InterruptedException {
		new TC_OGA_08_01_04_VerifyIngredientsUsingSearch(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_05_VerifySimilarItemsUsingSearch() throws Exception {
		new TC_OGA_08_01_05_VerifySimilarItemsUsingSearch(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_06_VerifyDisclaimerUsingSearch() throws Exception {
		new TC_OGA_08_01_06_VerifyDisclaimerUsingSearch(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_13_VerifyPricesOnItemsDetailsScreenThroughFavoritesList() throws Exception {
		new TC_OGA_08_01_13_VerifyPricesOnItemsDetailsScreenThroughFavoritesList(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod" } , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_14_VerifyAllDetailsViaFavoritesList() throws Exception {
		new TC_OGA_08_01_14_VerifyAllDetailsViaFavoritesList(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_15_VerifyNutritionFactsViaFavoritesList() throws InterruptedException {
		new TC_OGA_08_01_15_VerifyNutritionFactsViaFavoritesList(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_16_VerifyIngredientsViaFavoritesList() throws Exception {
		new TC_OGA_08_01_16_VerifyIngredientsViaFavoritesList(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_17_VerifySimilarItemsViaFavoritesList() throws Exception {
		new TC_OGA_08_01_17_VerifySimilarItemsViaFavoritesList(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_18_VerifyDisclaimerViaFavoritesList() throws Exception {
		new TC_OGA_08_01_18_VerifyDisclaimerViaFavoritesList(utility).perform();
	}//IndividualTestCase2


	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_19_VerifyShowMoreButtonBehavior() throws Exception {
		new TC_OGA_08_01_19_VerifyShowMoreButtonBehavior(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential" , "Suite_OGA_08_ItemsDetailsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_20_VerifyShowLessButtonBehavior() throws Exception {
		new TC_OGA_08_01_20_VerifyShowLessButtonBehavior(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_10_SortAndFiltersFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_10_01_01_VerifyDefaultValuesForSortFiltersForFavoritesList() throws Exception {
		new TC_OGA_10_01_01_VerifyDefaultValuesForSortFiltersForFavoritesList(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_10_SortAndFiltersFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_10_01_02_VerifyChangeDefaultValuesSortByMostFrequentPurchase() throws Exception {
		new TC_OGA_10_01_02_VerifyChangeDefaultValuesSortByMostFrequentPurchase(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_10_SortAndFiltersFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_10_01_03_VerifyChangeDefaultValuesSortByMostRecentPurchase() throws Exception {
		new TC_OGA_10_01_03_VerifyChangeDefaultValuesSortByMostRecentPurchase(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_10_SortAndFiltersFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_10_01_04_VerifyChangeDefaultValuesForDepartments() throws Exception {
		new TC_OGA_10_01_04_VerifyChangeDefaultValuesForDepartments(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_01_01_VerifyAddItemsToFavoritesListFromHomePage() throws Exception {
		new TC_OGA_11_01_01_VerifyAddItemsToFavoritesListFromHomePage(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_01_02_VerifyAddItemsToFavoritesListUsingSearch() throws Exception {
		new TC_OGA_11_01_02_VerifyAddItemsToFavoritesListUsingSearch(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_01_03_VerifyAddItemsToFavoritesListViaDepartments() throws Exception {
		new TC_OGA_11_01_03_VerifyAddItemsToFavoritesListViaDepartments(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_01_04_VerifyAddItemsToFavoritesListUsingItemImage() throws Exception {
		new TC_OGA_11_01_04_VerifyAddItemsToFavoritesListUsingItemImage(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_02_01_VerifyRemoveItemsFromFavoritesWhichAddedFromHomePage() throws Exception {
		new TC_OGA_11_02_01_VerifyRemoveItemsFromFavoritesWhichAddedFromHomePage(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_02_02_VerifyRemoveItemsFromFavoritesListWhichAddedUsingSearch() throws Exception {
		new TC_OGA_11_02_02_VerifyRemoveItemsFromFavoritesListWhichAddedUsingSearch(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_02_03_VerifyRemoveItemsFromFavoritesListWhichAddedViaDepartments() throws Exception {
		new TC_OGA_11_02_03_VerifyRemoveItemsFromFavoritesListWhichAddedViaDepartments(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"Sequential", "Suite_OGA_11_FavoritesListFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_11_02_04_VerifyRemoveItemsFromFavoritesListWhichAddedUsingItemImage() throws Exception {
		new TC_OGA_11_02_04_VerifyRemoveItemsFromFavoritesListWhichAddedUsingItemImage(utility).perform();
	}//IndividualTestCase2
	

	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_07_VerifyErrorMessageValidCreditCardNumber() throws Exception {
		new TC_OGA_12_03_07_VerifyErrorMessageValidCreditCardNumber(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_08_VerifyErrorMessageValidExpirationDate() throws Exception {
		new TC_OGA_12_03_08_VerifyErrorMessageValidExpirationDate(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_09_VerifyErrorMessageValidSecurityCode() throws Exception {
		new TC_OGA_12_03_09_VerifyErrorMessageValidSecurityCode(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_10_VerifyErrorMessageEnterTheCorrectStateCode() throws Exception {
		new TC_OGA_12_03_10_VerifyErrorMessageEnterTheCorrectState(utility).perform();
	}//IndividualTestCase2
	

	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_11_VerifyErrorMessageEnterTheCorrectPhoneNumber() throws Exception {
		new TC_OGA_12_03_11_VerifyErrorMessageEnterTheCorrectPhoneNumber(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_12_VerifyErrorMessageValidBillingAddress() throws Exception {
		new TC_OGA_12_03_12_VerifyErrorMessageValidBillingAddress(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Suite_OGA_12_PaymentMethodsFunctionalityTesting", "Prod"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_12_03_13_VerifyErrorMessagePaymentCouldNotBeAuthorized() throws Exception {
		new TC_OGA_12_03_13_VerifyErrorMessagePaymentCouldNotBeAuthorized(utility).perform();
	}//IndividualTestCase2

	
	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "tC_SNAP_04_01_VerifyAddEBTfood_itemsToCartUsingSearch", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_04_01_VerifyAddEBTfood_itemsToCartUsingSearch() throws Exception {
		new TC_SNAP_04_01_VerifyAddEBTfood_itemsToCartUsingSearch(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_04_02_VerifyAddEBTcash_itemsToCartUsingSearch() throws Exception {
		new TC_SNAP_04_02_VerifyAddEBTcash_itemsToCartUsingSearch(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_04_03_VerifyAddAlcohol_itemsToCartUsingSearch() throws Exception {
		new TC_SNAP_04_03_VerifyAddAlcohol_itemsToCartUsingSearch(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_05_01_VerifyCheckOutActive() throws Exception {
		new TC_SNAP_05_01_VerifyCheckOutActive(utility).perform();
	}//IndividualTestCase2


	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_05_02_VerifyCheckOutNonactive() throws Exception {
		new TC_SNAP_05_02_VerifyCheckOutNonactive(utility).perform();
	}//IndividualTestCase2

	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_06_01_VerifyIntermittentPageInReviewOrderMethodsBeforeUserIsRedirectedToPINadToShowEBTFoodAuthAmount() throws Exception {
		new TC_SNAP_06_01_VerifyIntermittentPageInReviewOrderMethodsBeforeUserIsRedirectedToPINadToShowEBTFoodAuthAmount(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_06_02_VerifyIntermittentPageInReviewOrderBeforeUserIsRedirectedToPINadToShowEBTCashAuthAmount() throws Exception {
		new TC_SNAP_06_02_VerifyIntermittentPageInReviewOrderBeforeUserIsRedirectedToPINadToShowEBTCashAuthAmount(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_06_03_IntermittentPageInPaymentMethodsBeforeUserIsRedirectedToPINadWithoutAmountForBalanceCheckonFoodAndCash() throws Exception {
		new TC_SNAP_06_03_IntermittentPageInPaymentMethodsBeforeUserIsRedirectedToPINadWithoutAmountForBalanceCheckonFoodAndCash(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_07_01_DisplayOrderTotalAmountInPaymentMethodAsPerUXForEBTeligibleStoreLongVersion() throws Exception {
		new TC_SNAP_07_01_DisplayOrderTotalAmountInPaymentMethodAsPerUXForEBTeligibleStoreLongVersion(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_07_02_DisplayOrderTotalAmountInPaymentMethodAsPerUXForEBTeligibleStoreShortVersion() throws Exception {
		new TC_SNAP_07_02_DisplayOrderTotalAmountInPaymentMethodAsPerUXForEBTeligibleStoreShortVersion(utility).perform();
	}//IndividualTestCase2
	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_01_UserCannotPayUsingEBTNo_CC() throws Exception {
		new TC_SNAP_08_01_UserCannotPayUsingEBTNo_CC(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_02_CartHasEBTEligibleItems() throws Exception {
		new TC_SNAP_08_02_CartHasEBTEligibleItems(utility).perform();
	}//IndividualTestCase2

	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo", "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_03_CartHasEBTRestrictedItems() throws Exception {
		new TC_SNAP_08_03_CartHasEBTRestrictedItems(utility).perform();
	}//IndividualTestCase2

	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_04_UserIsOnNonEBTStoreRequiringCCToPayForTheOrder() throws Exception {
		new TC_SNAP_08_04_UserIsOnNonEBTStoreRequiringCCToPayForTheOrder(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_05_UserHasNoEBTandNoCCOnFile() throws Exception {
		new TC_SNAP_08_05_UserHasNoEBTandNoCCOnFile(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_06_EBTIsON_NoCCToPayButHasAmountRemaining() throws Exception {
		new TC_SNAP_08_06_EBTIsON_NoCCToPayButHasAmountRemaining(utility).perform();
	}//IndividualTestCase2

	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_07_EBTIsON_NoCCToPayButTheAmountChangeInAmountRemaining() throws Exception {
		new TC_SNAP_08_07_EBTIsON_NoCCToPayButTheAmountChangeInAmountRemaining(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_08_EBTIsONOrderIsNotFoodEligibleWeDontKnowIfUserHasEBTCashBenefit() throws Exception {
		new TC_SNAP_08_08_EBTIsONOrderIsNotFoodEligibleWeDontKnowIfUserHasEBTCashBenefit(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_09_InputErrorsCashMaxError() throws Exception {
		new TC_SNAP_08_09_InputErrorsCashMaxError(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_08_10_InputErrorsFoodMaxError() throws Exception {
		new TC_SNAP_08_10_InputErrorsFoodMaxError(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_09_01_DisplayAlertMessageEBTRestrictedItemsWithEBTEligibleItemsNoCC() throws Exception {
		new TC_SNAP_09_01_DisplayAlertMessageEBTRestrictedItemsWithEBTEligibleItemsNoCC(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_09_02_DisplayAlertMessageBelowCCSectionEBTRestrictedItemsWithEBTEligibleItemsNoCC() throws Exception {
		new TC_SNAP_09_02_DisplayAlertMessageBelowCCSectionEBTRestrictedItemsWithEBTEligibleItemsNoCC(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_10_01_UserShownAcceptsEBTLogoOnPickupStoreListOnLocationSlider() throws Exception {
		new TC_SNAP_10_01_UserShownAcceptsEBTLogoOnPickupStoreListOnLocationSlider(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_10_02_UserShownAcceptsEBTLogoOnPickupStoreList() throws Exception {
		new TC_SNAP_10_02_UserShownAcceptsEBTLogoOnPickupStoreList(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_10_03_UserShownAcceptsEBTCopyOnPickupStoreList() throws Exception {
		new TC_SNAP_10_03_UserShownAcceptsEBTCopyOnPickupStoreList(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_10_04_UserNotShownLogoOrCopyIfDoesNotAcceptEBT() throws Exception {
		new TC_SNAP_10_04_UserNotShownLogoOrCopyIfDoesNotAcceptEBT(utility).perform();
	}//IndividualTestCase2

	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_11_01_UserIsAbleToSeeEBTCardEndingInPaymentMethodsSection() throws Exception {
		new TC_SNAP_11_01_UserIsAbleToSeeEBTCardEndingInPaymentMethodsSection(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_11_02_UserIsAbleToSeeMutliplePaymentMethodsInPaymentMethodsSectionCCPlusEBT() throws Exception {
		new TC_SNAP_11_02_UserIsAbleToSeeMutliplePaymentMethodsInPaymentMethodsSectionCCPlusEBT(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_11_03_EBTPaymentsAppliedToOrderToShowUpBelowOrderTotal() throws Exception {
		new TC_SNAP_11_03_EBTPaymentsAppliedToOrderToShowUpBelowOrderTotal(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_12_01_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalGreater() throws Exception {
		new TC_SNAP_12_01_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalGreater(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_12_02_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalEqualsZero() throws Exception {
		new TC_SNAP_12_02_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalEqualsZero(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_13_01_VerifyMessageWhenOrderTotalAmountHigherThanPreviousOrderTotal() throws Exception {
		new TC_SNAP_13_01_VerifyMessageWhenOrderTotalAmountHigherThanPreviousOrderTotal(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_01_VerifyRemovePromoFromPaymentsMethodsScreen() throws Exception {
		new TC_SNAP_14_01_VerifyRemovePromoFromPaymentsMethodsScreen(utility).perform();
	}//IndividualTestCase2

	
	
	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_02_OrderWithPromotions() throws Exception {
		new TC_SNAP_14_02_OrderWithPromotions(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_02_01_ApplyingPromo() throws Exception {
		new TC_SNAP_14_02_01_ApplyingPromo(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_03_EBTPaymentPromoAdjustments() throws Exception {
		new TC_SNAP_14_03_EBTPaymentPromoAdjustments(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_03_01_PromoAddedOnPaymentDetailsInPaymentMethods() throws Exception {
		new TC_SNAP_14_03_01_PromoAddedOnPaymentDetailsInPaymentMethods(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "SnapNo"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_04_EBTPaymentAdjustmentsCCPromo() throws Exception {
		new TC_SNAP_14_04_EBTPaymentAdjustmentsCCPromo(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"SequentialNo",  "Stage", "Snap"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_SNAP_14_04_01_PromoAddedOnPaymentDetailsInReviewOrder() throws Exception {
		new TC_SNAP_14_04_01_PromoAddedOnPaymentDetailsInReviewOrder(utility).perform();
	}//IndividualTestCase2

	
	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_01_07_01_01_ErrorMessagePleaseEnterYourFirstNameDuringCreateAccount", "E2E" , "BAT"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_07_01_01_ErrorMessagePleaseEnterYourFirstNameDuringCreateAccount() {
		new TC_OGA_01_07_01_01_ErrorMessagePleaseEnterYourFirstNameDuringCreateAccount(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest

	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_01_07_01_02_ErrorMessagePleaseEnterYourLastNameDuringCreateAccount", "E2E", "BAT"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_07_01_02_ErrorMessagePleaseEnterYourLastNameDuringCreateAccount() {
		new TC_OGA_01_07_01_02_ErrorMessagePleaseEnterYourLastNameDuringCreateAccount(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest


	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_01_07_01_03_ErrorMessagePleaseEnterYourEmailAddressDuringCreateAccount","E2E", "BAT"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_07_01_03_ErrorMessagePleaseEnterYourEmailAddressDuringCreateAccount() {
		new TC_OGA_01_07_01_03_ErrorMessagePleaseEnterYourEmailAddressDuringCreateAccount(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest


	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_01_07_01_04_ErrorMessagePleaseEnterAPasswordDuringCreateAccount","E2E", "BAT"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_07_01_04_ErrorMessagePleaseEnterAPasswordDuringCreateAccount() {
		new TC_OGA_01_07_01_04_ErrorMessagePleaseEnterAPasswordDuringCreateAccount(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest
	
	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_01_07_02_01_ErrorMessagePleaseEnterYourEmailAddressDuringSignIn","E2E", "BAT"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_07_02_01_ErrorMessagePleaseEnterYourEmailAddressDuringSignIn() {
		new TC_OGA_01_07_02_01_ErrorMessagePleaseEnterYourEmailAddressDuringSignIn(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest

	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_01_07_02_02_ErrorMessagePleaseEnterAPasswordDuringSignIn","E2E", "BAT"} , priority=101, enabled = true)
	/**some comment*/
	public void tC_OGA_01_07_02_02_ErrorMessagePleaseEnterAPasswordDuringSignIn() {
		new TC_OGA_01_07_02_02_ErrorMessagePleaseEnterAPasswordDuringSignIn(utility).perform();
	}//tc_ProjName_01_01_UserLogInTest

	

	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_03_01_02_VerifyAscendingOrderFromTopToBottomOfDisplayedPickupTimes", "E2E", "BAT"} , priority=313, enabled = true)
	/**some comment*/
	public void tc_OGA_03_01_02_VerifyAscendingOrderFromTopToBottomOfDisplayedPickupTimes() {
		new TC_OGA_03_01_02_VerifyAscendingOrderFromTopToBottomOfDisplayedPickupTimes(utility).perform();
	}//IndividualTestCase2
		
	
	

	
	
	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_04_02_03_VerifyAddItemsToTheCartViaFeaturedItems","E2E", "BAT"} , priority=313, enabled = true)
	//**some comment*/
	public void tC_OGA_04_02_03_VerifyAddItemsToTheCartViaFeaturedItems() throws Exception {
		new TC_OGA_04_02_03_VerifyAddItemsToTheCartViaFeaturedItems(utility).perform();
	}//IndividualTestCase2
	

	

	//@Title("test case title goes here")
	@Test(groups = {"TC_OGA_08_01_07_VerifyAllPricesViaFeaturedItems","E2E", "BAT"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_08_01_07_VerifyPricesOnItemsDetailsScreenThroughFeaturedItems() {
		new TC_OGA_08_01_07_VerifyPricesOnItemsDetailsScreenThroughFeaturedItems(utility).perform();
	}//IndividualTestCase2
	
	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_04_06_01_VerifyAddItemsToFavoritesListFromHomePage", "E2E", "BAT"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_06_01_VerifyAddItemsToFavoritesListFromHomePage() throws Exception {
		new TC_OGA_11_01_01_VerifyAddItemsToFavoritesListFromHomePage(utility).perform();
	}//IndividualTestCase2



	//@Title("test case title goes here")
	@Test(groups = {"tC_OGA_04_07_01_VerifyDeleteItemsFromFavoritesListWhichAddedFromHomePage","E2E", "BAT"} , priority=313, enabled = true)
	/**some comment*/
	public void tC_OGA_04_07_01_VerifyRemoveItemsFromFavoritesListWhichAddedFromHomePage() throws Exception {
		new TC_OGA_11_02_01_VerifyRemoveItemsFromFavoritesWhichAddedFromHomePage(utility).perform();
	}//IndividualTestCase2


	


	

}//class