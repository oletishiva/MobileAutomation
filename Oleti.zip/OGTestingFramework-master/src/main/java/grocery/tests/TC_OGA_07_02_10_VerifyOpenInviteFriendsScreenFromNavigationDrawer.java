package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_02_10_VerifyOpenInviteFriendsScreenFromNavigationDrawer extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_02_10_VerifyOpenInviteFriendsScreenFromNavigationDrawer(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Refer & get $10 0ff
		utility.tapElement("navigationDrawer_ReferButton");
		
		
		//getText <inviteFriends_TitleText>
		actualResult = utility.getTextElement("inviteFriends_TitleText");
		expectedResult = "Invite friends";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
		
	}// performTest

} // class
