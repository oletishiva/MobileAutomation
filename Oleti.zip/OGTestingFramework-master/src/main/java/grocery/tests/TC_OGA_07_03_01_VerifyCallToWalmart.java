package grocery.tests;

import org.openqa.selenium.By;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_03_01_VerifyCallToWalmart extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_03_01_VerifyCallToWalmart(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Contact Us
		utility.tapElement("navigationDrawer_ContactUsButton");
		
		//click Phone button
		utility.tapElement("navigationDrawer_ContactUsPhoneButton");
		
		
	
		
		//getAttribute("enabled")
		final String phoneAppDialButton = utility.getDriver().findElement(By.xpath(utility.getLocator("navigationDrawer_ContactUsDialButton"))).getAttribute("enabled");
		utility.reporter.logToAllure( phoneAppDialButton);
		Assert.assertEquals("true", phoneAppDialButton);

		
		utility.clickNativeAndroidBackButton();
		
		utility.clickNativeAndroidBackButton();
 
 
		
	}// performTest


} // class
