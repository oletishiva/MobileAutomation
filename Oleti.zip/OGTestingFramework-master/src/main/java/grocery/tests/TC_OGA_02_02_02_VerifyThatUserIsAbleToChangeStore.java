package grocery.tests;
import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_02_02_02_VerifyThatUserIsAbleToChangeStore extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_02_02_VerifyThatUserIsAbleToChangeStore(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
        
		// // comment one this test case will fail some of the time because you
		// cannot guarantee the existence of reserveButton Feb05RJR
		//tap <RESERVE button>
		
		
        utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
        
        final String oldPickupAddress = utility.getTextElement("reserveATime_ReserveStoreAddressText");
		
		utility.tapElement("reserveATime_PickUpLocationPicker"); 
		
		utility.tapElement("pickupTab_AnotherStoreAddress");
		
		final String newPickupAddress = utility.getTextElement("reserveATime_ReserveStoreAddressText");
		
		
		//compare old and new pickup addresses
		if (oldPickupAddress.equals(newPickupAddress))
			actualResult = "Pickup Address wasn't changed";
		else
			actualResult = "Pickup Address was changed";
		
		//compare expected and actual results
		utility.hardAssert(actualResult, expectedResult, name);
		 //Assert.assertNotEquals(oldPickupAddress, newPickupAddress);
		
		utility.clickNativeAndroidBackButton();

		
		
	}// performTest


}// class

