package grocery.tests;

import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_01_07_01_02_ErrorMessagePleaseEnterYourLastNameDuringCreateAccount extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_01_07_01_02_ErrorMessagePleaseEnterYourLastNameDuringCreateAccount(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		//Install Online Grocery Android
		//Launch Online Grocery Android
			
		//click <SkipButon>
		System.out.printf("\n RJR: Clicking on the 'Skip' button");
		utility.tapElement( "skipScreen_SkipButton" );
		
		//sendKeys <ZIP80211> to <zipCode_EnterZipCodeField>
		System.out.printf("\n RJR: Entering the zipcode 95117 into the zip_entry_text field");
		utility.sendKeysElement( "zipCode_EnterZipCodeField" , "80211" );
		
		//click <zipCode_GoButton>
		System.out.printf("\n RJR: Clicking on the 'zip_enter' button");
		utility.tapElement( "zipCode_GoButton" );
		
		
		//click <signIn_CreateAccountButton>
		utility.tapElement("signIn_CreateAccountButton");
		
		//sendKeys <FIRSTNAME> to <createAccount_FirstNameField>		
		utility.sendKeysElement( "createAccount_FirstNameField" , "Test" );
		
		//click <createAcccount_CreateAccountButton>
		utility.tapElement("createAcccount_CreateAccountButton");
		
			
		//getText error messages
		actualResult = utility.getTextElement("createAccount_ErrorMessageText");
		expectedResult = "Please enter your last name.";
		Assert.assertEquals(actualResult, expectedResult);
		
		
		
	}// performTest
} // class
