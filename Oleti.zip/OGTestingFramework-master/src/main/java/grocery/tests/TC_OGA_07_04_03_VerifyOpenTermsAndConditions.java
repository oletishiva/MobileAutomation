package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_04_03_VerifyOpenTermsAndConditions extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_04_03_VerifyOpenTermsAndConditions(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Refer & get $10 0ff
		utility.tapElement("navigationDrawer_ReferButton");
		
		//click <inviteFriends_TermsConditionsButton>
		utility.tapElement("inviteFriends_TermsConditionsButton");
		
		//getText <inviteFriends_TermsSnackBarText>
		final String textTems = utility.getTextElement("inviteFriends_TermsSnackBarText");
		actualResult = new String(textTems.replaceAll("\\n", ""));
		expectedResult = "Offer valid for one-time use only for Walmart Grocery online service, in available stores."
				+ "Minimum order of $50. Only one discount code per order. Offer not transferable."
				+ "Does not apply to alcohol purchases. Customer responsible for all applicable taxes. Offer expires after 1 year from promotion code delivery.";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
 
		utility.clickNativeAndroidBackButton();

		
	}// performTest
} // class
