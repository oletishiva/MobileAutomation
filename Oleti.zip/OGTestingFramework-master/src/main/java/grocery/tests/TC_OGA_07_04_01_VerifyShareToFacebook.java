package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_04_01_VerifyShareToFacebook extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_04_01_VerifyShareToFacebook(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Refer & get $10 0ff
		utility.tapElement("navigationDrawer_ReferButton");
		
		//click Share Now
		utility.tapElement("inviteFriends_ShareButton");
				
		//getText <inviteFriends_FacebookText>
		
		//utility.fastSwipe( "Facebook" );
		utility.fastSwipe( "inviteFriends_FacebookText", "up");
		
		actualResult = utility.getTextElement("inviteFriends_FacebookText");
		expectedResult = "Facebook";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
 
		utility.clickNativeAndroidBackButton();
 
		
		
	}// performTest

} // class