package grocery.tests;

import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;



public class TC_OGA_03_01_03_VerifyInformationAboutFREEPickup extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_03_01_03_VerifyInformationAboutFREEPickup(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}
	

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
										
		//utility.clickElement( "navigationDrawer_ReserveATimeButton" );
		
		// need to create an a fluent wait? mechanism that checks whether a snackbar is
		// open Jan04RJR
		//utility.clickElement( "reserveATime_AlertOkButton" );
		
		
		//TC check whether free pickup does not increase the price
		// as a starting condition: need to get checkout cart to be empty (need to create a flow for that)
		// if checkout not empty then empty checkout flow 
		
		// getText checkout cart price as Expected result
		// find out todays DD to a variable
		// derive tomorrows DD to a variable
		// check whether or not earliest pickup slot is checked or unchecked
		// 	if unchecked getTextElement if FREE element is present
		//		clickElement on earliest time slot
		//	if checked - for next time slot getTextElement if FREE element is present
		// 		clickElement on earliest time slot + 1
		// 	getText checkout cart as ActualResult
		// hardAssert Actual vs Expected
		// --- Can do this for 0, under 30, over 30 for store that is at 30 limit
		// , under 50, over 50 for store that is at 50 limit
		
		// another test case, verify that for each available time slot ( there is the same quantity of FREE elements present quantity)
		
		
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
	
			
		//click OK to close snackbar message
		
			
		
		//click <reserveATime_NoAvailabilityTodayText>
				
		
		//getText "FREE"
		
		utility.tapElement( "reserveATime_SlotPriceText" );  //???
		
		final String freePrice = utility.getTextElement( "reserveATime_SlotPriceText" );
		Assert.assertEquals("FREE", freePrice);
		utility.reporter.logToAllure( freePrice);
		
		
		
		utility.clickNativeAndroidBackButton();
		
		
	}// performTest



} // class
