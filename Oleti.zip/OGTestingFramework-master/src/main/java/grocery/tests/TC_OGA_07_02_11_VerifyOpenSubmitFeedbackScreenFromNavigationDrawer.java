package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_02_11_VerifyOpenSubmitFeedbackScreenFromNavigationDrawer extends AbstractTestCase {
	
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_02_11_VerifyOpenSubmitFeedbackScreenFromNavigationDrawer(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
	
		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		
		
		
		
		//click Send app feedback
		
	    utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
	    
		utility.tapElement("navigationDrawer_SendAppFeedbackButton");
		
		
		//getText <submitFeedback_TitleText>
		actualResult = utility.getTextElement("submitFeedback_TitleText");
		expectedResult = "Submit feedback";
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
 		
		
	}// performTest

} // class
