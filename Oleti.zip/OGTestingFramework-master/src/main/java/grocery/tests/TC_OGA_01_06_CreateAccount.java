package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

  
//UC_OGA_01_06_Registration into App with new user

public class TC_OGA_01_06_CreateAccount extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_01_06_CreateAccount(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	@Override
	public void perform()  {
		
		//Install Online Grocery Android
		//Launch Online Grocery Android
		
		
		
		//click <SkipButon>
		System.out.printf("\n RJR: Clicking on the 'Skip' button");
		utility.tapElement( "skipScreen_SkipButton" );
		
		//sendKeys <ZIP80211> to <zipCode_EnterZipCodeField>
		System.out.printf("\n RJR: Entering the zipcode 95117 into the zip_entry_text field");
		utility.sendKeysElement( "zipCode_EnterZipCodeField" , "80211" );
		
		//click <zipCode_GoButton>
		System.out.printf("\n RJR: Clicking on the 'zip_enter' button");
		utility.tapElement( "zipCode_GoButton" );
		
		
		//click <signIn_CreateAccountButton>	
		utility.tapElement( "signIn_CreateAccountButton" );
		
		//sendKeys <FIRSTNAME> to <createAccount_FirstNameField>
		utility.sendKeysElement( "createAccount_FirstNameField" , "Test" );
		
		//sendKeys <LASTNAME> to <createAccount_LastNameField>
		utility.sendKeysElement( "createAccount_LastNameField" , "User" );
		
		// for create different users	
		long now = System.currentTimeMillis();       
		String email = String.format("testuser%s@gmail.com", now);		
		
		//sendKeys <EMAIL> to <createAccount_EmailField>
		utility.sendKeysElement( "createAccount_EmailField" , email );
		
		//sendKeys <PASSWORD> to <createAccount_PasswordField>
		utility.sendKeysElement( "createAccount_PasswordField" , "Password" );
		
		//click <createAcccount_CreateAccountButton>
		utility.tapElement( "createAccount_CreateAccountButton" );
		
		//click <splashScreen_CloseButton> to close Splash Screen
		utility.tapElement( "splashScreen_CloseButton" );
		
		//click back button  //only for automation
		utility.getDriver().navigate().back();

		//click back button  //only for automation
		utility.getDriver().navigate().back();

		
		//getText "Hello, <FIRSTNAME>"  // doesn't work yet???
		/*String welcome = utility.getDriver().findElement(By.xpath("//*[contains(@class,'android.widget.TextView')]")).getText();
		utility.reporter.logToAllure( welcome);
		String FIRSTNAME = "Test";
						
		Assert.assertEquals("Hello, " + FIRSTNAME, welcome); */
		
		/*//click <homeTab_ConfirmButton>
		utility.getDriver().findElement(By.xpath("//*[contains(@text,'CONFIRM')]")).click();
		
		//click <homeTab_ReserveButton>
		utility.getDriver().findElement(By.xpath("//*[contains(@text,'RESERVE')]")).click();	*/
		
				
	}// performTest
} // class


