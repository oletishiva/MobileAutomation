package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_05_05_VerifySendMessage extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_05_05_VerifySendMessage(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();

		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_SendAppFeedbackButton>
		
		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down");
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
		
		utility.tapElement("navigationDrawer_SendAppFeedbackButton");
		
		//click <submitFeedback_MessageTitle>
		utility.tapElement("submitFeedback_MessageTitle");
		
		//sendKeys "Hello friends" to  <submitFeedback_MessageText>
		utility.sendKeysElement( "submitFeedback_MessageText" , "Hello friends" );
		
		
		//click <submitFeedback_SendButton>
		utility.tapElement("submitFeedback_SendButton");
		
		
		//getText <Send email with:> from <submitFeedback_SendEmailWithText>
 		actualResult = utility.getTextElement("submitFeedback_SendEmailWithText");
		expectedResult = "Send email with:";
		utility.hardAssert(actualResult, expectedResult, name);
			
		utility.clickNativeAndroidBackButton();
	
	}// performTest
} // class
