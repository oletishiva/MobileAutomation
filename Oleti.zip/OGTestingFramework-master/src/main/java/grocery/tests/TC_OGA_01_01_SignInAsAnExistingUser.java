package grocery.tests;
import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_01_01_SignInAsAnExistingUser extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_01_01_SignInAsAnExistingUser(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		
		//commenting below to see if I can use the state on the device Apr04RJR
//		flowSignIn();
		
		utility.reporter.logToAllure( utility.getDriver().findElements(By.xpath("//*[contains(@text,'HOME')]")) + "How many `Hello` elements are there? ");
		utility.reporter.logToAllure( utility.getDriver().findElements(By.xpath("//*[contains(@text,'HOME')]")).size() + "How many `Hello` elements are there? ");
		utility.reporter.logToAllure( utility.getDriver().findElements(By.xpath("//*[contains(@text,'HOME')]")).isEmpty() + "How many `Hello` elements are there? ");
		utility.reporter.logToAllure( utility.getDriver().findElements(By.xpath("//*[contains(@text,'HOME')]")).iterator() + "How many `Hello` elements are there? ");
		
		
		actualResult = utility.getTextElement("actionBar_HomeTab");
		expectedResult = "Home";
		utility.hardAssert(actualResult, expectedResult, name);
		
		
		
	}// performTest
} // class


