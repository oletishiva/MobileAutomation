package grocery.tests;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;



//Expected result: Verify checkout is unlocked 

public class TC_OGA_04_03_03_VerifyCheckoutButtonIsEnabled extends AbstractTestCase {
	

	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_04_03_03_VerifyCheckoutButtonIsEnabled(final UtilityContainer utility) {
		super(utility);
	}//constructor

	

	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
										
		
		//getText old_cart_count
		
		initialQuantity = Integer.valueOf( utility.getTextElement( "actionBar_CartItemCountButton" ) );
		utility.reporter.logToAllure( "Items in cart before: " + initialQuantity );

		
		//getText old_cart_subtotal
		final String cartSubtotalBefore = utility.getTextElement( "actionBar_CartSubtotalButton" );
		final String regex = "^"
					 + "(?:\\$)?"
					 + "(?:\\s*)?"
					 + "((?:\\d{1,3})(?:\\,)?(?:\\d{3})?(?:\\.)?(\\d{0,2})?)"
					 + "$";
		final Pattern patt = Pattern.compile(regex);
		Matcher matcher = patt.matcher(cartSubtotalBefore);
		matcher.find();
		final double subtotalDoubleBefore = Double.parseDouble(matcher.group(1).replaceAll("[$.]", ""));
		final double subtotalDoubleBeforeFinal = new BigDecimal((100.0 * subtotalDoubleBefore) / 100).setScale(2,RoundingMode.HALF_UP).doubleValue();
		
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );

		//sendKeys "itemWater" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		//click <Text>
		utility.tapElement( "search_Text" );
		
		//getPrice
		final String itemPriceText = utility.getTextElement( "homeTab_ItemPriceText" );
		
		matcher = patt.matcher(itemPriceText);
		matcher.find();
		final double itemPriceDouble = Double.parseDouble(matcher.group(1).replaceAll("[$.]", ""));
		final double itemPriceAdded = new BigDecimal((100.0 * itemPriceDouble) / 100).setScale(2,RoundingMode.HALF_UP).doubleValue();
		
		//click <global_AddVeryFirstItemOnTopLeftButton> of top right item
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
		
		//tap quantity button to open drop down menu
		utility.tapElement( "global_AmountQuantityOfItemButton"); 

		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
		
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
		
		final int max = Integer.valueOf(utility.getTextElement( "global_AmountDropDownMenuLastElement" ));
		
		utility.tapElement( "global_AmountDropDownMenuLastElement" );
		


	

		//tap <global_ToolBarArrowBackButton>		
		utility.tapElement( "global_ToolBarArrowBackButton" );

		//click <cart_ActionCartView>
		utility.tapElement( "actionBar_CartButton" );

		//click <cart_QuantityView> 
		//utility.tapElement( "cart_QuantityView" );
		
		//getText new_cart_count
		
		actualResult = Integer.valueOf( 
				utility.getTextElement( "actionBar_CartItemCountButton" ) );

		expectedResult = initialQuantity + max;
		utility.hardAssert(actualResult, expectedResult, name);

		
		//getText new_cart_subtotal
		final String cartSubtotalAfter = utility.getTextElement( "actionBar_CartSubtotalButton" );
		matcher = patt.matcher(cartSubtotalAfter);
		matcher.find();
		final double subtotalDoubleAfter = Double.parseDouble(matcher.group(1).replaceAll("[$.]", ""));
		final double subtotalDoubleAfterFinal = new BigDecimal((100.0 * subtotalDoubleAfter) / 100).setScale(2,RoundingMode.HALF_UP).doubleValue();
				
		Assert.assertEquals(subtotalDoubleBeforeFinal + (itemPriceAdded * max), subtotalDoubleAfterFinal);
		
		//getAttribute("enabled")
		final String cartCheckOut = utility.getDriver().findElement(By.xpath(utility.getLocator("homeTab_CheckOutButton"))).getAttribute("enabled");
		utility.reporter.logToAllure( cartCheckOut);
		Assert.assertEquals("true", cartCheckOut);
		
		
		
		utility.clickNativeAndroidBackButton();
	
		
	}// performTest


} // class



