package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_12_03_13_VerifyErrorMessagePaymentCouldNotBeAuthorized extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	private transient boolean flagCardIsChanged = true;
	
	
	
	private transient FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!")
			.withTimeout(3, TimeUnit.SECONDS)
	        .pollingEvery(50, TimeUnit.MILLISECONDS)
	        .ignoring(NoSuchElementException.class);
	
	public TC_OGA_12_03_13_VerifyErrorMessagePaymentCouldNotBeAuthorized(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public boolean isElementPresent(final By locator) {
	    try {
	    	
	    	fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	    	
	        return true;  
	    
	    }  
	    
	    catch(Exception e) {  
	       
	    	return false;  
	    
	    } 
	 
	 }

	public void changeCard() {
		
		utility.tapElement( "payment_FirstPaymentMethod" );
		
		utility.tapElement( "payment_ContinueButton" );
		
		//scroll down to <Place Order>
		utility.fastSwipe( "reviewOrder_SmsInfoText", "up");
		
		
		utility.tapElement( "reviewOrder_PlaceOrderButton" );
		
		//sendKeys <000> to <reviewOrder_CVV>
		utility.sendKeysElement("reviewOrder_CVV", "000");
		
		utility.tapElement( "reviewOrder_ContinueButton" );
		
		flagCardIsChanged = false;
		
	}
	
	

	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		//flowSignIn sequence
		flowSignIn();
		
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);

		//tap search button
		utility.tapElement( "actionBar_SearchButton");
				
		//sendKeys <water> to <search field>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
				
		//tap search 
		utility.tapElement( "search_Text" );
				
		//tap <ADD> button
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton"); 
		
		//tap quantity button to open drop down menu
		utility.tapElement( "global_AmountQuantityOfItemButton"); 

				
		//scroll down to <max amount>
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
		
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");	

				
		//tap <max amount>
		utility.tapElement( "global_AmountDropDownMenuLastElement");
				
		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton");
				
		//tap <Cart>
		utility.tapElement( "actionBar_CartButton");
				
		//tap <Checkout>
		utility.tapElement( "cart_CheckoutButton");
		
		//Check PaymentMethodView
		if (isElementPresent(By.xpath("//*[contains(@text,'Payment Method')]"))) 
			
			changeCard();
		
		else
			
			//tap <Continue>
		    utility.tapElement( "cart_ContinueButton");
		
		//Check PaymentMethodView
		if (isElementPresent(By.xpath("//*[contains(@text,'Payment Method')]")) && flagCardIsChanged)  
			
			changeCard();
				
		//Check snackbar
		if (isElementPresent(By.xpath("//*[starts-with(@text,'What if an item isn')]")) && flagCardIsChanged) {
					
			//close snackbar
			utility.tapElement( "reviewOrder_AllowSubstitutesCheckBox");
				    
			//tap <PickupPicker>
			utility.tapElement( "reviewOrder_PickupPicker");

		}
				
		if (isElementPresent(By.xpath("//*[contains(@text, 'Your reservation has expired. Please select a new time.')]")) && flagCardIsChanged)
			
			//tap <reserveATime_AlertOkButton>			
			utility.tapElement( "reserveATime_AlertOkButton");
		
		if (flagCardIsChanged) {
				
			//tap <DayAfterTomorrow>		
			utility.tapElement( "reserveATime_PickupDay");
						        
			//scroll down <Time> to <3PM-4PM> 				
			utility.fastSwipe( "reserveATime_TodayText", "up");
			
		
			//tap <3PM-4PM> 		
			utility.tapElement( "reserveATime_LastSlotTime");				
		
			//tap <Continue>	
			utility.tapElement( "cart_ContinueButton");
			
			changeCard();
			
		}
		
		//get text from message
		actualResult = utility.getTextElement("reviewOrder_ErrorMessageText");
		
		expectedResult = "Your payment couldn't be authorized. Please use a different payment method.";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);
		
		//tap <global_ToolbarCloseScreenButton>	
		utility.tapElement( "reviewOrder_ChangeButton");
		
		//tap <global_ToolbarNavigateToPreviousScreenArrow>	
		utility.tapElement( "global_ToolbarNavigateToPreviousScreenArrow");
		
		//tap <payment_AlertOkButton>	
		utility.tapElement( "payment_AlertOkButton");
		
		
		
		utility.clickNativeAndroidBackButton();

		
	}// performTest
}// class
