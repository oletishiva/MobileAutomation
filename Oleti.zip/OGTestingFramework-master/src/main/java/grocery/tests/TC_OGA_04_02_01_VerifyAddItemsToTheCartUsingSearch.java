package grocery.tests;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_04_02_01_VerifyAddItemsToTheCartUsingSearch extends AbstractTestCase {
		
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_04_02_01_VerifyAddItemsToTheCartUsingSearch(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
		
		initialQuantity = Integer.valueOf( utility.getTextElement( "actionBar_CartItemCountButton" ) );

		utility.tapElement( "actionBar_SearchButton" );
		
		utility.sendKeysElement( "search_SearchSrcField" , itemWater );
		
		utility.tapElement( "search_Text" );
		
		expectedResult = utility.getPriceElement( "homeTab_ItemPriceText" );
		
		
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
			
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		
//		-----
		
		actualResult = utility.getDriver().findElement(By.xpath(utility.getLocator("actionBar_CartSubtotalButton"))).getText();
		
		utility.hardAssert(actualResult, expectedResult, name);
		
		actualResult = Integer.valueOf( 
				utility.getTextElement( "actionBar_CartItemCountButton" ) );

		expectedResult = initialQuantity +1;
		utility.hardAssert(actualResult, expectedResult, name);

		
		
		
		
		
		// ** need to add an @AfterTest method jan29RJR
		// flowCleanCart()
		// if signedInFlow flag is turned on then:
		// navigate to Home Screen
		// getText cartItemTotal from <cart>
		// click cartItem
		// for (int i = 0; i < cartItemTotal; i++) {}
		// tap very dynamically loose element to reduce item qty
		// alternatively (while (cartItemTotal = getText cartItemTotal) > 0) do 
	
		
	}// performTest
} // class

