package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_05_02_10_VerifyThatUserSeesAlcoholDisclosureWhenOrderingAlcohol extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	

	
	public FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!")
			.withTimeout(3, TimeUnit.SECONDS)
	        .pollingEvery(10, TimeUnit.MILLISECONDS)
	        .ignoring(NoSuchElementException.class);
	
	public boolean isElementPresent(final By locator) {
	    try {
	    	
	    	fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	    	
	        return true;  
	    
	    }  
	    
	    catch(Exception e) { 
	       
	    	return false;
	    	
	    }
	 
	 }
	
	
	public TC_OGA_05_02_10_VerifyThatUserSeesAlcoholDisclosureWhenOrderingAlcohol(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		//flowSignIn sequence
		flowSignIn();
		
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);

        //tap search button
        utility.tapElement( "actionBar_SearchButton");
      				
      	//sendKeys <water> to <search field>
      	utility.sendKeysElement("search_SearchSrcField", "wine\n");

		if (isElementPresent(By.xpath("//*[contains(@text,'Keep in mind, some items found in our stores may not be available online.')]")))

			//get text from message
			actualResult = "Keep in mind, some items found in our stores may not be available online.";
		
		else
			
			actualResult = "";
			
		expectedResult = "Keep in mind, some items found in our stores may not be available online.";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);
		
		utility.clickNativeAndroidBackButton();
		
	}// performTest


	
}// class