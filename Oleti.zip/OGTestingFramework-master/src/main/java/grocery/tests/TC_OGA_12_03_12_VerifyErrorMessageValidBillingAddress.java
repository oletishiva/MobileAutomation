package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_OGA_12_03_12_VerifyErrorMessageValidBillingAddress extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	private transient boolean flagAddressIsChanged = true;
	
	
	private transient  FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!")
			.withTimeout(3, TimeUnit.SECONDS)
	        .pollingEvery(50, TimeUnit.MILLISECONDS)
	        .ignoring(NoSuchElementException.class);
	
	public TC_OGA_12_03_12_VerifyErrorMessageValidBillingAddress(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public boolean isElementPresent(final By locator) {
	    try {
	    	
	    	fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	    	
	        return true;  
	    
	    }  
	    
	    catch(Exception e) {  
	       
	    	return false;  
	    
	    } 
	 
	 } 

	public void changeAddress() {
		
		utility.tapElement( "payment_AddButton" );
		
		utility.tapElement( "addCard_ActionChange" );
		
		if (isElementPresent(By.xpath("//*[contains(@resource-id,'com.walmart.grocery:id/address_list_add_button')]")))	
		
			utility.tapElement( "newAddress_AddAddressButton" );

		//sendKeys <hhhhh> to <newAddress_StreetField>
		utility.sendKeysElement("newAddress_StreetField", "hhhhh");
		
		//sendKeys <hhhhh> to <newAddress_CityField>
		utility.sendKeysElement("newAddress_CityField", "hhhhh");
		
		//sendKeys <hh> to <newAddress_StateField>
		utility.sendKeysElement("newAddress_StateField", "hh");
		
		//sendKeys <94444> to <newAddress_ZipCodeField>
		utility.sendKeysElement("newAddress_ZipCodeField", "94444");
		
		//sendKeys <4159999999> to <newAddress_PhoneField>
		utility.sendKeysElement("newAddress_PhoneField", "4159999999");		
		
		flagAddressIsChanged = false;
		
	}
	


	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		//flowSignIn sequence
		flowSignIn();
		
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);

		//tap search button
		utility.tapElement( "actionBar_SearchButton");
				
		//sendKeys <water> to <search field>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
				
		//tap search 
		utility.tapElement( "search_Text" );
				
		//tap <ADD> button
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton"); 
		
		//tap quantity button to open drop down menu
		utility.tapElement( "global_AmountQuantityOfItemButton"); 

				
		//scroll down to <max amount>
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");
		
		utility.fastSwipe( "global_AmountDropDownMenuLastElement", "up");	

				
		//tap <max amount>
		utility.tapElement( "global_AmountDropDownMenuLastElement");
				
		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton");
				
		//tap <Cart>
		utility.tapElement( "actionBar_CartButton");
				
		//tap <Checkout>
		utility.tapElement( "cart_CheckoutButton");
		
		//Check PaymentMethodView
		if (isElementPresent(By.xpath("//*[contains(@text,'Payment Method')]"))) 
			
			changeAddress();
		
		else
			
			//tap <Continue>
		    utility.tapElement( "cart_ContinueButton");
		
		//Check PaymentMethodView
		if (isElementPresent(By.xpath("//*[contains(@text,'Payment Method')]")) && flagAddressIsChanged)  
			
			changeAddress();
				
		//Check snackbar
		if (isElementPresent(By.xpath("//*[starts-with(@text,'What if an item isn')]")) && flagAddressIsChanged) {
					
			//close snackbar
			utility.tapElement( "reviewOrder_AllowSubstitutesCheckBox");
				    
			//tap <PickupPicker>
			utility.tapElement( "reviewOrder_PickupPicker");

		}
				
		if (isElementPresent(By.xpath("//*[contains(@text, 'Your reservation has expired. Please select a new time.')]")) && flagAddressIsChanged)
			
			//tap <reserveATime_AlertOkButton>			
			utility.tapElement( "reserveATime_AlertOkButton");
		
		if (flagAddressIsChanged) {
				
			//tap <DayAfterTomorrow>		
			utility.tapElement( "reserveATime_PickupDay");
						        
			//scroll down <Time> to <3PM-4PM> 				
			utility.fastSwipe( "reserveATime_TodayText", "up");
			
		
			//tap <3PM-4PM> 		
			utility.tapElement( "reserveATime_LastSlotTime");				
		
			//tap <Continue>	
			utility.tapElement( "cart_ContinueButton");
			
			changeAddress();
			
		}
		
		//tap <global_ToolbarSaveButton>
		utility.tapElement( "global_ToolbarSaveButton" );
		
		//get text from message
		actualResult = utility.getTextElement("newAddress_SnackBarText");
		
		expectedResult = "Please enter a valid billing address.";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);
		
		//tap <newAddress_CloseView>	
		utility.tapElement( "global_ToolbarCloseScreenButton");
		
		//tap <newAddress_AlertOkButton>	
		utility.tapElement( "newAddress_AlertOkButton");
		
		if (isElementPresent(By.xpath("//*[contains(@resource-id,'com.walmart.grocery:id/address_list_add_button')]")))		
		
			//tap <global_ToolbarNavigateToPreviousScreenArrow >	
			utility.tapElement( "global_ToolbarNavigateToPreviousScreenArrow ");
		
		//tap <global_ToolbarCloseScreenButton>	
		utility.tapElement( "global_ToolbarCloseScreenButton");
		
		//tap <global_ToolbarNavigateToPreviousScreenArrow >	
		utility.tapElement( "global_ToolbarNavigateToPreviousScreenArrow ");
		
		//tap <payment_AlertOkButton>	
		utility.tapElement( "payment_AlertOkButton");
		
		
		
		utility.clickNativeAndroidBackButton();

		
	}// performTest
}// class
