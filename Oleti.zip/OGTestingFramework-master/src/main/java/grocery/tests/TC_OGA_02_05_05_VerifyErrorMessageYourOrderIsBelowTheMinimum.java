package grocery.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_02_05_05_VerifyErrorMessageYourOrderIsBelowTheMinimum extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_02_05_05_VerifyErrorMessageYourOrderIsBelowTheMinimum(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	public void clearCart() throws InterruptedException {
		//clean Cart
		
		utility.tapElement( "actionBar_CartButton" );
		
		for (int i = utility.getDriver().findElements(By.xpath("//*[contains(@resource-id,'com.walmart.grocery:id/title')]")).size(); i > 0; i--) {
			
			utility.tapElement( "cart_QuantityView" );
		
			utility.tapElement( "cart_DropDownButton" );
		
			utility.tapElement( "homeTab_RemoveDropDownMenu" );
		
		}
		
		//tap <global_ToolbarNavigateToPreviousScreenArrow >
		utility.tapElement( "global_ToolbarNavigateToPreviousScreenArrow ");

	}
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		//flowSignIn sequence
		flowSignIn();
		
        //decrease implicitly wait
        utility.getDriver().manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
        
		
		//check cart empty
		if (Integer.parseInt(utility.getTextElement( "actionBar_CartItemCountButton" )) > 0) {
			clearCart();
		}
		
		if (!utility.getDriver().findElements(By.xpath("//*[contains(@text, 'Reserve a time for your order')]")).isEmpty()) {
		
			//tap <homeTab_ReserveButton>		
			utility.tapElement("homeTab_ReserveButton");
			}
			
			if (!utility.getDriver().findElements(By.xpath("//*[contains(@text, 'Your reservation has expired. Please select a new time.')]")).isEmpty())
			{			
				//tap <reserveATime_AlertOkButton>			
				utility.tapElement( "reserveATime_AlertOkButton");
			   
			    //tap <DayAfterTomorrow>
			    utility.tapElement( "reserveATime_PickupDay");
					
			    utility.fastSwipe( "reserveATime_TodayText", "up");
			    
	            //tap <3PM-4PM> 
	            utility.tapElement( "reserveATime_LastSlotTime");
		}
		
		actualResult = "";

		if (!utility.getDriver().findElements(By.xpath("//*[contains(@text, 'Your order is below the minimum')]")).isEmpty())
		{
		//get text from message
		actualResult = "Your order is below the minimum";
		
		expectedResult = "Your order is below the minimum";
		
		//check message text
		utility.hardAssert(actualResult, expectedResult, name);
		

		}
	}// performTest

}// class
