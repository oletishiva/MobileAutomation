package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_06_02_VerifyPrivacyPolicy extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	
	public TC_OGA_07_06_02_VerifyPrivacyPolicy(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	
	
	@Override
	/** {@link performTest} */
	public void perform() throws InterruptedException {
		
		flowSignIn();
		
	
		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_AboutWalmartGroceryButton>
	

		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down"); 
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
		
        utility.tapElement("navigationDrawer_AboutWalmartGroceryButton");
        
        
        //click <navigationDrawer_AboutPrivacyPolicyText>
        utility.tapElement("navigationDrawer_AboutPrivacyPolicyText");
        //Thread.sleep(5000);
        
		//getText <navigationDrawer_WalmartPrivacyLink>
		actualResult = utility.getTextElement("navigationDrawer_WalmartPrivacyLink");
		expectedResult = "corporate.walmart.com/privacy-security/walmart-privacy-policy";
		utility.hardAssert(actualResult, expectedResult, name);

		
		utility.clickNativeAndroidBackButton();
       	
		utility.clickNativeAndroidBackButton();

		
	}// performTest
} // class
