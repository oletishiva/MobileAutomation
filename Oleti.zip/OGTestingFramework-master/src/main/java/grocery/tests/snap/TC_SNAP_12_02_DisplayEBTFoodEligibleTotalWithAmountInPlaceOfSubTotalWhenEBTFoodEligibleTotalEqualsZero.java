package grocery.tests.snap;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_SNAP_12_02_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalEqualsZero extends AbstractTestCase {

	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	
	private transient FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!").withTimeout(3, TimeUnit.SECONDS)
			.pollingEvery(50, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);



	public TC_SNAP_12_02_DisplayEBTFoodEligibleTotalWithAmountInPlaceOfSubTotalWhenEBTFoodEligibleTotalEqualsZero(
			final UtilityContainer utility) {
		super(utility);
	}// constructor
	
	public boolean isElementPresent(final By locator) {

		try {
			fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));

			return true;
		}

		catch (Exception e) {

			return false;
		}
	}




	@Override
	/** {@link performTest} */
	public void perform() throws Exception {


			// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemSalame" );

			// utility.tapElement( "global_ToolBarArrowBackButton" );

			Thread.sleep(5000);

			utility.tapElement("actionBar_CartButton");

	

			//Verify  the location of the field on the view
			actualResult = utility.getTextElement( "cart_EBTFoodEligibleText" ).replaceAll("\\.", "").replaceAll("\\d{3,}", "");

			expectedResult = "EBT food eligible $0";
			utility.hardAssert(actualResult, expectedResult, name);
		
		
		
		
		//for automation only - return to cart for clean
		

		utility.clickNativeAndroidBackButton();

	}// performTest
} // class

