package grocery.tests.snap;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_SNAP_04_03_VerifyAddAlcohol_itemsToCartUsingSearch extends AbstractTestCase {
	
	
/**
 * constructs {@link IndividualTestCase2} object, extending
 * {@link AbstractTestCase}, setting a local reference of
 * {@link UtilityContainer} during instantiation Dec12RJR
 */
public TC_SNAP_04_03_VerifyAddAlcohol_itemsToCartUsingSearch(final UtilityContainer utility) {
	super(utility);
}//constructor




@Override
/** {@link performTest} */
public void perform() throws Exception {
	

	
	//new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemRedWine" ) ;
	
	
		
	//utility.tapElement( "global_ToolBarArrowBackButton" );
	
	utility.tapElement( "actionBar_CartButton" );
	
	
	actualResult = utility.getTextElement( "cart_EBTFoodEligibleText" ).replaceAll("\\.", "").replaceAll("\\d{3,}", "");

	expectedResult = "EBT food eligible $0";
	utility.hardAssert(actualResult, expectedResult, name);
	

	
	
	
	utility.clickNativeAndroidBackButton();
	
	

}// performTest
} // class

