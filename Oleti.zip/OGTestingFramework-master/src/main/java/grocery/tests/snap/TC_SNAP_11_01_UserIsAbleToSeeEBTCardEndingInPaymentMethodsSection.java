package grocery.tests.snap;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_SNAP_11_01_UserIsAbleToSeeEBTCardEndingInPaymentMethodsSection extends AbstractTestCase {
	
	
/**
 * constructs {@link IndividualTestCase2} object, extending
 * {@link AbstractTestCase}, setting a local reference of
 * {@link UtilityContainer} during instantiation Dec12RJR
 */
	
	private transient FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!").withTimeout(3, TimeUnit.SECONDS)
			.pollingEvery(50, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);


	
public TC_SNAP_11_01_UserIsAbleToSeeEBTCardEndingInPaymentMethodsSection(final UtilityContainer utility) {
	super(utility);
}//constructor

public boolean isElementPresent(final By locator) {

	try {
		fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));

		return true;
	}

	catch (Exception e) {

		return false;
	}
}




@Override
/** {@link performTest} */
public void perform() throws Exception {
	



	if (isElementPresent(By.xpath(utility.getLocator("homeTab_ReserveTimeExpiredMessage")))) {

		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );

		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemSalame" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		Thread.sleep(5000);

		utility.tapElement("actionBar_CartButton");

		utility.tapElement("cart_CheckoutButton");

		utility.tapElement("reserveATime_AlertOkButton");

		// tap on Today + 6 day
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 6);
		final Date today = calendar.getTime();

		final SimpleDateFormat formatter = new SimpleDateFormat("dd", Locale.ENGLISH);
		final String todayPlusSixDate = formatter.format(today);
		System.out.println(todayPlusSixDate);

		utility.tapElement( "reserveATime_TodayPlusSixDayNumber" );

		utility.tapElement("reserveATime_9amSlotButton");

		utility.tapElement("reserveATime_ContinueButton");

	}

	else {
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );


		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemSalame" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		Thread.sleep(5000);

		utility.tapElement("actionBar_CartButton");

		utility.tapElement("cart_CheckoutButton");

	}


	
	//tap <payment_EBTToggle>
	utility.tapElement( "payment_EBTTuggle");
	
	//tap <payment_EBTCashField>
	utility.tapElement( "payment_EBTCashField");
	
	//getText <payment_EBTCashMaxAmountText>.ifExists() to [someVariable]
	String maxAmount = utility.getTextElement( "payment_EBTCashMaxAmountText" );
	
	//initialQuantity = Integer.valueOf( utility.getTextElement( "payment_EBTCashField" ) );
	
	
	//sendKeys more [someVariable] to <payment_EBTCashField> 
	utility.getDriver().findElement(By.xpath(utility.getLocator("payment_EBTCashField"))).clear();
	utility.getDriver().findElement(By.xpath(utility.getLocator("payment_EBTCashField"))).sendKeys("30.00");
	//utility.tapElement( "payment_EBTCashField");  Can't tap any button for automation, needs keyboard button
	
	
	
	
	//Verify  the location of the field on the view
	

	
	//for automation only - return to cart for clean
	utility.clickNativeAndroidBackButton();
	
	utility.tapElement( "payment_AlertOkButton" );
	
	
	
	
	utility.clickNativeAndroidBackButton();
	
	
	

}// performTest
} // class

