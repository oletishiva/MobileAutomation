package grocery.tests.snap;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;



public class TC_SNAP_08_05_UserHasNoEBTandNoCCOnFile extends AbstractTestCase {
	
	
/**
 * constructs {@link IndividualTestCase2} object, extending
 * {@link AbstractTestCase}, setting a local reference of
 * {@link UtilityContainer} during instantiation Dec12RJR
 */
	
	private transient FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!").withTimeout(3, TimeUnit.SECONDS)
			.pollingEvery(50, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);


public TC_SNAP_08_05_UserHasNoEBTandNoCCOnFile(final UtilityContainer utility) {
	super(utility);
}//constructor

public boolean isElementPresent(final By locator) {
	
	try {
		fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));

		return true;
	}

	catch (Exception e) {

		return false;
	}
}




@Override
/** {@link performTest} */
public void perform() throws Exception {
	

	
	if (isElementPresent(By.xpath(utility.getLocator("homeTab_ReserveTimeExpiredMessage")))) {
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemSalame" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );

		
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemRedWine" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );


		Thread.sleep(5000);

		utility.tapElement("actionBar_CartButton");

		utility.tapElement("cart_CheckoutButton");


		utility.tapElement("reserveATime_AlertOkButton");

		// tap on Today + 6 day
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 6);
		final Date today = calendar.getTime();

		final SimpleDateFormat formatter = new SimpleDateFormat("dd", Locale.ENGLISH);
		final String todayPlusSixDate = formatter.format(today);
		System.out.println(todayPlusSixDate);

		utility.tapElement( "reserveATime_TodayPlusSixDayNumber" );

		utility.tapElement("reserveATime_9amSlotButton");

		utility.tapElement("reserveATime_ContinueButton");

	}
	
	else {
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemSalame" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );

		
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemRedWine" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );

		Thread.sleep(5000);

		utility.tapElement("actionBar_CartButton");

		utility.tapElement("cart_CheckoutButton");

	
	}
	
	
	//Verify The continue button on the view	
	//getAttribute("enabled")
	final String PaymentContinue = utility.getDriver().findElement(By.xpath(utility.getLocator("payment_ContinueButton"))).getAttribute("enabled");
	System.out.println(PaymentContinue);
	Assert.assertEquals("false", PaymentContinue);

	
	
	
	// for automation only - return to cart for clean

	utility.clickNativeAndroidBackButton();

	utility.tapElement("payment_AlertOkButton");

	

	utility.clickNativeAndroidBackButton();
	
	
	

}// performTest
} // class





