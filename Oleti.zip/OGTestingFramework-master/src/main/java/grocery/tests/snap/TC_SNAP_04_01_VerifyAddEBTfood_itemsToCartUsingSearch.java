package grocery.tests.snap;
import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_SNAP_04_01_VerifyAddEBTfood_itemsToCartUsingSearch extends AbstractTestCase {
	
	
/**
 * constructs {@link IndividualTestCase2} object, extending
 * {@link AbstractTestCase}, setting a local reference of
 * {@link UtilityContainer} during instantiation Dec12RJR
 */
	
	
public TC_SNAP_04_01_VerifyAddEBTfood_itemsToCartUsingSearch(final UtilityContainer utility) {
	super(utility);
}//constructor



@Override
/** {@link performTest} */
public void perform() throws Exception {

	/***need to test below Roma Apr11RJR
	 * flowAddItemViaSearch2( "itemChicken" ); */
	
	System.out.println("TC Started woohoo");
	
	//new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );
	
	
	//utility.tapElement( "global_ToolBarArrowBackButton" );
	
	flowAddItemViaFavoritesSearch( "itemChicken" );
	
	System.out.println( "what happened? :D");
	
	
	utility.tapElement( "actionBar_CartButton" );
	
		System.out.println(
				" Apr18RJR Need to try command below and see what happens,"
				+ "if fails need to try return this instead of return void");
//		//should i return object this? Apr18RJR
//		tapElementAbstractClass( "actionBar_CartButton" );
	
	actualResult = utility.getTextElement( "cart_EBTFoodEligibleText" ).replaceAll("\\.", "").replaceAll("\\d{3,}", "");
	
	expectedResult = "EBT food eligible $";
	utility.hardAssert(actualResult, expectedResult, name);
	

	
	
	
	utility.clickNativeAndroidBackButton();
	
	
	

}// performTest
} // class

