package grocery.tests.snap;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


public class TC_SNAP_14_04_01_PromoAddedOnPaymentDetailsInReviewOrder extends AbstractTestCase {
	
	
/**
 * constructs {@link IndividualTestCase2} object, extending
 * {@link AbstractTestCase}, setting a local reference of
 * {@link UtilityContainer} during instantiation Dec12RJR
 */
	
private transient FluentWait<WebDriver> fluentWait = new FluentWait<>(utility.getDriver())
			.withMessage("Element didn't find!!!").withTimeout(3, TimeUnit.SECONDS)
			.pollingEvery(50, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);


final String promoCode = "ITEMTEST";

	
public TC_SNAP_14_04_01_PromoAddedOnPaymentDetailsInReviewOrder(final UtilityContainer utility) {
	super(utility);
}//constructor

public boolean isElementPresent(final By locator) {

	try {
		fluentWait.until(ExpectedConditions.presenceOfElementLocated(locator));

		return true;
	}

	catch (Exception e) {

		return false;
	}
}




@Override
/** {@link performTest} */
public void perform() throws Exception {
	



	if (isElementPresent(By.xpath(utility.getLocator("homeTab_ReserveTimeExpiredMessage")))) {


		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemRedWine" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		Thread.sleep(5000);

		utility.tapElement("actionBar_CartButton");

		utility.tapElement("cart_CheckoutButton");

		utility.tapElement("reserveATime_AlertOkButton");

		// tap on Today + 6 day
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 6);
		final Date today = calendar.getTime();

		final SimpleDateFormat formatter = new SimpleDateFormat("dd", Locale.ENGLISH);
		final String todayPlusSixDate = formatter.format(today);
		System.out.println(todayPlusSixDate);

		utility.tapElement( "reserveATime_TodayPlusSixDayNumber" );

		utility.tapElement("reserveATime_9amSlotButton");

		utility.tapElement("reserveATime_ContinueButton");

	}

	else {
		

		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemChicken" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );
		
		
		// new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemRedWine" );

		// utility.tapElement( "global_ToolBarArrowBackButton" );

			
		Thread.sleep(5000);

		utility.tapElement("actionBar_CartButton");

		utility.tapElement("cart_CheckoutButton");

	}


	
	//tap <payment_EBTToggle>
	utility.tapElement( "payment_EBTTuggle");
	Thread.sleep(5000);
	
	//tap <payment_EBTCashField>
	utility.tapElement( "payment_EBTCashField");
	
	//getText <payment_EBTCashMaxAmountText>.ifExists() to [someVariable]
	String maxAmount = utility.getTextElement( "payment_EBTCashMaxAmountText" );
	
	//initialQuantity = Integer.valueOf( utility.getTextElement( "payment_EBTCashField" ) );
	
	
	//sendKeys more [someVariable] to <payment_EBTCashField> 
	utility.getDriver().findElement(By.xpath(utility.getLocator("payment_EBTCashField"))).clear();
	utility.getDriver().findElement(By.xpath(utility.getLocator("payment_EBTCashField"))).sendKeys("30.00");
	//utility.tapElement( "payment_EBTCashField");  Can't tap any button for automation, needs keyboard button
	
	
	//tap <payment_FirstPaymentMethod>
	utility.fastSwipe("payment_EBTCashText", "up");
	utility.tapElement( "payment_FirstPaymentMethod");
	
	//tap ADD A PROMO CODE
	utility.tapElement( "payment_AddPromoCodeButton");

	//sendKeys valid promo code
	utility.getDriver().findElement(By.xpath(utility.getLocator("payment_PromoCodeApplyField"))).sendKeys(promoCode);
	
	
	//tap Apply
	utility.tapElement( "payment_PromoCodeApplyButton");
	Thread.sleep(5000);
	
	//tap <payment_PreviewTotalButton>
	utility.tapElement( "payment_PreviewTotalButton");
	
	
	//Verify  the location of the field on the view
	actualResult = utility.getTextElement("payment_PreviewPromoCodeText");
	expectedResult = "Promo Code";
	utility.hardAssert(actualResult, expectedResult, name);

	
	//for automation only - return to cart for clean
	utility.clickNativeAndroidBackButton();
	
	utility.tapElement( "payment_AlertOkButton" );
	
	
	
	
	utility.clickNativeAndroidBackButton();
	
	
	

}// performTest
} // class
