package grocery.tests.snap;

import org.openqa.selenium.By;
import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;



public class TC_SNAP_05_02_VerifyCheckOutNonactive extends AbstractTestCase {
	
	
/**
 * constructs {@link IndividualTestCase2} object, extending
 * {@link AbstractTestCase}, setting a local reference of
 * {@link UtilityContainer} during instantiation Dec12RJR
 */
public TC_SNAP_05_02_VerifyCheckOutNonactive(final UtilityContainer utility) {
	super(utility);
}//constructor



@Override
/** {@link performTest} */
public void perform() throws Exception {
	

	
	//new Flow_AddItemViaSearch(utility).searchAndAddItem( "itemSalame" );
	
		
	//utility.tapElement( "global_ToolBarArrowBackButton" );
	
	utility.tapElement( "actionBar_CartButton" );
	
	Thread.sleep(5000);
	
	
	//getAttribute("enabled")
	final String cartCheckOut = utility.getDriver().findElement(By.xpath(utility.getLocator("homeTab_CheckOutButton"))).getAttribute("enabled");
	System.out.println(cartCheckOut);
	Assert.assertEquals("false", cartCheckOut);
	

	
	
	
	utility.clickNativeAndroidBackButton();
	
	
	

}// performTest
} // class

