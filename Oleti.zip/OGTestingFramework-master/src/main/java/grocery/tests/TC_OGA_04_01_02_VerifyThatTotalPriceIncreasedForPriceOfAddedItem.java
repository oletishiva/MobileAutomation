package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

/** @author Roma Jacob Remedy May14RJR */
public class TC_OGA_04_01_02_VerifyThatTotalPriceIncreasedForPriceOfAddedItem extends AbstractTestCase {
	

	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_04_01_02_VerifyThatTotalPriceIncreasedForPriceOfAddedItem(final UtilityContainer utility) {
		super(utility);
	}//constructor
			


	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
				

		cartTotalPrice = utility.parsePriceElement( "actionBar_CartSubtotalButton" );
		
		utility.tapElement( "actionBar_SearchButton" );
		
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
	
		
		utility.tapElement( "search_Text" );
		
		
		firstItemPrice = utility.parsePriceElement( "homeTab_ItemPriceText" );
		
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
			
		utility.tapElement( "global_AmountQuantityOfItemButton" );
		
		utility.tapElement( "global_AmountDropDownMenuLastElement" );

		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		utility.tapElement( "actionBar_SearchButton" );
		
		utility.sendKeysElement( "search_SearchSrcField" ,
				utility.getTestDataItem( "itemBeef" ) );
		
		utility.tapElement( "search_Text" );
		
		secondItemPrice = utility.parsePriceElement( "homeTab_ItemPriceText" );

		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
		
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
	
		actualResult = utility.parsePriceElement( "actionBar_CartSubtotalButton" );
		
		expectedResult = cartTotalPrice + ( 3 * firstItemPrice ) + secondItemPrice;
		utility.hardAssert(actualResult, expectedResult, name);
		
	}// performTest

} // class
