package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_05_08_VerifyRemoveScreenshotFromSubmitFeedback extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_05_08_VerifyRemoveScreenshotFromSubmitFeedback(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		

		//click <actionBar_NavigationDrawerButton>
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click <navigationDrawer_SendAppFeedbackButton>
		
		//utility.fastSwipe( "navigationDrawer_SignOutButton", "down");
		
		//utility.fastSwipe( "navigationDrawer_HelloTitleText", "up");
		
		utility.tapElement("navigationDrawer_SendAppFeedbackButton");			
		
		//click <submitFeedback_ScreenshotsAddButton>
		utility.tapElement("submitFeedback_ScreenshotsAddButton");
						
		//click <submitFeedback_ImageView>
 		utility.tapElement("submitFeedback_ImageView");
 		
		//click <submitFeedback_RemoveScreenshotButton>
 		utility.tapElement("submitFeedback_RemoveScreenshotButton");

		
		utility.clickNativeAndroidBackButton();

		
	}// performTest

} // class
