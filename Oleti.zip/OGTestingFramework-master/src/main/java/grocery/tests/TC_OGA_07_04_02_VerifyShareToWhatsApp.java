package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_07_04_02_VerifyShareToWhatsApp extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_07_04_02_VerifyShareToWhatsApp(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		

		//click Menu button
		utility.tapElement("actionBar_NavigationDrawerButton");
		
		//click Refer & get $10 0ff
		utility.tapElement("navigationDrawer_ReferButton");
		
		//click Share Now
		utility.tapElement("inviteFriends_ShareButton");
				
		//getText <inviteFriends_WhatsAppText>

	    
	    //utility.fastSwipe( "WhatsApp" );
	    utility.fastSwipe( "inviteFriends_ShareNowTitle", "up");
	    
		actualResult = utility.getTextElement("inviteFriends_WhatsAppText");
		expectedResult = "WhatsApp";
		utility.hardAssert(actualResult, expectedResult, name);
		
		//click back button  //only for automation
		utility.getDriver().navigate().back();
 
		//click back button  //only for automation
		utility.getDriver().navigate().back();

		
		
	}// performTest
} // class
