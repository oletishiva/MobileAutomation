package grocery.tests;
import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


/** @author Roma Jacob Remedy May14RJR */
/** this Test Class verifies the ability to add items to cart */
public class TC_OGA_04_01_01_VerifySignedInUserIsAbleToAddItemsToCartThroughSearch extends AbstractTestCase {
	
	
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_04_01_01_VerifySignedInUserIsAbleToAddItemsToCartThroughSearch(final UtilityContainer utility) {
		super(utility);
	}//constructor
	

	
	
	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
		
		initialQuantity = Integer.valueOf( utility.getTextElement( "actionBar_CartItemCountButton" ) );

		flowAddItemViaSearch2( itemWater );
			
		utility.tapElement( "global_AmountQuantityOfItemButton" );
		
		utility.tapElement( "global_AmountDropDownMenuLastElement" );

		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		utility.tapElement( "actionBar_SearchButton" );
		
		utility.sendKeysElement( "search_SearchSrcField" , itemWater );
		
		utility.tapElement( "search_Text" );
	
		utility.tapElement( "global_IncreaseByOneItemButton" );
		
		utility.tapElement( "global_ToolBarArrowBackButton" );
	
		actualResult = Integer.valueOf( 
				utility.getTextElement( "actionBar_CartItemCountButton" ) );

		expectedResult = initialQuantity +4;
		utility.hardAssert(actualResult, expectedResult, name);
		
	}// performTest


} // class

