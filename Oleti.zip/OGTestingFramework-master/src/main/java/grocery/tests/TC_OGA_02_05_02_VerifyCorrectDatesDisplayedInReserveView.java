package grocery.tests;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;
import io.appium.java_client.MobileElement;

public class TC_OGA_02_05_02_VerifyCorrectDatesDisplayedInReserveView extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_05_02_VerifyCorrectDatesDisplayedInReserveView(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}
	

	@Override
	/** {@link performTest} */
	public void perform() {
		

		flowSignIn();
						
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
				
		
		//getText Today +7 days (22, 23, 24, 25, 26, 27, 28)
	
		final List elements = utility.getDriver().findElements(By.xpath(utility.getLocator("reserveATime_TodaysCalendarDateText")));
		
		final List<String> datesOfWeekList = new ArrayList<>();
		
		for (int i = 0; i < elements.size(); i++) {
			
		final MobileElement datesOfWeek = (MobileElement) elements.get(i);  
			
			datesOfWeekList.add(datesOfWeek.getText()); 
			System.out.println( datesOfWeekList);
			
		
			
		} // for loop
		
		
		utility.clickNativeAndroidBackButton();

	
	}// performTest


} // class

