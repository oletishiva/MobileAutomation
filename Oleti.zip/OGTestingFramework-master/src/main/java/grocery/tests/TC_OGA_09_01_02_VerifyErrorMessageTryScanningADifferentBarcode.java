package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_09_01_02_VerifyErrorMessageTryScanningADifferentBarcode extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_09_01_02_VerifyErrorMessageTryScanningADifferentBarcode(final UtilityContainer utility) {
		super(utility);
	}//constructor

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();

		utility.tapElement("actionBar_ScanButton");
		
		utility.reporter.logToAllure( "Please scan barcode manually !!!");
		utility.reporter.logToAllure( "Please scan barcode manually !!!");
		utility.reporter.logToAllure( "Please scan barcode manually !!!");
		utility.reporter.logToAllure( "Please scan barcode manually !!!");
		
		
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		actualResult = utility.getTextElement("inviteFriends_TermsSnackBarText"); //wrong element name
		expectedResult = "We can’t identify the exact\nitem you scanned.Try scanning a\ndifferent barcode.";
		utility.hardAssert(actualResult, expectedResult, name);
		
		
	}// performTest
}// class
