package grocery.tests;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


//TC_OGA_02_05_04 verify message “No Pickup Availability Today” is present after cutoff time

public class TC_OGA_02_05_04_VerifyMessageNoPickupAvailabilityTodayIsPresent extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_05_04_VerifyMessageNoPickupAvailabilityTodayIsPresent(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
						
		
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
		
		
		//getText Tomorrow day
		final Calendar calendar = Calendar.getInstance(); 
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		final Date tomorrow = calendar.getTime();

		final SimpleDateFormat formatter = new SimpleDateFormat("EEE, MMM dd", Locale.ENGLISH);
		final String tomorrowDate = formatter.format(tomorrow);
		
		
		//getText "There is no Pickup availability today."		
		
		actualResult = utility.getTextElement("reserveATime_NoAvailabilityTodayText");
				
		expectedResult = "There is no Pickup availability today. The next opening is on " + tomorrowDate;
		utility.hardAssert(actualResult, expectedResult, name);
		
		
		utility.clickNativeAndroidBackButton();

		
		
	}// performTest

	
} // class
