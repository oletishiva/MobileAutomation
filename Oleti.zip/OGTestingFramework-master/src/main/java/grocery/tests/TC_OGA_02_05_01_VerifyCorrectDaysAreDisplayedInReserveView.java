package grocery.tests;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;
import io.appium.java_client.MobileElement;

//doesn't work
//getText text “Mon” 

public class TC_OGA_02_05_01_VerifyCorrectDaysAreDisplayedInReserveView extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_05_01_VerifyCorrectDaysAreDisplayedInReserveView(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}
	

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
						
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
		
		
		//getText Mon (Tue, Wed, Thu, Fri, Sat, Sun)
	
		final List elements = utility.getDriver().findElements(By.xpath(utility.getLocator("reserveATime_WeekDayNameText")));
		

		
		final List<String> daysOfWeekList = new ArrayList<>();
		
		for (int i = 0; i < elements.size(); i++) {
			
			final MobileElement daysOfWeek = (MobileElement) elements.get(i);  
	
			daysOfWeekList.add(daysOfWeek.getText()); 
			System.out.println( daysOfWeekList);
			
		
			
		} // for loop
		
		
		utility.clickNativeAndroidBackButton();

	
	}// performTest


} // class

