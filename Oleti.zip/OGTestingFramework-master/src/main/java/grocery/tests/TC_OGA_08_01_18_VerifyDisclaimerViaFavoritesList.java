package grocery.tests;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_08_01_18_VerifyDisclaimerViaFavoritesList extends AbstractTestCase {
	

	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_08_01_18_VerifyDisclaimerViaFavoritesList(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}

	public void cleanFavoritesList() {
		//clean Favorites list
		utility.tapElement( "homeTab_ItemFavoriteToggle" );
	}

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
		flowSignIn();
										
											
		//click <actionBar_SearchButton>
		utility.tapElement( "actionBar_SearchButton" );

		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );

		//click <Text>
		utility.tapElement( "search_Text" );
		
		//click on <homeTab_ItemFavoriteToggle>
		utility.tapElement( "homeTab_ItemFavoriteToggle" );

		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		//click Favorites Tab
		utility.tapElement( "actionBar_FavoritesTab" );
		
		//click on top left item's image
		utility.tapElement( "homeTab_ImageView" );

		//getText Disclaimer		
		utility.tapElement( "itemDetails_PriceTotal");
		utility.fastSwipe( "itemDetails_PriceTotal", "up");
        
		actualResult = utility.getTextElement("itemDetails_Disclaimer");
		expectedResult = "Disclaimer";
		utility.hardAssert(actualResult, expectedResult, name);
      
        
		utility.tapElement( "global_ToolbarNavigateToPreviousScreenArrow " );
		
        cleanFavoritesList();
		
		clickHomeTab();

		
	}// performTest

}// class
