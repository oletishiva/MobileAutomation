package grocery.tests;

import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;

public class TC_OGA_10_01_01_VerifyDefaultValuesForSortFiltersForFavoritesList extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_10_01_01_VerifyDefaultValuesForSortFiltersForFavoritesList(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	public void clickHomeTab() {
		//click Home Tab  //for automation only
		utility.tapElement( "actionBar_HomeTab" );
	}

	public void cleanFavoritesList() {
		//clear Favorites List (for next test cases)
		utility.tapElement("homeTab_ItemFavoriteToggle");
	}
	

	@Override
	/** {@link performTest} */
	public void perform() throws Exception {
		
	

		flowSignIn();
						
				
		//click <actionBar_SearchButton>
		utility.tapElement("actionBar_SearchButton");
				
		//sendKeys "water" to <search_SearchSrcField>
		utility.sendKeysElement( "search_SearchSrcField" ,
				itemWater );
		
		//click <Text>
		utility.tapElement( "search_Text" );

		//click on <homeTab_ItemFavoriteToggle> on left item
		utility.tapElement("homeTab_ItemFavoriteToggle");

		//tap <global_ToolBarArrowBackButton>
		utility.tapElement( "global_ToolBarArrowBackButton" );
		
		//click Favorites Tab
		utility.tapElement("actionBar_FavoritesTab");

		//click Sort & Filter
		utility.tapElement("favoritesTab_SortAndFilterButton");
		
		//getText <sortFilterMenu_SortByCurrentlySelectedText>
		final String defaultSortByText = utility.getTextElement("sortFilterMenu_SortByCurrentlySelectedText");
		utility.reporter.logToAllure( defaultSortByText);
		Assert.assertEquals(defaultSortByText, "Department");
		
		//getText <sortFilterMenu_DepartmentsCurrentlySelectedText>
		final String defaultDepartmentsText = utility.getTextElement("sortFilterMenu_DepartmentsCurrentlySelectedText");
		utility.reporter.logToAllure( defaultDepartmentsText);
		Assert.assertEquals(defaultDepartmentsText, "All");
		
		utility.clickNativeAndroidBackButton();
 
		cleanFavoritesList();
		
		clickHomeTab();


	}// performTest


} // class
