package grocery.tests;

import org.testng.Assert;

import grocery.core.AbstractTestCase;
import grocery.core.UtilityContainer;


//getText text “About Pickup”


public class TC_OGA_02_03_VerifyInfoAboutPickupService extends AbstractTestCase {
	/**
	 * constructs {@link IndividualTestCase2} object, extending
	 * {@link AbstractTestCase}, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec12RJR
	 */
	public TC_OGA_02_03_VerifyInfoAboutPickupService(final UtilityContainer utility) {
		super(utility);
	}//constructor
	
	private void navigateBackButton() {
		//click back button  //only for automation
		utility.getDriver().navigate().back();
	}
	

	@Override
	/** {@link performTest} */
	public void perform() {
		
		flowSignIn();
		
		
		utility.tapElement( "homeTab_StorePicker" );
		//utility.tapElement("homeTab_ReserveButton");  for Snap version
		
		
		//click Pickup link
		utility.tapElement( "reserveATime_LearnMoreAboutPickup" );

		//getText “About Pickup"
		final String alertAboutPickup = utility.getTextElement( "reserveATime_AlertTitle" );
		System.out.printf("\n RJR: The text read was: %s" , alertAboutPickup);
		
		Assert.assertEquals("About Pickup", alertAboutPickup);	
		
		//click OK to close modal message
		utility.tapElement( "reserveATime_AlertOkButton" );
		
		utility.clickNativeAndroidBackButton();


	}// performTest


} // class

