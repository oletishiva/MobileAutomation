package grocery.utils;
/** @author Roma Jacob Remedy Jan02RJR */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogEntry;
import org.testng.TestListenerAdapter;

import com.google.common.base.Stopwatch;

import io.appium.java_client.AppiumDriver;
import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

/**
 * The purpose of this class is to act as a reporter for the Remedy Testing
 * Framework, This class will hold in itself, the logging configuration aspects
 * as well as the screenshot configurations for the testing Framework. Dec29RJR
 */
public class Reporter extends TestListenerAdapter {
	
	/** logger {@link Logger} Jan02RJR */
	public transient Logger logger = LogManager.getLogger(this.getClass().getSimpleName() + ".class");

	
	/** get a reference to this service class with
	 * {@link Reporter#getreporterinstance()}. Dec17RJR */
	private static Reporter reporterInstance;
	
	
	/**
	 * googStopWatch {@link Stopwatch} measures method execution duration Feb27RJR
	 */
	private transient Stopwatch googleStopwatch;
	
	/** Reporter constructor constructs an object of @{link Reporter} Feb27RJR */
	public Reporter() {
		googleStopwatch = Stopwatch.createUnstarted();
	}//constructor
	
	
	
	
	/** logToAllure will print [ message ] to the console, store to logger and
	 * allure and log it to allure Feb21RJR */
	@Step("{0}")
	public <T> void logToAllure( final String message ) {
		logger.info( message );
	} //logToAllure
	
	
	/** loggerNoAllureDebug will print [ message ] to the console, store to logger,
	 * But WONT store to allure Feb21RJR */
	public <T> void loggerNoAllureDebug( final String message ) {
		logger.debug( message );
	} //loggerNoAllureDebug
	
	
	
	@Attachment(value = "{1}", type = "image/png")
	public byte[] makeScreenShotAndAttachToAllure(WebDriver driver, String screenShotName) {

		screenShotName =  screenShotName+Thread.currentThread().getStackTrace()[3].getMethodName()+".png";
		
		try {
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File targetFile = new File("target/Screenshots", screenShotName);
					targetFile.getParentFile().mkdirs();
			FileUtils.copyFile(screenshotFile, targetFile);

			logToAllure("\n\n Screenshot Filename is: " + screenShotName+Thread.currentThread().getStackTrace()[5].getMethodName()+".png");

			return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		} catch (IOException e) {
			logToAllure(" An exception ocurred while taking screenshot and method "
					+ e.getCause() + Thread.currentThread().getStackTrace()[2].getMethodName() + "%n%n");
			return null;
		}
	}

	/**
	 * @return a reference of an instantiated Reporter object Feb21RJR
	 */
	public static Reporter getreporterInstance() {
		if (reporterInstance == null) {
			reporterInstance = new Reporter();
		}
		return reporterInstance;
	} // getreporterInstance

	
	/** captureLog captures the logcat from the device Jan02RJR */
	public void captureLog( AppiumDriver<?> driver ) throws IOException , FileNotFoundException {
		    DateFormat df = new SimpleDateFormat("MMMddHHmm");
		    Date today = Calendar.getInstance().getTime();
		    String reportDate = df.format(today);
		    String logPath = "./target/Logs/";
		    logToAllure(String.format( "%n%n Saving device log... %s",driver.getSessionId() ));
		    List<LogEntry> logEntries = driver.manage().logs().get("logcat").filter(Level.ALL);
		    String filename = logPath + "GroceryLogcat_" + reportDate + ".txt";
		    File logcatfile = new File(filename);
		    
		if (!logcatfile.exists()) {
			logcatfile.createNewFile();
			logToAllure(String.format("%n%n Logcat captured: \t %s %n", logcatfile));
		}
		    PrintWriter log_file_writer;
			try {
				log_file_writer = new PrintWriter(logcatfile);
		    log_file_writer.println(logEntries );
		    log_file_writer.flush();
		    logToAllure(String.format( driver.getSessionId() + " %n Parsing log - Done."));
		    } catch (FileNotFoundException e) {
			e.printStackTrace();
		}	
	}

	
	/** measureMethodDuration restarts measuring method duration. Feb27RJR */
	public void measureMethodDuration() {
		googleStopwatch.reset();
		googleStopwatch.start();
	}// measureMethodDuration
	
	/** logMethodDuration will logs the duration of the method Feb27RJR */
	public void logMethodDuration() {
		long duration = googleStopwatch.elapsed( TimeUnit.MILLISECONDS );
		logToAllure( String.format( " \t200  duration %-4dms  \t%s %n",
				duration , Thread.currentThread().getStackTrace()[3].getMethodName() ) );
	}//logMethodDuration
	
} //class


