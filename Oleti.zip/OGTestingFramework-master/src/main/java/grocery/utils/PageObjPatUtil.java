package grocery.utils;
/** @author Roma Jacob Remedy Dec13RJR */

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * PageObjPatUtil reads the mappedElements.xlsx document, parsing the
 * element names and locators an creating a mappedElementMap object where
 * locator xPaths can be returned when calling the element Name as key this is
 * an Excel alternative to PageFactory Dec17RJR
 */
public class PageObjPatUtil {

	/** declaring the objects name Dec15RJR */
	protected transient String name;
	
	/** {@link ExcelParserUtil} will parse the mappedElement.xlsx Dec15RJR */
	protected transient ExcelParserUtil excelParserUtil;
	
	/** mapShtNameLastRow stores the names of all the sheets in workbook Dec17RJR */
	protected transient Map<String , Integer> mapShtNameLastRow;
	
	/**
	 * mappedElementsMap member will store the Element Key Value pairs from the
	 * parsed mappedElements.xlsx document Dec15RJR
	 */
	private transient Map< String , String > mappedElementsMap;
	
	
	/**
	 * KEY_COLUMN specifies Element Key column in the
	 * mappedElements.xlsx doument Dec15RJR
	 */
	private static final transient int KEY_COLUMN = 1;
	/**
	 * KEY_COLUMN specifies Element Value column in the
	 * mappedElements.xlsx doument Dec15RJR
	 */
	private static final transient int VALUE_COLUMN = 6;
	/**
	 * INITIALPARSEROW specifies from which row in the
	 * mappedElements.xlsx doument to start parsing Element Key Value's Dec15RJR
	 */
	private static final transient int INITIALPARSEROW = 5;
	
	/** the name of the element in mappedElements Excel Document Dec17RJR */
	protected transient String elementName = "elementNotMapped";
	/** the xPath of the element in mappedElements Excel Document Dec17RJR */
	protected transient String elementNameXPath;
	
	/** lastRowOnSheet will store demeter last row on the sheet value */
	protected transient int lastRowOnSheet;
	/** sheetName will store demeter {@link Sheet} value */
	protected transient String sheetName;
	/** lastRowInteger will store demeter {@link Integer} value */
	protected transient Integer lastRowInteger;
	
	/**
	 * Creates instance of {@link PageObjPatUtil} Dec11RJR.
	 * 
	 * @param inputParserUtil
	 */
	public PageObjPatUtil() {
		name = "PageObjPatUtilOBJ";
	}//constructor
	
	

	/**
	 * getMappedElementsMap returns the map of Element Name xPath Locator
	 * Pairs Dec17RJR
	 */
	public Map< String , String > getMappedElementsMap() {
		return mappedElementsMap;
	}
	
	
	
	/**
	 * createMappedElementsMAPobject creates a KeyValue Pairs Map of parsed
	 * elements from the mappedElements.xlsx document Dec17RJR
	 * 
	 * @param locMappedElements String
	 */
	public void createMappedElementsMAP(final String locMappedElements) {

		try {
			
			excelParserUtil = new ExcelParserUtil();
			
			mappedElementsMap = new HashMap<String , String>();

			/** {@link parseWorkbook} */
			excelParserUtil.parseWorkbook(locMappedElements);
			
			mapShtNameLastRow = excelParserUtil.getMapOfShetNamesAndLastRows();
			
			
			for (final String sheetName : mapShtNameLastRow.keySet()) {
				this.sheetName = sheetName;
				
				if ("Details".equals(sheetName)) {
					continue;
				}//if statement
				
				/** parsing the value of the last row on the sheet Dec24RJR */
				lastRowInteger = mapShtNameLastRow.get(sheetName);
				lastRowOnSheet = lastRowInteger.intValue();
				
				
				for (int rowNumber = INITIALPARSEROW; rowNumber <= lastRowOnSheet; rowNumber++) {
					

					elementName = excelParserUtil.getCellValue(sheetName, rowNumber, KEY_COLUMN);
					elementNameXPath = excelParserUtil.getCellValue(sheetName, rowNumber, VALUE_COLUMN);
					/**
					 * adding the elementName and elementNameXPath KeyValue
					 * Pairs into the mappedElementsMap
					 */
					mappedElementsMap.put(elementName, elementNameXPath);
				} // inner for loop
				
			} //outer for loop

		} catch (Exception e) {
			System.out.printf("\n RJR: Exception happened in %s \n The Exception was: %s \n and \n",
					Thread.currentThread().getStackTrace()[1].getMethodName() , e );
			e.printStackTrace();
		} // try-catch
	}// createMappedElementsMAP
				
}//class
