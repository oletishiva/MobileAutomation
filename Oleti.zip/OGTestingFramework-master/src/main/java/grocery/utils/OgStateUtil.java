package grocery.utils;
/** @author Roma Jacob Remedy Mar23RJR */

import java.util.HashMap;
import java.util.Map;

/**
 * OgStateUtil stores the state of the application, helping handle unforeseen
 * events in the app Feb21RJR
 */
public class OgStateUtil {
	

	/** *** reporter used for logging of messages and screenshots */
	public transient Reporter reporter = Reporter.getreporterInstance();
	
	/** ogaFlagsMap stores the states of individual app flags Mar22RJR */
	private transient Map<String, Boolean> ogFlagsMapNew;
	/**
	 * ogFlagsArr contains all the possible flags for the Oga Programs Mar22RJR
	 */
	private final transient String[] ogFlagsArr = { "signInState", "isUserInHomeScreen"
		, "flag_SubstituteOffer" , "flag_SkipIsUserInHomeScreen"
		, "flag_DidTestCaseFinish" };
	
	/** The OgStateUtil constructor initializes the ogStateMap */
	public OgStateUtil() {
		reporter.logToAllure( "Constructing OgStateUtil");
		initOgaState();
	}// constructor
	
	
	
	/**
	 * initOgaState initializes the HashMap Collection representing various OGA
	 * features and their particular state Feb21RJR
	 */
	private void initOgaState() {
		reporter.logToAllure( "Initializing the ogStateMap" );

		ogFlagsMapNew = new HashMap<String, Boolean>();
		reporter.loggerNoAllureDebug( "setting each of the flags to false" );
		for ( final String someFlag : ogFlagsArr ) {
			ogFlagsMapNew.put(someFlag, false);
		}//for each loop
		
	}//initOgaState


	/** getFlagStateOf returns the state of the app flag
	 * @param flagName {@link OgStateFlags} 
	 * 				flagName is the name of the a particular flag
	 * @return ogStateFlagsIs Boolean
	 * 				ogStateFlags Is represents the state of the app flag
	 * 				`true` means on and `false` means off feature Mar22RJR */
	public Boolean getOgFlagState( final String flagName ) {
		Boolean ogStateFlagsIs;
		reporter.loggerNoAllureDebug( String.format(
				"\n getOgFlagState: %s \n" , flagName) );
		ogStateFlagsIs = ogFlagsMapNew.get( flagName );
		
		return ogStateFlagsIs;
	}//getOgFlagState
	
	
	/** setOgFlag sets the state of the particular Oga flag
	 * @param flagName {@link ogFlagsArr} 
	 * 				flagName is the name of the a particular flag
	 * @param flagState Boolean
	 * 				flagState represents the state of the app flag
	 * 				`true` means on and `false` means off feature Mar22RJR */
	public void setOgFlag( final String flagName , final Boolean flagState ) {
		reporter.loggerNoAllureDebug( String.format(
				"\n setting OgFlagState: of %s to %s \n" , flagName, flagState) );
		ogFlagsMapNew.put( flagName , flagState );
		
	}//setFlagState

	
} //class
