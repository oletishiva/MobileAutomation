package grocery.utils;
/** @author Roma Jacob Remedy Dec24RJR */

import static java.lang.System.getProperty;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
 * InputParserUtil parses the userInput into known Testing Framework Key Value
 * Pairs Dec07RJR
 */
public class InputParserUtil implements InputParserUtilInterface {

	/** driverType is the type of the WebDriver to create */
	private String driverType;
	/** udid is the identifier for the device we are automating */
	private String udid;
	/** apppackage is the package of the app */
	private String apppackage;
	/** appactivity is the mainActivity of the app */
	private String appactivity;
	/** bundleid is the ios app */
	private transient String bundleid;
	/** resetappiumondevice directs appium whether or not to clear local cach
	 * and reinstall the app for the session the options available are:
	 * @link {fullReset}
	 *            Driver DO FULL-RESET by uninstall and install client (slowest)
	 * @link {fastReset}
	 *            Driver DO FAST-RESET clearing cache and settings no reinstall
	 * @link {noReset}
	 *            Driver DO NORMAL start of app on device (fastest) Dec12RJR */
	private String resetappiumdevice;
	/**
	 * locMappedElements is the physical path to the mappedElements
	 * document Dec24RJR
	 */
	private transient String locMappedElements;
	/**
	 * locOfTestData is the physical path to the ogaTestData
	 * properties file Feb22RJR
	 */
	private transient String locOfTestData;
	/**
	 * mappedCLA is a {@link HashMap} that stores all the Frameworks arguments
	 * Dec24RJR
	 */
	private transient Map<InputCLA,String> mappedCLA;
	
	/** InputParserUtil constructor sets all the variables during instantiation 
	 * @throws IOException */
	public InputParserUtil() throws IOException {
		instantiateMappedCLA();
	} //constructor 
	
	/** instantiateMappedCLA instantiates mappedCLA 
	 * @throws IOException */
	public void instantiateMappedCLA() throws IOException {
		mappedCLA = new HashMap<InputCLA , String>();

		/** stream loads the property file by searching for it anywhere in the project
		 * Apr15RJR */
		final InputStream stream = ClassLoader.getSystemResourceAsStream("grocery.properties");
		final Properties props = new Properties();
		props.load(stream);
		
		for ( InputCLA someEnum : InputCLA.values()) {
			if ( getProperty( someEnum.toString() ) == null) {
				mappedCLA.put( someEnum, props.getProperty( String.valueOf(someEnum) ));				
			} else {
				mappedCLA.put( someEnum , getProperty( String.valueOf(someEnum) ));
			} // if else
			
		} // for each loop
	}//instantiateMappedCLA();
	
	@Override
	/** setter for driverType */
	public void setDriverType(final String driverType) {
		this.driverType = String.valueOf( getProperty(driverType) );
	}

	@Override
	/** getter for driverType */
	public String getDriverType() {
		return driverType;
	}

	@Override
	/** setter for udid */
	public void setUdid(final String udid) {
		this.udid = String.valueOf( getProperty(udid) );
	}

	@Override
	/** getter for udid */
	public String getUdid() {
		return udid;
	}
	
	@Override
	/** setter for apppackage */
	public void setApppackage(final String apppackage) {
		this.apppackage = String.valueOf( getProperty(apppackage) );
	}

	@Override
	/** getter for apppackage */
	public String getApppackage() {
		return apppackage;
	}

	@Override
	/** setter for appactivity */
	public void setAppactivity(final String appactivity) {
		this.appactivity = String.valueOf( getProperty(appactivity) );
	}
	@Override
	/** getter for appactivity */
	public String getAppactivity() {
		return appactivity;
	}
	
	@Override
	/** setter for bundleid */
	public void setBundleId(final String bundleid) {
		this.bundleid = String.valueOf( getProperty(bundleid) );
	}
	/** getter for bundleid */
	public String getBundleId() {
		return bundleid;
	}
	
	@Override
	/** setter for resetappiumdevice */
	public void setResetappiumdevice(final String resetappiumdevice) {
		this.resetappiumdevice = String.valueOf( getProperty(resetappiumdevice) );
	}
	@Override
	/** getter for resetappiumdevice */
	public String getResetappiumdevice() {
		return resetappiumdevice;
	}

	
	@Override
	/** setter for pathToMappedElementsWorkbook */
	public void setPathToMappedElementsWorkbook(final String locMappedElements) {
		this.locMappedElements = String.valueOf( getProperty(locMappedElements) );
	}
	/** getter for pathToMappedElementsWorkbook */
	public String getPathToMappedElementsWorkbook() {
		return locMappedElements;
	}
	
	/** setter for locOfTestData Feb22RJR */
	public void setNameOfTestData( final String locOfTestData ) {
		this.locOfTestData = String.valueOf( getProperty(locOfTestData) );
	}
	/** getter for locOfTestData Feb22RJR */
	public String getNameOfTestData() {
		return locOfTestData;
	}
	
	
	@Override
	/** returns {@link mappedCLA} */
	public Map<InputCLA, String> getMappedCLA() {
		return mappedCLA;
	}
	
}//InputParserUtil

