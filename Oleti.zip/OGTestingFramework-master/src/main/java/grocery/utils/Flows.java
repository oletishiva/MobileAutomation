package grocery.utils;
/** @author Roma Jacob Remedy Apr11RJR */

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.TestListenerAdapter;

import grocery.core.UtilityContainer;

/**
 * The purpose of this class is to facilitate all the common flows within the
 * OGA app Apr11RJR
 */
public class Flows extends TestListenerAdapter {

	/** logger {@link Logger} Jan02RJR */
	public transient Logger logger = LogManager.getLogger(this.getClass().getSimpleName() + ".class");

	/** someVariable is a generic string helper variable Apr24RJR */
	protected transient String someVariable;
	
	/** orderNumberFlows helper variable stores the orderNumber Apr28RJR */
	protected transient String orderNumberFlows;
	
	
	/** the reference to this service class with
	 * {@link Flows#getFlowsInstance()}. Dec17RJR */
	private static Flows flowsInstance;
	
	/** {@link UtilityContainer} */
	protected transient static UtilityContainer utility;
	
	/** Flows constructor constructs an object of @{link Flows} Feb27RJR */
	public Flows() {
	}//constructor
	
	/**
	 * searchAndAddItem step sequence will tap actionBar_SearchButton ;
	 * sendKeysElement actionBar_SearchButton w itemName ; tap search_Text ; tap
	 * global_AddVeryFirstItemOnTopLeftButton;
	 * 
	 * @param itemTest String
	 * @return this May14RJR
	 */
	public Object addToCartSearchedItem( UtilityContainer utility , final String itemName ) {
		this.utility = utility;
		
		utility.tapElement( "actionBar_SearchButton" );

		utility.sendKeysElement( "search_SearchSrcField" , itemName );
		
		utility.tapElement( "search_Text" );
		
		utility.tapElement( "global_AddVeryFirstItemOnTopLeftButton" );
			
	
		return this;
	} //searchAndAddItem
	
	
	
	
	
	/** cleanCart will clean the cart in OGA May10RJR */
	public synchronized Object flowCleanCart( UtilityContainer utility ) {
		this.utility = utility;
		
		utility.reporter.logToAllure( "flow_cleanCart called,"
				+ " given `cart_ActionBarCartCountText` having delta > 0 items ");
		
		int amountOfItemsInCart = 
				Integer.valueOf( utility.getTextElement( "cart_ActionBarCartCountText" ));
		
		
		if ( amountOfItemsInCart > 0 ) {

			utility.tapElement( "actionBar_CartButton" );
		
				while ( utility.getDriver().findElements(By.xpath("//*[contains(@resource-id,'com.walmart.grocery:id/title')]")).size() > 0) {	
				utility.reporter.logToAllure("in the clean loop");
				
				utility.tapElement( "cart_QuantityView" );
			
				utility.tapElement( "cart_DropDownButton" );
			
				utility.tapElement( "homeTab_RemoveDropDownMenu" );
			
				amountOfItemsInCart = 
						Integer.valueOf( utility.getTextElement( "cart_ActionBarCartCountText" ));
				
			} //while loop
			utility.reporter.logToAllure("out of the clean loop waiting five seconds for last item to be cleared");
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String cartCountAfterDeleted =
					utility.getTextElement( "cart_ActionBarCartCountText" );
			int countAfterDeleted = Integer.parseInt(cartCountAfterDeleted);
			utility.reporter.logToAllure("Items in cart at end of this flow " + countAfterDeleted);
			
			Assert.assertEquals(0, countAfterDeleted);
			utility.reporter.logToAllure(" Navigating back to home screen from flowCleanCart");
			utility.clickNativeAndroidBackButton();
			
		} // if statement 

	
		return this;
	}
	
	
	/**
	 * addFavoriteItem step sequence will tap the `add` button on a particular
	 * itemName to add it into the cart from favorites it will tap
	 * actionBar_FavoritesTab ; tapVar global_AddVeryFirstItemOnTopLeftButton with
	 * itemName
	 * 
	 * @param itemTest String
	 * @return this Apr11RJR
	 */
	public Object flowAddToCartFavoriteItem( UtilityContainer utility , final String itemName ) {
		this.utility = utility;
		
		utility.tapElement( "actionBar_FavoritesTab" ); //

		return this;
	} //addFavoriteItem
	
	
	
	// below is not complete Apr23RJR
	@Deprecated
	public Object flowEbtCheckoutPlaceorder(final String cvv) {
		
		flowCheckOutNewOrderReserveTime();
		
		flowPaymentEbtMaxFoodMaxCashCC();
		
		utility.tapElement( "payment_ContinueButton" );
		
		
		utility.reporter.logToAllure(  "Below is a fluent wait to check"
				+ " for alcohol disclosure element -"
				+ " I need to add a hard check for another"
				+ "element if its present than check if alcohol disclosure is there ");
		if ( utility.isElementFluentlyPresent( "reviewOrder_AlcoholDisclosureCheckbox" )) {
			utility.reporter.logToAllure( " AlcoholDisclosure Checkbox present ");
			utility.tapElement( "reviewOrder_AlcoholDisclosureCheckbox" );
		}//if alcohol disclosure statement
		
		
		
		
		orderNumberFlows = utility.getTextElement( "orderConfirmation_OrderNumberText" );
				
		utility.tapElement( "global_ToolbarCloseScreenButton" );

		return this;
	} //ebtCheckoutPlaceorder
	
	
	/**
	 * flowCheckOutNewOrderReserveTime will initiate the checkout sequence, by
	 * tapping the relevant elements and calling another flow
	 * {@link reserveATime} Apr23RJR
	 */
	public Object flowCheckOutNewOrderReserveTime() {
		
		utility.tapElement( "actionBar_CartButton" );
		
		utility.tapElement( "cart_StartNewOrderButton" );
		
		utility.tapElement( "cart_ContinueButton" );
		
		flowReserveATime();
		
		return this;
	} //flowCheckOutNewOrderReserveTime
	
	
	/**
	 * flowReserveATime will interact with the relevant elements to reserve a for a
	 * pickup/deliver the default date is today+6 and the default time window is
	 * 9-10am Apr23RJR
	 */
	public Object flowReserveATime() {
		
		utility.tapElement( "reserveATime_TodayPlusSixDayNumber" );
		
		utility.tapElement( "reserveATime_9amSlotButton" );
		
		utility.tapElement( "reserveATime_ContinueButton" );
		
		return this;
	} //flowReserveATime
	
	
	/**
	 * flowPaymentEbtMaxFoodMaxCashCC handles the distrebution of payment,
	 * maximizing EBT Food, than Maximicing EBT Cash, than the rest on CC, if no
	 * EBT Presnt it will charge all on CC Apr28RJR
	 */
	private Object flowPaymentEbtMaxFoodMaxCashCC() {
		// TODO Auto-generated method stub
		
		utility.tapElement( "payment_EBTToggle" );
		
		if ( utility.isElementFluentlyPresent( "payment_EBTToggle" )) { 
			utility.reporter.logToAllure( " Toggling EBT ");
			utility.tapElement( "payment_EBTToggle" );
			utility.tapElement( "payment_EBTCashField" );
			
			if ( utility.isElementFluentlyPresent( "payment_EBTCashMaxAmountText" )) {
				utility.reporter.logToAllure( " Parsing Max EBTCash ");
				someVariable = utility.getTextElement( "payment_EBTCashMaxAmountText" );
				utility.sendKeysElement( "payment_EBTCashField" , someVariable );
				utility.getDriver().navigate().back();
			}//inner if-statement
			
		} //outer if-statement
		
		if ( ! utility.isEnabledElement( "payment_ContinueButton" )) {
			utility.reporter.logToAllure( "selecting first CC Delta balance > 0 " );
			utility.reporter.logToAllure( " Does this work correctly with EBT?????");
			utility.reporter.logToAllure( " and Does this work correctly with Mixed EBT/CC");
			utility.tapElement( "payment_FirstPaymentMethod" );
		} //if statement
		
		return this;
	} //flowPaymentEbtMaxFoodMaxCash

	
	

	/**
	 * @return a reference of an instantiated Reporter object Apr11RJR
	 */
	public static Flows getFlowsInstance() {
		if (flowsInstance == null) {
			flowsInstance = new Flows();
		}
		return flowsInstance;
	} // getreporterInstance


	
} //class