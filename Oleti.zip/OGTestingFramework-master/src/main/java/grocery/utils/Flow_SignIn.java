package grocery.utils;
import grocery.core.UtilityContainer;

/**
 * The Flow_SignIn contains the SignIn sequence that is executed each time the
 * suite starts, and is called from the @BeforeSuite method from the
 * {@link UtilityContainer} Jan02RJR
 */
public class Flow_SignIn {
	
	/** {@link UtilityContainer} */
	protected transient static UtilityContainer utility;
	
	/**
	 * the state of signed being signed in {@link Flow_SignIn} Jan02RJR
	 */
	private static Boolean signInState;

	/**
	 * Constructs {@link Flow_SignIn} object, setting a local reference of
	 * {@link UtilityContainer} during instantiation Dec18RJR
	 */
	public Flow_SignIn(final UtilityContainer utility) {
		this.utility = utility;
	}//constructor
	
	
	/** signIn will as an existing user to OGA Jan02RJR */
	public Object signIn() {

		
		utility.tapElement( "skipScreen_SkipButton" );
		
		utility.sendKeysElement( "zipCode_EnterZipCodeField" , "80211" );//comment li8ne
		utility.tapElement( "zipCode_GoButton" );//comment li8ne
	utility.tapElement( "signIn_SignInButton" ); //remove line old build Dec24RJR
	
		
	utility.sendKeysElement( "signIn_EmailField" , "walmartsunnyvale@gmail.com" );
	
	utility.tapElement( "signIn_EmailField" );
	
	utility.sendKeysElement( "signIn_PasswordField" , "PasswordMissing" );
	
	utility.tapElement( "signIn_PasswordField" );
	
	System.out.println("Please manually click Sign In button !!");
	System.out.println("Please manually click Sign In button !!");
	System.out.println("Please manually click Sign In button !!");
	System.out.println("Please manually click Sign In button !!");
	
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
	
	return this;
	} //signIn
	
	/** @return a reference to signInState Jan02RJR */
	public static boolean getSignInState() {
		if (utility == null || signInState == null) {
			signInState = false;
		}
		return signInState;
	} // getSignInState

	
	
}
