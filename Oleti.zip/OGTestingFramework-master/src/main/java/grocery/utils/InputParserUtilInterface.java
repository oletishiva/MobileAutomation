package grocery.utils;

import java.util.Map;

/** interface for the InputParserUtil Dec07RJR */
public interface InputParserUtilInterface {
	
	// -Dgroups=E2E,Regression (This specifies the testNG groups to execute
	// -Denv= (environments usually prod/uat/dev/local
	/// -DdriverType= (androidnative, androidchrome, iosnative, osxchrome and
	// others
	// -Dgroup= (the group of tests we'd like to execute
	/// -Dudid= (the udid of a device
	/// -Dapppackage= (name of package for mobile testing
	/// -Dappactivity= (name of activity for mobile testing
	// -Dmdn= (mobile device number [a phone number]
	// -Duser= (some username
	// -Dpass= (somepassword
	// -Demail= (someemail
	// -Ddb= (somedatabase
	
	/**
	 * InputCLA enum contains the default CLA arguments when launching the
	 * testing Framework Feb23RJR
	 */
	enum InputCLA { driverType, udid , apppackage , appactivity , bundleid
		, resetappiumdevice , locMappedElements , groups , env
		, mdn , user , pass , email , db , TesterName , nameOfTestData
	}//enum InputCLA
		
	/** setter for driverType */
	void setDriverType(final String driverType);

	/** getter for driverType */
	String getDriverType();

	/** setter for udid */
	void setUdid(final String udid);

	/** getter for udid */
	String getUdid();

	/** setter for apppackage */
	void setApppackage(final String apppackage);

	/** getter for apppackage */
	String getApppackage();

	/** setter for appactivity */
	void setAppactivity(final String appactivity);

	/** getter for appactivity */
	String getAppactivity();

	/** setter for bundleid */
	void setBundleId(final String bundleid);

	/** getter for bundleid */
	String getBundleId();

	/** setter for resetappiumdevice */
	void setResetappiumdevice(final String resetappiumdevice);

	/** getter for resetappiumondevice */
	String getResetappiumdevice();

	/** setter for locMappedElements */
	void setPathToMappedElementsWorkbook(final String locMappedElements);

	/** getter for pathToMappedElementsWorkbook */
	String getPathToMappedElementsWorkbook();
	
	/** setter for locNameOfTestData Apr15RJR */
	void setNameOfTestData( final String NameOfTestData );

	/** getter for getNameOfTestData Apr15RJR */
	String getNameOfTestData();

	// Map<String,String> map
	/** mappedCLA will store all the captured CLA */
	Map<InputCLA, String> getMappedCLA();

} // interface
