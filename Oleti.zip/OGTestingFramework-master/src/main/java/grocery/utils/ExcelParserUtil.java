package grocery.utils;
/** @author Roma Jacob Remedy Dec24RJR */

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/** The ExcelParserUtil class is used to Parse Excel documents
 * 
 *  This Particular ExcelParser can Parse {@link xlsx} documents
 *  Dec13RJR */
public class ExcelParserUtil {
	
	/** Microsoft Excel document @{link Workbook} */
	protected transient Workbook workbook;
	/** sheet will store demeter {@link Sheet} values */
	protected transient Sheet sheet;
	/** row will store demeter {@link row} values */
	protected transient Row row;
	/** cell will store demeter {@link cell} values */
	protected transient Cell cell;
	/** cellValue will store demeter String values */
	protected transient String cellValue;
	
	/**
	 * mapShtNameLastRow stores the name and Last row variable of all the sheets
	 * in workbook Dec17RJR
	 */
	protected transient Map<String , Integer> mapShtNameLastRow;
	
	
	/**
	 * parseWorkbook will instantiate a new Instance {@link Workbook}
	 * 
	 * @param {workbookLocation} String
	 * @throws IOException @throws InvalidFormatException
	 * @throws EncryptedDocumentException Dec17RJR
	 */
	public void parseWorkbook(final String workbookLocation)
			throws EncryptedDocumentException, InvalidFormatException, IOException {
		
		final FileInputStream fileInputStream = new FileInputStream(workbookLocation);
		workbook = WorkbookFactory.create(fileInputStream);
	}// parseWorkbook
	
	
	/** getter of workbook {@link workbook} Dec17RJR */
	public Workbook getWorkbook() {
		return workbook;
	}// getWorkbook
	
	
	/**
	 * getListOfSheets returns an ArrayList<String> of sheet names from a
	 * workbook Dec17RJR
	 * 
	 * @return listOfSheets
	 */
	public Map<String , Integer> getMapOfShetNamesAndLastRows() {
		//instantiating listOfSheets Dc17RJR
		
		mapShtNameLastRow = new HashMap<String, Integer>();
		
		// iterating the sheets and parsing the elements Dec17RJR
		final Iterator<Sheet> sheetIterator = workbook.sheetIterator();
		while (sheetIterator.hasNext()) {
			this.sheet = sheetIterator.next();
			mapShtNameLastRow.put(sheet.getSheetName() , sheet.getLastRowNum() );
		} // while loop
		
		return mapShtNameLastRow; 
	}// getListOfSheets
	
	/**
	 * getCellValue returns the cellValue from a sheet
	 * @param sheetName String
	 * @param rowNumber int
	 * @param columnNumber int
	 * @return {@value cellValue} String Dec13RJR */
  	public String getCellValue( final String sheetName , final int rowNumber , final int columnNumber ) {
  		
  		
  		sheet = workbook.getSheet(sheetName);
  		
  		//// below saves me from exceptions Dec19RJR
  		if ( sheet.getRow(rowNumber) == null) {
  			cellValue = "missing xpath in mappedelements.xlsx";
		} else {

			row = sheet.getRow(rowNumber);

			/**
			 * MissingCellPolicy.RETURN_BLANK_AS_NULL bellow skips blanks in
			 * excel Nov16RJR
			 */
			if (row.getCell(columnNumber, MissingCellPolicy.RETURN_BLANK_AS_NULL) == null) {
				cellValue = "missing xpath in mappedelements.xlsx";
			} else {

				cell = row.getCell(columnNumber);
				cellValue = cell.getStringCellValue();
			} // inner if statement
  		} //outer else
  		return cellValue;
  	}//getElementPath
	
}//class
