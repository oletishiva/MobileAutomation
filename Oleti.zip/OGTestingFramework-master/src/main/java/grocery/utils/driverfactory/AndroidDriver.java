package grocery.utils.driverfactory;
/** @author Roma Jacob Remedy Dec14RJR */

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;

import grocery.utils.InputParserUtil;
import grocery.utils.InputParserUtilInterface.InputCLA;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.remote.MobileBrowserType;
import io.appium.java_client.remote.MobileCapabilityType;

/** AndroidDriver specifically handles with Android Device Drivers Dec11RJR */
class AndroidDriver extends AbstractDriver {
	
	
	/** logger {@link Logger} Jan02RJR */
	public transient Logger logger = LogManager.getLogger(this.getClass().getSimpleName() + ".class");

	/** Creates instance of {@link AndroidDriver} Dec11RJR */
	public AndroidDriver(final InputParserUtil inputParserUtil) {
		super();
		this.inputParserUtil = inputParserUtil;
	}//constructor
	
	@Override
	/** defining android specific capabilities Dec10RJR */
	protected void setCapabilities() {

			mappedCLA = inputParserUtil.getMappedCLA();

			final String driverType = mappedCLA.get(InputCLA.driverType);
			final String udid = mappedCLA.get(InputCLA.udid);
			final String apppackage = mappedCLA.get(InputCLA.apppackage);
			final String appactivity = mappedCLA.get(InputCLA.appactivity);
			final String resetappiumdevice = mappedCLA.get(InputCLA.resetappiumdevice);
			
		
			capabilities.setCapability("udid", udid);
			capabilities.setCapability("appPackage", apppackage);
			capabilities.setCapability("appActivity", appactivity);
			capabilities.setCapability("deviceName", "My Android");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("platformVersion", "5.1");
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
			capabilities.setCapability(MobileCapabilityType.TAKES_SCREENSHOT, "true");

			capabilities.setCapability("unicodeKeyboard", true);
			capabilities.setCapability("resetKeyboard", true);
		
		if ("fullReset".equals(resetappiumdevice)) {
			logger.info(" Driver DO FULL-RESET by uninstall and install client");
		} else if ("fastReset".equals(resetappiumdevice)) {
			logger.info(" Driver DO FAST-RESET by clearing cache and settings without reinstall");
            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
            capabilities.setCapability(MobileCapabilityType.NO_RESET, false);
		} else if ("noReset".equals(resetappiumdevice)) {
			logger.info(" Driver DO FASTEST start of app on device"); 
            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
        } //if else statement
		
			
		if ("androidchrome".equals(driverType)) {
			capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.CHROME);
		} //if statement
		
	}//setCapabilities
	
	
	@Override
	/**
	 * instantiateDriver creates an instance of driver, bridging the connection
	 * with the remote device
	 * 
	 * @return driver WebDriver Dec10RJR
	 */
	public WebDriver instantiateDriver() throws MalformedURLException {

			driver = new AppiumDriver<>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);

		return driver;
	}// instantiateDriver
}//AndroidDriver