package grocery.utils.driverfactory;
/** @author Roma Jacob Remedy Dec11RJR */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Timeouts;

import grocery.utils.InputParserUtil;


/** DriverFactory generates an instance of WebDriver depending on
 * {@link InputParserUtil}
 * containing specifications of particular drivers Dec10RJR */
public class DriverFactory {
	
	/** declaring abstractDriver */
	private transient AbstractDriver abstractDriver;
	
	/** declaring {@link InputParserUtil} inputParserUtil Dec15RJR */
	private final transient InputParserUtil inputParserUtil;
	
	/** declaring {@link WebDriver} driver */
	private transient WebDriver driver;
	
	/** options will store demeter {@link options} values */
	protected transient Options options;
	/** timeouts will store demeter {@link timeouts} values */
	protected transient Timeouts timeouts;
	
	
	/**
	 * Creates instance of {@link DriverFactory} Dec11RJR.
	 * 
	 * @param inputParserUtil
	 */
	public DriverFactory(final InputParserUtil inputParserUtil) {
		this.inputParserUtil = inputParserUtil;
	}// constructor
	
	/**
	 * builds the {@link WebDriver} driver class and instantiates the driver
	 * object Dec17RJR
	 */
	public void buildDriver() {

		try {

			String parrsedInput = inputParserUtil.getDriverType();
			parrsedInput = "androidnativeInputFromUser";
			if (parrsedInput.contains("android")) {
				abstractDriver = new AndroidDriver(inputParserUtil);
			} // if statement
			abstractDriver.setCapabilities();
			driver = abstractDriver.instantiateDriver();

		} catch (Exception e) {
			System.out.printf("\n RJR: Exception happened in %s \n The Exception was: %s \n",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e);
		} // try-catch
	}// buildDriver
	
	
	/** driver getter @return driver */
	public WebDriver getDriver() {
		return driver;
	}//getDriver
}//DiverFactory
