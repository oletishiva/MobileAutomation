package grocery.utils.driverfactory;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import grocery.utils.InputParserUtil;
import grocery.utils.InputParserUtilInterface.InputCLA;

/** AbstractDriver is the parent of all drivers */
abstract class AbstractDriver {

	/** declaring the objects name Dec15RJR */
	protected final transient String name;
	
	/** declaring {@link InputParserUtil} inputParserUtil Dec15RJR */
	protected transient InputParserUtil inputParserUtil;
	
	/**
	 * mappedCLA is a {@link HashMap} that stores all the Frameworks arguments
	 * Dec24RJR
	 */
	protected transient Map<InputCLA,String> mappedCLA;
	
	/** member driver {@link WebDriver} */
	protected transient WebDriver driver;
	/** declaring capabilities */
	protected transient DesiredCapabilities capabilities = new DesiredCapabilities(); 
	
	/** defining android specific capabilities Dec10RJR 
	 * @throws Exception */
	protected abstract void setCapabilities();
	

	/** AbstractDriver Constructor Dec14RJR */
	public AbstractDriver() {
		name = "AbstractDriverOBJ";
	} //constructor
	
	/**
	 * instantiateDriver creates an instance of driver, bridging the connection
	 * with the remote device
	 * 
	 * @return driver WebDriver Dec10RJR
	 * @throws MalformedURLException 
	 */
	public abstract WebDriver instantiateDriver() throws MalformedURLException;
	
}// AbstractDriver