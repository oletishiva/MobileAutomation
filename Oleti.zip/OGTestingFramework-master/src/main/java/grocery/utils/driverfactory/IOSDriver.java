package grocery.utils.driverfactory;
/** @author Roma Jacob Remedy Dec14RJR */

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import grocery.utils.InputParserUtil;

/** AndroidDriver specifically handles with Android Device Drivers Dec11RJR */
class IOSDriver extends AbstractDriver {
	
	/** Creates instance of {@link IOSDriver} Dec11RJR */
	public IOSDriver(final InputParserUtil inputParserUtil) {
		super();
		this.inputParserUtil = inputParserUtil;
	}//constructor
	
	@Override
	/** defining android specific capabilities Dec10RJR */
	protected void setCapabilities() {
		try {
		String driverType = inputParserUtil.getDriverType();
		String udid = inputParserUtil.getUdid();
		String bundleId = inputParserUtil.getBundleId();
		driverType = "iosnative";
		udid = "482eb15c641526c21eafe3c50f5a7a83b9f7c300";
		bundleId = "com.apple.mobilesafari";
		
		capabilities.setCapability(udid, "482eb15c641526c21eafe3c50f5a7a83b9f7c300");
		capabilities.setCapability("platformName", "ios");
		capabilities.setCapability("deviceName","iOS");
		capabilities.setCapability("platformVersion", "10.2");

		capabilities.setCapability(bundleId, "com.apple.mobilesafari");		
		
		capabilities.setCapability("showXcodeLog", true);
		capabilities.setCapability("automationName", "XCUITest");
        
		capabilities.setCapability("newCommandTimeout", "600000");
		
		
		if ("iosnative".equals(driverType)) {
			/** blank on purpose Dec17RJR */
		} else if ("iossafari".equals(driverType)) {
			/** mobile ios browser based mobile automation Dec17RJR */
			capabilities.setCapability("safariInitialUrl", "https://www.bing.com/");
			capabilities.setCapability("startIWDP", true );
			capabilities.setCapability("browserName", "safari");
			
		} else {
			throw new IllegalArgumentException(" RJR: IllegalArgumentException"
					+ "Invalid driveType in inputParserUtil \t" + driverType );
		} //if-else driverType selection
		
		} catch (Exception e) {
			System.out.printf("\n RJR: Exception happened in %s \n The Exception was: %s \n",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e);
		} // try-catch
	}//setCapabilities
	
	
	@Override
	/**
	 * instantiateDriver creates an instance of driver, bridging the connection
	 * with the remote device
	 * 
	 * @return driver {@link WebDriver} Dec10RJR
	 */
	public WebDriver instantiateDriver() {

		try {
			driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return driver;
	}// instantiateDriver
}//AndroidDriver